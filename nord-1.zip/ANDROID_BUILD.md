# NORD — préparation Android

Le projet est préparé pour être empaqueté avec Capacitor.

## Pré-requis

- Node.js 20+
- Android Studio récent
- Android SDK installé
- JDK 17 ou 21

## Première préparation

```bash
npm install
npm run android:setup
```

Cette commande crée le dossier `android/` s'il n'existe pas et synchronise les assets.

## Compiler l'APK debug

```bash
npm run android:build
```

L'APK debug sera généré dans :

```text
android/app/build/outputs/apk/debug/app-debug.apk
```

## Ouvrir dans Android Studio

```bash
npm run android:open
```

## Application distante (optionnel)

Si la version web est déjà déployée et que tu veux que l'APK charge cette version :

```bash
CAPACITOR_SERVER_URL=https://ton-domaine.example npm run android:setup
```

Ne renseigne cette variable que si tu veux explicitement une application dépendante d'une connexion internet.
