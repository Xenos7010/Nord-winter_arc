import { createFileRoute } from "@tanstack/react-router";
import { useEffect, useState } from "react";
import { AppShell } from "@/components/app-shell";
import { Landing } from "@/components/landing";
import { Onboarding } from "@/components/onboarding";
import { useArcStore } from "@/lib/store";

export const Route = createFileRoute("/")({ component: Home });

function Home() {
  const arc = useArcStore((s) => s.arc);
  const loadDemo = useArcStore((s) => s.loadDemo);
  const [onboarding, setOnboarding] = useState(false);

  useEffect(() => {
    const result = useArcStore.persist.rehydrate();
    void Promise.resolve(result).finally(() => {
      useArcStore.getState().setHydrated();
    });
  }, []);

  if (onboarding && !arc) {
    return <Onboarding onCancel={() => setOnboarding(false)} />;
  }

  if (!arc) {
    return (
      <Landing
        onStart={() => setOnboarding(true)}
        onDemo={loadDemo}
      />
    );
  }

  return <AppShell arc={arc} />;
}
