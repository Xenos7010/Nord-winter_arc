import type { RuleIcon } from "@/lib/types";
import {
  Ban,
  BookOpen,
  Brain,
  Droplets,
  Dumbbell,
  Footprints,
  Heart,
  Moon,
  PersonStanding,
  Smartphone,
  Snowflake,
  Sun,
  Trees,
  UtensilsCrossed,
  Wind,
  type LucideIcon,
} from "lucide-react";

const MAP: Record<RuleIcon, LucideIcon> = {
  droplet: Droplets,
  utensils: UtensilsCrossed,
  phone: Smartphone,
  dumbbell: Dumbbell,
  run: PersonStanding,
  tree: Trees,
  heart: Heart,
  footprints: Footprints,
  moon: Moon,
  shower: Snowflake,
  book: BookOpen,
  brain: Brain,
  sunrise: Sun,
  wind: Wind,
  ban: Ban,
};

export function RuleGlyph({
  name,
  className,
}: {
  name: RuleIcon;
  className?: string;
}) {
  const Icon = MAP[name] ?? Heart;
  return <Icon className={className} strokeWidth={1.6} />;
}
