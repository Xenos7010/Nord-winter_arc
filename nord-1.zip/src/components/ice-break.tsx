import { useState } from "react";
import { Frame } from "./frame";

const SHARDS = [
  { clip: "polygon(-0.1% -0.1%, 24.4% -0.1%, 25.9% 10.2%, 10.3% 14.4%, -0.1% 13.8%)", x: -67, y: -117, r: -1, d: 36 },
  { clip: "polygon(24.1% -0.1%, 55.7% -0.1%, 45.8% 13.2%, 25.6% 10.3%)", x: -45, y: -121, r: 2, d: 34 },
  { clip: "polygon(55.4% -0.1%, 75.2% -0.1%, 67.1% 15.3%, 56.8% 17.8%, 54.1% 17.8%, 45.6% 13.1%)", x: 3, y: -102, r: -8, d: 30 },
  { clip: "polygon(74.9% -0.1%, 100.2% -0.1%, 100.2% 14.7%, 66.8% 15.4%)", x: 82, y: -85, r: 14, d: 36 },
  { clip: "polygon(-0.1% 36.8%, -0.1% 13.6%, 10.3% 14.2%, 23.6% 31.3%, 15.5% 35.1%)", x: -84, y: -39, r: -9, d: 23 },
  { clip: "polygon(23.3% 31.4%, 10.1% 14.3%, 25.6% 10.1%, 45.9% 13.0%, 54.4% 17.7%, 38.1% 29.9%)", x: -39, y: -65, r: -7, d: 23 },
  { clip: "polygon(54.3% 36.6%, 37.8% 29.8%, 54.1% 17.6%, 56.8% 17.6%, 77.6% 29.0%)", x: 37, y: -22, r: 1, d: 15 },
  { clip: "polygon(100.2% 14.5%, 100.2% 28.2%, 87.7% 30.4%, 77.3% 29.1%, 56.5% 17.7%, 66.8% 15.2%)", x: 89, y: -80, r: 16, d: 23 },
  { clip: "polygon(-0.2% 47.2%, -0.2% 36.6%, 15.4% 34.9%, 37.3% 51.4%, 24.3% 54.9%)", x: -104, y: 134, r: -4, d: 15 },
  { clip: "polygon(37.0% 51.5%, 15.1% 35.0%, 23.2% 31.2%, 38.1% 29.6%, 54.5% 36.4%, 61.2% 47.4%, 39.4% 51.6%)", x: -92, y: 39, r: 0, d: 5 },
  { clip: "polygon(60.8% 47.4%, 54.1% 36.4%, 77.4% 28.9%, 87.8% 30.2%, 77.3% 47.2%, 69.8% 48.6%)", x: 71, y: 48, r: -1, d: 10 },
  { clip: "polygon(100.1% 28.0%, 100.1% 48.4%, 77.1% 47.2%, 87.6% 30.2%)", x: 100, y: 18, r: 20, d: 18 },
  { clip: "polygon(-0.1% 62.7%, -0.1% 47.1%, 24.4% 54.7%, 15.3% 61.1%)", x: -123, y: 151, r: -16, d: 22 },
  { clip: "polygon(15.0% 61.0%, 24.1% 54.7%, 37.0% 51.2%, 39.5% 51.4%, 49.8% 68.4%, 49.0% 68.9%, 23.5% 66.0%)", x: -27, y: 177, r: -7, d: 19 },
  { clip: "polygon(49.5% 68.5%, 39.2% 51.4%, 61.0% 47.2%, 70.0% 48.4%, 75.8% 64.8%)", x: 34, y: 223, r: 11, d: 14 },
  { clip: "polygon(100.2% 48.2%, 100.2% 67.4%, 79.6% 66.0%, 75.5% 64.8%, 69.7% 48.4%, 77.2% 47.0%)", x: 110, y: 162, r: 9, d: 20 },
  { clip: "polygon(-0.1% 79.3%, -0.1% 62.5%, 15.3% 60.9%, 23.8% 65.9%, 16.4% 79.6%)", x: -93, y: 254, r: -2, d: 31 },
  { clip: "polygon(16.2% 79.5%, 23.5% 65.8%, 49.0% 68.7%, 44.5% 81.7%, 33.7% 83.2%)", x: -53, y: 234, r: -12, d: 33 },
  { clip: "polygon(44.2% 81.7%, 48.7% 68.7%, 49.5% 68.3%, 75.8% 64.6%, 79.9% 65.8%, 70.4% 84.3%, 44.3% 81.7%)", x: 7, y: 251, r: 5, d: 30 },
  { clip: "polygon(100.2% 67.2%, 100.2% 85.7%, 77.1% 86.7%, 70.1% 84.3%, 79.6% 65.7%)", x: 60, y: 223, r: 10, d: 37 },
  { clip: "polygon(21.4% 100.1%, -0.2% 100.1%, -0.2% 79.0%, 16.4% 79.4%, 33.9% 83.0%)", x: -74, y: 297, r: -1, d: 46 },
  { clip: "polygon(53.9% 100.1%, 21.1% 100.1%, 33.6% 83.0%, 44.5% 81.5%, 44.5% 81.6%)", x: -10, y: 300, r: -1, d: 45 },
  { clip: "polygon(69.7% 100.1%, 53.6% 100.1%, 44.3% 81.5%, 70.4% 84.1%, 77.4% 86.5%)", x: 33, y: 272, r: 14, d: 46 },
  { clip: "polygon(100.2% 85.5%, 100.2% 100.1%, 69.4% 100.1%, 77.1% 86.5%)", x: 81, y: 333, r: 20, d: 51 },
];

export function IceBreak({ onBroken }: { onBroken: () => void }) {
  const [taps, setTaps] = useState(0);
  const [leaving, setLeaving] = useState(false);
  const [impacts, setImpacts] = useState<{ id: number; x: number; y: number }[]>([]);
  const [flash, setFlash] = useState(0);

  function tap(e: React.PointerEvent<HTMLButtonElement>) {
    if (leaving) return;
    const rect = e.currentTarget.getBoundingClientRect();
    const x = ((e.clientX - rect.left) / rect.width) * 100;
    const y = ((e.clientY - rect.top) / rect.height) * 100;
    setImpacts((prev) => [...prev.slice(-4), { id: Date.now() + Math.random(), x, y }]);
    setFlash((n) => n + 1);
    const next = taps + 1;
    setTaps(next);
    if (next >= 3) {
      setLeaving(true);
      window.setTimeout(onBroken, 1150);
    }
  }

  return (
    <Frame>
      <button
        type="button"
        onPointerDown={tap}
        className="relative z-[1] flex min-h-dvh w-full flex-col items-center justify-center overflow-hidden px-6 text-center md:min-h-[844px]"
      >
        {!leaving && <IcePane taps={taps} />}
        {leaving &&
          SHARDS.map((s, i) => (
            <span
              key={i}
              className="ice-shard pointer-events-none absolute inset-0"
              style={{
                ["--dx" as string]: `${s.x}px`,
                ["--dy" as string]: `${s.y}px`,
                ["--rot" as string]: `${s.r}deg`,
                animation: `ice-shatter 1000ms cubic-bezier(0.22, 1, 0.36, 1) ${s.d}ms both`,
              }}
            >
              <span className="ice-fill absolute inset-0" style={{ clipPath: s.clip }} />
            </span>
          ))}

        <Cracks taps={taps} leaving={leaving} />

        {impacts.map((p) => (
          <span
            key={p.id}
            className="ice-ripple pointer-events-none absolute size-4 rounded-full"
            style={{ left: `${p.x}%`, top: `${p.y}%` }}
          />
        ))}

        <span
          key={flash}
          className="pointer-events-none absolute inset-0 bg-ice/30"
          style={{ animation: flash ? "ice-flash 420ms ease-out both" : undefined }}
        />

        <div
          className="relative z-[2]"
          style={{
            opacity: leaving ? 0 : 1,
            transform: leaving ? "scale(0.98)" : "scale(1)",
            transition: "opacity 400ms ease, transform 400ms ease",
          }}
        >
          <p className="text-[11px] tracking-[0.28em] text-ice uppercase">Jour 1</p>
          <h1 className="mt-4 font-serif text-[2.6rem] leading-[1.05] tracking-tight text-fg">
            Ton arc est pris
            <br />
            dans la glace.
          </h1>
          <p className="mx-auto mt-5 max-w-[16rem] text-[14px] text-muted">
            {taps >= 3
              ? "Ça se brise."
              : `Trois taps pour la briser. ${3 - taps} restant${3 - taps > 1 ? "s" : ""}.`}
          </p>
        </div>
      </button>
    </Frame>
  );
}

function IcePane({ taps: _taps }: { taps: number }) {
  return (
    <span
      className="ice-fill pointer-events-none absolute inset-0"
      style={{ boxShadow: "inset 0 0 80px rgba(190, 230, 245, 0.12)" }}
    />
  );
}

function Cracks({ taps, leaving }: { taps: number; leaving: boolean }) {
  return (
    <svg
      className="pointer-events-none absolute inset-0 h-full w-full"
      viewBox="0 0 390 844"
      preserveAspectRatio="xMidYMid slice"
      style={{ opacity: leaving ? 0 : 1, transition: "opacity 280ms ease" }}
    >
      <defs>
        <filter id="crack-glow" x="-20%" y="-20%" width="140%" height="140%">
          <feGaussianBlur stdDeviation="1.2" result="b" />
          <feMerge>
            <feMergeNode in="b" />
            <feMergeNode in="SourceGraphic" />
          </feMerge>
        </filter>
      </defs>
      <g
        fill="none"
        stroke="#e8f4fa"
        strokeLinecap="round"
        strokeLinejoin="round"
        filter="url(#crack-glow)"
      >
        <CrackPath
          d="M196 0 L204 150 L168 250 L248 360 L190 520 L220 844"
          show={taps >= 1}
          w={2.2}
        />
        <CrackPath d="M204 150 L310 120 L390 168" show={taps >= 1} w={1.4} />
        <CrackPath d="M168 250 L70 210 L0 248" show={taps >= 1} w={1.3} />
        <CrackPath d="M168 250 L120 340 L40 420" show={taps >= 2} w={1.5} />
        <CrackPath d="M248 360 L340 320 L390 360" show={taps >= 2} w={1.4} />
        <CrackPath d="M248 360 L300 470 L360 560 L390 620" show={taps >= 2} w={1.6} />
        <CrackPath d="M190 520 L90 500 L0 560" show={taps >= 2} w={1.3} />
        <CrackPath d="M190 520 L140 640 L80 760" show={taps >= 3} w={1.8} />
        <CrackPath d="M220 620 L300 700 L340 820" show={taps >= 3} w={1.6} />
        <CrackPath d="M310 120 L280 60 L300 0" show={taps >= 3} w={1.1} />
        <CrackPath d="M70 210 L90 80 L40 0" show={taps >= 3} w={1.1} />
        <CrackPath d="M300 470 L250 430 L210 470" show={taps >= 3} w={1} />
      </g>
    </svg>
  );
}

function CrackPath({ d, show, w }: { d: string; show: boolean; w: number }) {
  return (
    <path
      d={d}
      pathLength={1}
      strokeWidth={show ? w : 0}
      className={show ? "ice-crack" : undefined}
      opacity={show ? 0.9 : 0}
    />
  );
}
