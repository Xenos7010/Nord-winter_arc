import { useEffect, useState } from "react";
import { msUntil, splitCountdown } from "@/lib/arc";
import type { Arc } from "@/lib/types";
import { formatFr } from "@/lib/utils";
import { ConfirmSheet } from "./confirm-sheet";
import { Frame } from "./frame";

export function Countdown({ arc, onReset }: { arc: Arc; onReset: () => void }) {
  const [, setNow] = useState(() => Date.now());
  const [confirm, setConfirm] = useState(false);

  useEffect(() => {
    const id = window.setInterval(() => setNow(Date.now()), 1000);
    return () => window.clearInterval(id);
  }, []);

  const live = splitCountdown(msUntil(arc.startDate));

  return (
    <Frame>
      <div className="relative z-[1] flex min-h-dvh flex-col px-6 pb-[max(1.5rem,env(safe-area-inset-bottom))] pt-[max(2rem,env(safe-area-inset-top))] md:min-h-[844px]">
        <p className="text-center text-[11px] tracking-[0.24em] text-ice uppercase">Avant le départ</p>
        <h1 className="mt-4 text-center font-serif text-[2.4rem] leading-tight tracking-tight">
          Ton arc commence
          <br />
          {formatFr(arc.startDate, { weekday: "long", day: "numeric", month: "long" })}
        </h1>

        <div className="my-auto grid grid-cols-4 gap-2">
          <Unit value={live.d} label="jours" />
          <Unit value={live.h} label="heures" />
          <Unit value={live.m} label="min" />
          <Unit value={live.s} label="sec" />
        </div>

        <p className="mb-8 text-center text-[14px] leading-relaxed text-muted">
          Un rappel chaque soir jusqu'au jour 1. Arrive prêt. Le jour J, tu brises la glace.
        </p>
        <p className="mb-4 text-center text-[12px] text-faint">Signé par {arc.signerName}</p>
        <button
          type="button"
          onClick={() => setConfirm(true)}
          className="h-11 text-[13px] text-muted"
        >
          Annuler le contrat
        </button>
        <ConfirmSheet
          open={confirm}
          title="Annuler le contrat ?"
          body="Tu n'as pas encore commencé. Ça efface la signature et le jour 1 choisi."
          confirmLabel="Annuler l'arc"
          onCancel={() => setConfirm(false)}
          onConfirm={onReset}
        />
      </div>
    </Frame>
  );
}

function Unit({ value, label }: { value: number; label: string }) {
  return (
    <div className="rounded-lg bg-surface px-1 py-4 text-center">
      <div className="font-serif text-[2rem] tabular-nums leading-none text-fg">
        {String(value).padStart(2, "0")}
      </div>
      <div className="mt-2 text-[10px] tracking-[0.16em] text-muted uppercase">{label}</div>
    </div>
  );
}