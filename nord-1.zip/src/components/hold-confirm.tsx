import { useRef, useState } from "react";
import { Check } from "lucide-react";
import { cn } from "@/lib/utils";

const HOLD_MS = 680;
const SIZE = 44;
const R = 16;
const C = 2 * Math.PI * R;

type Props = {
  confirmed: boolean;
  disabled?: boolean;
  onConfirm: () => void;
  label?: string;
};

export function HoldConfirm({ confirmed, disabled, onConfirm, label }: Props) {
  const [progress, setProgress] = useState(0);
  const raf = useRef<number | null>(null);
  const start = useRef(0);

  function stop() {
    if (raf.current) cancelAnimationFrame(raf.current);
    raf.current = null;
    setProgress(0);
  }

  function tick(now: number) {
    const p = Math.min(1, (now - start.current) / HOLD_MS);
    setProgress(p);
    if (p >= 1) {
      stop();
      onConfirm();
      return;
    }
    raf.current = requestAnimationFrame(tick);
  }

  function down(e: React.PointerEvent) {
    if (disabled) return;
    e.preventDefault();
    try {
      (e.currentTarget as HTMLElement).setPointerCapture(e.pointerId);
    } catch {
      /* ignore — untrusted events cannot capture */
    }
    start.current = performance.now();
    raf.current = requestAnimationFrame(tick);
  }

  function up() {
    stop();
  }

  return (
    <button
      type="button"
      aria-label={label ?? (confirmed ? "Retirer" : "Maintenir pour valider")}
      disabled={disabled}
      onPointerDown={down}
      onPointerUp={up}
      onPointerCancel={up}
      onLostPointerCapture={up}
      onContextMenu={(e) => e.preventDefault()}
      className={cn(
        "relative grid size-11 place-items-center rounded-full select-none",
        "transition-transform duration-150 ease-out active:scale-[0.96]",
        disabled && "opacity-40",
      )}
      style={{ touchAction: "none" }}
    >
      <svg width={SIZE} height={SIZE} viewBox="0 0 44 44" className="absolute inset-0">
        <circle
          cx="22"
          cy="22"
          r={R}
          fill="none"
          className="stroke-line"
          strokeWidth="1.5"
        />
        <circle
          cx="22"
          cy="22"
          r={R}
          fill="none"
          className={confirmed ? "stroke-ok" : "stroke-ice"}
          strokeWidth="2"
          strokeLinecap="round"
          strokeDasharray={C}
          strokeDashoffset={confirmed ? 0 : C * (1 - progress)}
          transform="rotate(-90 22 22)"
        />
      </svg>
      <span
        className={cn(
          "grid size-7 place-items-center rounded-full transition-[background,color,transform] duration-200",
          confirmed ? "bg-ok/15 text-ok" : "text-faint",
        )}
      >
        <Check className="size-3.5" strokeWidth={2.4} />
      </span>
    </button>
  );
}
