type Props = {
  open: boolean;
  title: string;
  body: string;
  confirmLabel: string;
  cancelLabel?: string;
  onCancel: () => void;
  onConfirm: () => void;
};

export function ConfirmSheet({
  open,
  title,
  body,
  confirmLabel,
  cancelLabel = "Annuler",
  onCancel,
  onConfirm,
}: Props) {
  if (!open) return null;
  return (
    <div className="fixed inset-0 z-40 grid place-items-center md:absolute bg-bg/75 px-5">
      <div
        role="dialog"
        aria-modal="true"
        aria-labelledby="confirm-title"
        className="w-full max-w-[340px] rounded-xl border border-line bg-surface p-5"
      >
        <h3 id="confirm-title" className="font-serif text-[1.7rem] leading-tight tracking-tight">
          {title}
        </h3>
        <p className="mt-2 text-[14px] leading-relaxed text-muted">{body}</p>
        <div className="mt-5 grid grid-cols-2 gap-2">
          <button
            type="button"
            onClick={onCancel}
            className="h-12 rounded-md border border-line text-[14px] text-muted transition-transform duration-150 active:scale-[0.96]"
          >
            {cancelLabel}
          </button>
          <button
            type="button"
            onClick={onConfirm}
            className="h-12 rounded-md bg-fg text-[14px] font-medium text-bg transition-transform duration-150 active:scale-[0.96]"
          >
            {confirmLabel}
          </button>
        </div>
      </div>
    </div>
  );
}
