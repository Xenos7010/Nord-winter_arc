import type { ReactNode } from "react";
import { cn } from "@/lib/utils";

export function Frame({ children, className }: { children: ReactNode; className?: string }) {
  return (
    <div className="min-h-dvh bg-bg md:flex md:items-center md:justify-center md:bg-[#040506] md:p-6">
      <div
        className={cn(
          "relative mx-auto flex min-h-dvh w-full max-w-[430px] flex-col overflow-hidden bg-bg grain",
          "md:min-h-[844px] md:max-h-[844px] md:rounded-[2.5rem] md:border md:border-line md:shadow-[0_40px_80px_-20px_rgba(0,0,0,0.7)]",
          className,
        )}
      >
        {children}
      </div>
    </div>
  );
}
