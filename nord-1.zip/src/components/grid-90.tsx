import { ARC_LENGTH, dayNumber, evaluateWeeks, isoForDay, isDayFull } from "@/lib/arc";
import type { Arc } from "@/lib/types";
import { cn, formatFr, todayISO } from "@/lib/utils";
import { useState } from "react";

export function Grid90({ arc }: { arc: Arc }) {
  const iso = todayISO();
  const n = dayNumber(arc, iso);
  const evalw = evaluateWeeks(arc, iso);
  const [picked, setPicked] = useState<number | null>(null);
  const pickedIso = picked ? isoForDay(arc, picked) : null;

  return (
    <div className="flex flex-1 flex-col overflow-y-auto px-5 pb-36 pt-[max(1.25rem,env(safe-area-inset-top))]">
      <p className="text-[11px] tracking-[0.22em] text-muted uppercase">90 cases</p>
      <h1 className="mt-2 font-serif text-[2.4rem] leading-tight tracking-tight">
        Plus tu tiens,
        <br />
        plus elles s'allument.
      </h1>

      <div className="mt-6 grid grid-cols-10 gap-1.5">
        {Array.from({ length: ARC_LENGTH }, (_, i) => {
          const day = i + 1;
          const dIso = isoForDay(arc, day);
          const future = n > 0 ? day > n : true;
          const full = !future && isDayFull(arc, dIso);
          const started = !future && Boolean(arc.days[dIso]);
          return (
            <button
              key={day}
              type="button"
              onClick={() => setPicked(day)}
              aria-label={`Jour ${day}`}
              className={cn(
                "aspect-square rounded-[5px] transition-transform duration-150 active:scale-[0.96]",
                full && "bg-ok",
                !full && started && "bg-ember/80",
                future && "bg-raised",
                !future && !full && !started && "bg-line",
                picked === day && "ring-1 ring-fg",
              )}
            />
          );
        })}
      </div>

      <div className="mt-6 flex flex-wrap gap-x-4 gap-y-2 text-[11px] text-muted">
        <Legend swatch="bg-ok" label="Journée pleine" />
        <Legend swatch="bg-ember/80" label="Incomplète" />
        <Legend swatch="bg-raised" label="À venir" />
      </div>

      {picked && pickedIso && (
        <div className="mt-6 rounded-lg border border-line bg-surface px-4 py-4">
          <div className="text-[12px] text-muted">
            Jour {picked} · {formatFr(pickedIso)}
          </div>
          <div className="mt-1 text-[15px]">
            {n > 0 && picked > n
              ? "Pas encore."
              : isDayFull(arc, pickedIso)
                ? "Journée pleine."
                : arc.days[pickedIso]
                  ? "Journée incomplète."
                  : "Rien de validé."}
          </div>
        </div>
      )}

      <div className="mt-8">
        <p className="mb-3 text-[11px] tracking-[0.2em] text-muted uppercase">Semaines</p>
        <ul className="space-y-2">
          {evalw.weeks.map((w) => (
            <li key={w.index} className="flex items-center justify-between text-[13px]">
              <span>Semaine {w.index + 1}</span>
              <span
                className={cn(
                  "text-[12px]",
                  w.mark === "complete" && "text-ok",
                  w.mark === "frozen" && "text-ice",
                  w.mark === "failed" && "text-danger",
                  w.mark === "current" && "text-fg",
                  w.mark === "upcoming" && "text-faint",
                )}
              >
                {weekLabel(w.mark)}
              </span>
            </li>
          ))}
        </ul>
      </div>
    </div>
  );
}

function Legend({ swatch, label }: { swatch: string; label: string }) {
  return (
    <span className="inline-flex items-center gap-2">
      <span className={cn("size-2.5 rounded-[3px]", swatch)} />
      {label}
    </span>
  );
}

function weekLabel(mark: string) {
  if (mark === "complete") return "Validée";
  if (mark === "frozen") return "Gelée";
  if (mark === "failed") return "Ratée";
  if (mark === "current") return "En cours";
  return "—";
}
