import { evaluateWeeks, weekCount } from "@/lib/arc";
import type { Arc } from "@/lib/types";
import { LivingFlame } from "./living-flame";

export function FlameView({ arc }: { arc: Arc }) {
  const { weeks, flame, gelUsed, flameOut } = evaluateWeeks(arc);
  const total = weekCount(arc);
  const frozen = weeks.some((w) => w.mark === "frozen");

  let status = "La flamme grandit avec chaque semaine complète.";
  if (flameOut) status = "La flamme s'est éteinte. L'arc, lui, continue jusqu'au jour 90.";
  else if (frozen) status = "Le gel la couvre. Une seule fois. La prochaine, elle s'éteint.";

  return (
    <div className="flex flex-1 flex-col overflow-y-auto px-5 pb-36 pt-[max(1.25rem,env(safe-area-inset-top))]">
      <p className="text-[11px] tracking-[0.22em] text-muted uppercase">La flamme</p>
      <h1 className="mt-2 font-serif text-[2.4rem] leading-tight tracking-tight">
        {flameOut ? "Éteinte." : frozen ? "Gelée." : "Elle ne pardonne qu'une fois."}
      </h1>
      <p className="mt-3 max-w-[22rem] text-[14px] leading-relaxed text-muted">{status}</p>

      <div className="relative mx-auto my-8 grid place-items-center">
        <LivingFlame size={220} out={flameOut} frozen={frozen} />
      </div>

      <div className="text-center">
        <div className="font-serif text-[3rem] leading-none tabular-nums">{flame}</div>
        <div className="mt-1 text-[12px] tracking-[0.16em] text-muted uppercase">
          semaines allumées · {total} au total
        </div>
      </div>

      <ul className="mt-10 space-y-3 text-[13px] text-muted">
        <li className="flex justify-between border-b border-line pb-3">
          <span>Gel utilisé</span>
          <span className="text-fg">{gelUsed ? "Oui" : "Pas encore"}</span>
        </li>
        <li className="flex justify-between border-b border-line pb-3">
          <span>Semaines validées</span>
          <span className="text-fg tabular-nums">{flame}</span>
        </li>
        <li className="flex justify-between">
          <span>État</span>
          <span className="text-fg">
            {flameOut ? "Éteinte" : frozen ? "Couverte par le gel" : "Vivante"}
          </span>
        </li>
      </ul>
    </div>
  );
}
