import { dayNumber } from "@/lib/arc";
import { useArcStore } from "@/lib/store";
import type { Arc } from "@/lib/types";
import { Frame } from "./frame";

export function Complete({ arc }: { arc: Arc }) {
  const reset = useArcStore((s) => s.reset);

  return (
    <Frame>
      <div className="relative z-[1] flex min-h-dvh flex-col px-6 pb-[max(1.5rem,env(safe-area-inset-bottom))] pt-[max(2rem,env(safe-area-inset-top))] md:min-h-[844px]">
        <p className="text-[11px] tracking-[0.24em] text-ice uppercase">Jour 90</p>
        <h1 className="mt-3 font-serif text-[2.6rem] leading-tight tracking-tight">
          Voilà ce que 90 jours ont changé.
        </h1>
        <div className="mt-8 grid flex-1 grid-cols-2 gap-3">
          <figure className="overflow-hidden rounded-lg bg-raised">
            {arc.photos.day1 ? (
              <img src={arc.photos.day1} alt="Jour 1" className="h-full min-h-48 w-full object-cover" />
            ) : (
              <div className="grid h-full min-h-48 place-items-center text-[12px] text-faint">Pas de photo jour 1</div>
            )}
            <figcaption className="px-3 py-2 text-[12px] text-muted">Jour 1</figcaption>
          </figure>
          <figure className="overflow-hidden rounded-lg bg-raised">
            {arc.photos.day90 ? (
              <img src={arc.photos.day90} alt="Jour 90" className="h-full min-h-48 w-full object-cover" />
            ) : (
              <div className="grid h-full min-h-48 place-items-center text-[12px] text-faint">Pas de photo jour 90</div>
            )}
            <figcaption className="px-3 py-2 text-[12px] text-muted">Jour 90</figcaption>
          </figure>
        </div>
        <p className="mt-6 text-[14px] text-muted">
          {arc.signerName}. Un autre arc peut commencer quand tu veux.
        </p>
        <button
          type="button"
          onClick={reset}
          className="mt-6 flex h-14 items-center justify-center rounded-[18px] bg-fg text-[15px] font-medium text-bg"
        >
          Nouvel arc
        </button>
      </div>
    </Frame>
  );
}
