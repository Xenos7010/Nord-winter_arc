import { Flame, Grid2x2, Sun, User } from "lucide-react";
import type { TabId } from "@/lib/types";
import { cn } from "@/lib/utils";

const TABS: { id: TabId; label: string; icon: typeof Sun }[] = [
  { id: "jour", label: "Jour", icon: Sun },
  { id: "cases", label: "90", icon: Grid2x2 },
  { id: "flamme", label: "Flamme", icon: Flame },
  { id: "toi", label: "Toi", icon: User },
];

export function TabBar({ tab, onChange }: { tab: TabId; onChange: (t: TabId) => void }) {
  return (
    <nav className="pointer-events-none fixed inset-x-0 bottom-0 z-30 mx-auto w-full max-w-[430px] md:absolute flex justify-center px-4 pb-[max(0.85rem,calc(env(safe-area-inset-bottom)+0.35rem))]">
      <ul className="pointer-events-auto grid w-full grid-cols-4 rounded-[22px] border border-line bg-raised py-1.5 shadow-[0_10px_40px_-16px_rgba(0,0,0,0.8)]">
        {TABS.map((t) => {
          const Icon = t.icon;
          const active = tab === t.id;
          return (
            <li key={t.id}>
              <button
                type="button"
                onClick={() => onChange(t.id)}
                className={cn(
                  "flex h-12 w-full flex-col items-center justify-center gap-0.5 text-[10px] tracking-wide transition-colors duration-150",
                  active ? "text-fg" : "text-faint",
                )}
              >
                <Icon className="size-[18px]" strokeWidth={active ? 2 : 1.6} />
                {t.label}
              </button>
            </li>
          );
        })}
      </ul>
    </nav>
  );
}
