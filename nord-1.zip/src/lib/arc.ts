import { RULE_MAP } from "./catalog";
import type { Arc, DayLog, RuleDef, WeekMark } from "./types";
import { addDaysISO, diffDays, todayISO } from "./utils";

export const ARC_LENGTH = 90;

export function rulesOf(arc: Arc): RuleDef[] {
  return arc.ruleIds.map((id) => RULE_MAP[id]).filter(Boolean);
}

export function dayNumber(arc: Arc, iso = todayISO()): number {
  return diffDays(arc.startDate, iso) + 1;
}

export function isoForDay(arc: Arc, n: number): string {
  return addDaysISO(arc.startDate, n - 1);
}

export function isBeforeStart(arc: Arc, iso = todayISO()): boolean {
  return diffDays(arc.startDate, iso) < 0;
}

export function isComplete(arc: Arc, iso = todayISO()): boolean {
  return dayNumber(arc, iso) > ARC_LENGTH;
}

export function clampDay(arc: Arc, iso = todayISO()): number {
  return Math.min(ARC_LENGTH, Math.max(0, dayNumber(arc, iso)));
}

export function dailyRules(rules: RuleDef[]): RuleDef[] {
  return rules.filter((r) => r.cadence === "daily");
}

export function weeklyRules(rules: RuleDef[]): RuleDef[] {
  return rules.filter((r) => r.cadence === "weekly");
}

export function emptyLog(date: string): DayLog {
  return { date, checks: {} };
}

export function logFor(arc: Arc, iso: string): DayLog {
  return arc.days[iso] ?? emptyLog(iso);
}

export function isRuleChecked(arc: Arc, iso: string, ruleId: string): boolean {
  return Boolean(arc.days[iso]?.checks[ruleId]);
}

export function dayScore(arc: Arc, iso: string): { done: number; total: number } {
  const rules = rulesOf(arc);
  const log = logFor(arc, iso);
  const done = rules.filter((r) => log.checks[r.id]).length;
  return { done, total: rules.length };
}

export function isDayFull(arc: Arc, iso: string): boolean {
  const dailies = dailyRules(rulesOf(arc));
  if (dailies.length === 0) return false;
  const log = logFor(arc, iso);
  return dailies.every((r) => log.checks[r.id]);
}

export function weekIndexForDay(dayN: number): number {
  return Math.floor((dayN - 1) / 7);
}

export function weekCount(arc: Arc): number {
  return Math.ceil(ARC_LENGTH / 7);
}

export function daysInWeek(arc: Arc, weekIndex: number): string[] {
  const start = weekIndex * 7 + 1;
  const end = Math.min(ARC_LENGTH, start + 6);
  const out: string[] = [];
  for (let n = start; n <= end; n++) out.push(isoForDay(arc, n));
  return out;
}

export function weeklyProgress(arc: Arc, weekIndex: number, rule: RuleDef): { done: number; target: number } {
  const target = rule.weeklyTarget ?? 1;
  const days = daysInWeek(arc, weekIndex);
  const done = days.filter((iso) => isRuleChecked(arc, iso, rule.id)).length;
  return { done, target };
}

export function isWeekComplete(arc: Arc, weekIndex: number): boolean {
  const days = daysInWeek(arc, weekIndex);
  if (!days.every((iso) => isDayFull(arc, iso))) return false;
  const weeklies = weeklyRules(rulesOf(arc));
  return weeklies.every((r) => {
    const { done, target } = weeklyProgress(arc, weekIndex, r);
    return done >= target;
  });
}

export type WeekSnapshot = {
  index: number;
  mark: WeekMark;
  days: { iso: string; n: number; full: boolean; incomplete: boolean; future: boolean }[];
};

export function evaluateWeeks(arc: Arc, iso = todayISO()): {
  weeks: WeekSnapshot[];
  flame: number;
  gelUsed: boolean;
  flameOut: boolean;
} {
  const todayN = dayNumber(arc, iso);
  const totalWeeks = weekCount(arc);
  const currentWeek = todayN <= 0 ? -1 : weekIndexForDay(Math.min(todayN, ARC_LENGTH));
  const weeks: WeekSnapshot[] = [];
  let gelUsed = false;
  let flameOut = false;
  let flame = 0;

  for (let i = 0; i < totalWeeks; i++) {
    const days = daysInWeek(arc, i).map((d) => {
      const n = dayNumber(arc, d);
      const future = todayN > 0 ? n > todayN : true;
      const full = !future && isDayFull(arc, d);
      const incomplete = !future && !full && Boolean(arc.days[d]);
      return { iso: d, n, full, incomplete: incomplete || (!future && !full), future };
    });

    let mark: WeekMark;
    if (todayN <= 0 || i > currentWeek) {
      mark = "upcoming";
    } else if (i === currentWeek && todayN <= ARC_LENGTH) {
      mark = "current";
    } else if (isWeekComplete(arc, i)) {
      mark = "complete";
      flame += 1;
    } else if (!gelUsed && !flameOut) {
      mark = "frozen";
      gelUsed = true;
    } else {
      mark = "failed";
      flameOut = true;
    }

    weeks.push({ index: i, mark, days });
  }

  return { weeks, flame, gelUsed, flameOut };
}

export function msUntil(iso: string): number {
  const start = parseISODateMidnight(iso);
  return start.getTime() - Date.now();
}

function parseISODateMidnight(iso: string): Date {
  const [y, m, d] = iso.split("-").map(Number);
  return new Date(y, m - 1, d, 0, 0, 0, 0);
}

export function splitCountdown(ms: number): { d: number; h: number; m: number; s: number } {
  const clamped = Math.max(0, ms);
  const s = Math.floor(clamped / 1000);
  return {
    d: Math.floor(s / 86400),
    h: Math.floor((s % 86400) / 3600),
    m: Math.floor((s % 3600) / 60),
    s: s % 60,
  };
}
