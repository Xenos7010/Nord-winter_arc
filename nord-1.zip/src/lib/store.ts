import { create } from "zustand";
import { persist } from "zustand/middleware";
import { PROGRAM_MAP, applyTraining } from "./catalog";
import { evaluateWeeks, rulesOf } from "./arc";
import type { Arc, ProgramId, TabId, TrainingMode } from "./types";
import { addDaysISO, todayISO } from "./utils";

type Draft = {
  programId: ProgramId;
  training: TrainingMode;
  startDate: string;
  signerName: string;
  signatureData?: string;
};

type ArcState = {
  hydrated: boolean;
  arc: Arc | null;
  tab: TabId;
  draft: Draft;
  setHydrated: () => void;
  setTab: (tab: TabId) => void;
  setDraft: (partial: Partial<Draft>) => void;
  sign: () => void;
  loadDemo: () => void;
  toggleCheck: (iso: string, ruleId: string) => void;
  setGratitude: (iso: string, text: string) => void;
  setPhoto: (slot: "day1" | "day90", dataUrl: string) => void;
  breakIce: () => void;
  reset: () => void;
};

const defaultDraft = (): Draft => ({
  programId: "classique",
  training: "salle",
  startDate: todayISO(),
  signerName: "",
});

function applyWeekFlags(arc: Arc): Arc {
  const { gelUsed, flameOut } = evaluateWeeks(arc);
  if (arc.gelUsed === gelUsed && arc.flameOut === flameOut) return arc;
  return { ...arc, gelUsed, flameOut };
}

function demoArc(): Arc {
  const start = addDaysISO(todayISO(), -46);
  const program = PROGRAM_MAP.classique;
  const days: Arc["days"] = {};
  for (let n = 1; n <= 46; n++) {
    const iso = addDaysISO(start, n - 1);
    const week = Math.floor((n - 1) / 7);
    const missWeek = week === 2;
    const missDay = missWeek && (n === 16 || n === 17);
    const checks: Record<string, boolean> = {};
    for (const id of program.ruleIds) {
      const ruleWeekly = id === "salle" || id === "course";
      if (missDay) {
        checks[id] = id === "eau" || id === "pas";
        continue;
      }
      if (ruleWeekly) {
        const dayInWeek = (n - 1) % 7;
        if (id === "salle") checks[id] = dayInWeek < 4;
        if (id === "course") checks[id] = dayInWeek === 1 || dayInWeek === 4;
      } else {
        checks[id] = true;
      }
    }
    days[iso] = {
      date: iso,
      checks,
      gratitude: missDay ? undefined : "J'ai tenu. C'est déjà ça.",
    };
  }
  const raw: Arc = {
    startDate: start,
    signedAt: start,
    signerName: "Démo",
    programId: "classique",
    ruleIds: program.ruleIds,
    days,
    gelUsed: false,
    flameOut: false,
    iceBroken: true,
    photos: {},
    demo: true,
  };
  return applyWeekFlags(raw);
}

export const useArcStore = create<ArcState>()(
  persist(
    (set, get) => ({
      hydrated: false,
      arc: null,
      tab: "jour",
      draft: defaultDraft(),
      setHydrated: () => set({ hydrated: true }),
      setTab: (tab) => set({ tab }),
      setDraft: (partial) => set({ draft: { ...get().draft, ...partial } }),
      sign: () => {
        const { draft } = get();
        const program = PROGRAM_MAP[draft.programId] ?? PROGRAM_MAP.classique;
        const startDate = draft.startDate || todayISO();
        const arc: Arc = {
          startDate,
          signedAt: todayISO(),
          signerName: draft.signerName.trim() || "Anonyme",
          signatureData: draft.signatureData,
          programId: program.id,
          training: draft.training,
          ruleIds: applyTraining(program.ruleIds, draft.training),
          days: {},
          gelUsed: false,
          flameOut: false,
          iceBroken: startDate < todayISO(),
          photos: {},
        };
        set({ arc, tab: "jour", draft: defaultDraft() });
      },
      loadDemo: () => set({ arc: demoArc(), tab: "jour" }),
      toggleCheck: (iso, ruleId) => {
        const arc = get().arc;
        if (!arc) return;
        const prev = arc.days[iso] ?? { date: iso, checks: {} };
        const nextChecked = !prev.checks[ruleId];
        const checks = { ...prev.checks, [ruleId]: nextChecked };
        const days = { ...arc.days, [iso]: { ...prev, checks } };
        set({ arc: applyWeekFlags({ ...arc, days }) });
      },
      setGratitude: (iso, text) => {
        const arc = get().arc;
        if (!arc) return;
        const prev = arc.days[iso] ?? { date: iso, checks: {} };
        const checks = { ...prev.checks, gratitude: true };
        const days = {
          ...arc.days,
          [iso]: { ...prev, checks, gratitude: text.trim() },
        };
        set({ arc: applyWeekFlags({ ...arc, days }) });
      },
      setPhoto: (slot, dataUrl) => {
        const arc = get().arc;
        if (!arc) return;
        set({
          arc: { ...arc, photos: { ...arc.photos, [slot]: dataUrl } },
        });
      },
      breakIce: () => {
        const arc = get().arc;
        if (!arc) return;
        set({ arc: { ...arc, iceBroken: true } });
      },
      reset: () => set({ arc: null, tab: "jour", draft: defaultDraft() }),
    }),
    {
      name: "nord-arc-v1",
      partialize: (s) => ({ arc: s.arc }),
      skipHydration: true,
    },
  ),
);

export function useRules() {
  const arc = useArcStore((s) => s.arc);
  return arc ? rulesOf(arc) : [];
}
