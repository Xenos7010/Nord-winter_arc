import type { Program, RuleDef, TrainingMode } from "./types";

export const RULES: RuleDef[] = [
  {
    id: "eau",
    title: "Que de l'eau",
    detail: "Ni soda, ni alcool, ni jus.",
    icon: "droplet",
    cadence: "daily",
  },
  {
    id: "fastfood",
    title: "Zéro fast-food",
    detail: "Ça attendra le jour 91.",
    icon: "utensils",
    cadence: "daily",
  },
  {
    id: "tel",
    title: "Pas de téléphone à table",
    detail: "Tu manges. C'est tout.",
    icon: "phone",
    cadence: "daily",
  },
  {
    id: "salle",
    title: "La salle, 4× par semaine",
    detail: "Pas trois. Quatre.",
    icon: "dumbbell",
    cadence: "weekly",
    weeklyTarget: 4,
  },
  {
    id: "course",
    title: "Courir, 2× par semaine",
    detail: "Même lentement. Même sous la pluie.",
    icon: "run",
    cadence: "weekly",
    weeklyTarget: 2,
  },
  {
    id: "dehors",
    title: "20 minutes dehors",
    detail: "Tous les jours. Surtout en hiver.",
    icon: "tree",
    cadence: "daily",
  },
  {
    id: "gratitude",
    title: "Gratitude",
    detail: "Une chose, chaque soir.",
    icon: "heart",
    cadence: "daily",
  },
  {
    id: "pas",
    title: "10 000 pas",
    detail: "Chaque jour. Tu valides quand c'est fait.",
    icon: "footprints",
    cadence: "daily",
  },
  {
    id: "sommeil",
    title: "7 à 8 h de sommeil",
    detail: "Le vrai secret. Couche-toi.",
    icon: "moon",
    cadence: "daily",
  },
  {
    id: "froid",
    title: "Douche froide",
    detail: "Chaque matin. Sans négocier.",
    icon: "shower",
    cadence: "daily",
  },
  {
    id: "reveil",
    title: "Réveil 5h30",
    detail: "Le jour commence avant le monde.",
    icon: "sunrise",
    cadence: "daily",
  },
  {
    id: "reseaux",
    title: "Zéro réseau social",
    detail: "90 jours hors du bruit.",
    icon: "ban",
    cadence: "daily",
  },
  {
    id: "meditation",
    title: "10 min de silence",
    detail: "Assis. Rien d'autre.",
    icon: "wind",
    cadence: "daily",
  },
  {
    id: "lecture",
    title: "20 pages",
    detail: "Un livre. Pas un écran.",
    icon: "book",
    cadence: "daily",
  },
  {
    id: "etude",
    title: "2 h de travail profond",
    detail: "Téléphone dans une autre pièce.",
    icon: "brain",
    cadence: "daily",
  },
  {
    id: "salle6",
    title: "La salle, 6× par semaine",
    detail: "Un repos. Six séances.",
    icon: "dumbbell",
    cadence: "weekly",
    weeklyTarget: 6,
  },
  {
    id: "course5",
    title: "Courir, 5× par semaine",
    detail: "Endurance avant tout.",
    icon: "run",
    cadence: "weekly",
    weeklyTarget: 5,
  },
  {
    id: "maison",
    title: "Séance à la maison, 4× par semaine",
    detail: "Pompes, squats, gainage. Pas trois. Quatre.",
    icon: "dumbbell",
    cadence: "weekly",
    weeklyTarget: 4,
  },
  {
    id: "maison6",
    title: "Séance à la maison, 6× par semaine",
    detail: "Un repos. Six séances.",
    icon: "dumbbell",
    cadence: "weekly",
    weeklyTarget: 6,
  },
  {
    id: "outdoor",
    title: "Entraînement dehors, 4× par semaine",
    detail: "Barre, parc, escaliers. Pas trois. Quatre.",
    icon: "dumbbell",
    cadence: "weekly",
    weeklyTarget: 4,
  },
  {
    id: "outdoor6",
    title: "Entraînement dehors, 6× par semaine",
    detail: "Un repos. Six séances.",
    icon: "dumbbell",
    cadence: "weekly",
    weeklyTarget: 6,
  },
];

export const RULE_MAP: Record<string, RuleDef> = Object.fromEntries(
  RULES.map((r) => [r.id, r]),
);

export const PROGRAMS: Program[] = [
  {
    id: "classique",
    name: "Classique",
    tagline: "Les 9 règles. Le vrai défi.",
    ruleIds: ["eau", "fastfood", "tel", "salle", "course", "dehors", "gratitude", "pas", "sommeil"],
  },
  {
    id: "hard",
    name: "Mode hard",
    tagline: "Froid, 5h30, zéro réseau.",
    ruleIds: ["eau", "fastfood", "froid", "reveil", "reseaux", "salle", "dehors", "pas", "sommeil"],
  },
  {
    id: "monk",
    name: "Monk mode",
    tagline: "Silence. Méditation. Rien d'autre.",
    ruleIds: ["eau", "reseaux", "meditation", "lecture", "dehors", "gratitude", "pas", "sommeil", "tel"],
  },
  {
    id: "muscu",
    name: "Muscu",
    tagline: "Salle 6×. Sommeil. Eau.",
    ruleIds: ["salle6", "eau", "fastfood", "pas", "sommeil", "dehors", "gratitude", "tel", "froid"],
  },
  {
    id: "course",
    name: "Course",
    tagline: "Cinq sorties. Outdoor. Endurance.",
    ruleIds: ["course5", "pas", "eau", "sommeil", "dehors", "fastfood", "gratitude", "tel", "lecture"],
  },
  {
    id: "etudes",
    name: "Études",
    tagline: "Deux heures profondes. Zéro bruit.",
    ruleIds: ["etude", "lecture", "reseaux", "eau", "sommeil", "dehors", "pas", "gratitude", "tel"],
  },
  {
    id: "froid",
    name: "Tête froide",
    tagline: "Douche froide. Souffle. Journal.",
    ruleIds: ["froid", "meditation", "gratitude", "eau", "dehors", "sommeil", "pas", "tel", "fastfood"],
  },
];

export const PROGRAM_MAP: Record<string, Program> = Object.fromEntries(
  PROGRAMS.map((p) => [p.id, p]),
);

export const QUOTES = [
  "Pendant qu'ils attendent janvier, tu construis.",
  "Le froid ne négocie pas. Toi non plus.",
  "La discipline est le pont entre l'intention et le résultat.",
  "Personne ne vient te sauver. C'est ça, l'arc.",
  "Tu n'as pas besoin d'être motivé. Tu as besoin d'être présent.",
  "Le silence est une arme.",
  "Un jour tenu pèse plus que dix promis.",
  "La version de toi du printemps se décide maintenant.",
  "Ce n'est pas un tracker. C'est un contrat.",
  "Rate, gèle, continue. N'abandonne pas le compte.",
  "Les excuses aiment le confort. Toi, tu as choisi l'hiver.",
  "Neuf règles. Pas une de plus à inventer ce soir.",
  "Le jour 90 regarde le jour 1. Ne le déçois pas.",
  "Moins de bruit. Plus de preuves.",
  "Tu signes. Ensuite tu tiens.",
  "La flamme n'a pas d'opinion. Elle compte.",
  "Travaille en silence. Le résultat parlera.",
  "Un hiver bien tenu rattrape des années molles.",
  "Aujourd'hui compte. Demain n'existe pas encore.",
  "Ce n'est pas de la motivation. C'est de la répétition.",
];

export function quoteForDay(dayNumber: number): string {
  if (dayNumber <= 0) return QUOTES[0];
  return QUOTES[(dayNumber - 1) % QUOTES.length];
}

const TRAINING_SWAP: Record<string, Record<Exclude<TrainingMode, "salle">, string>> = {
  salle: { maison: "maison", dehors: "outdoor" },
  salle6: { maison: "maison6", dehors: "outdoor6" },
};

export function isGymRule(id: string): boolean {
  return id in TRAINING_SWAP;
}

export function applyTraining(ruleIds: string[], mode: TrainingMode): string[] {
  if (mode === "salle") return ruleIds;
  return ruleIds.map((id) => TRAINING_SWAP[id]?.[mode] ?? id);
}
