export type Cadence = "daily" | "weekly";

export type RuleDef = {
  id: string;
  title: string;
  detail: string;
  icon: RuleIcon;
  cadence: Cadence;
  weeklyTarget?: number;
};

export type RuleIcon =
  | "droplet"
  | "utensils"
  | "phone"
  | "dumbbell"
  | "run"
  | "tree"
  | "heart"
  | "footprints"
  | "moon"
  | "shower"
  | "book"
  | "brain"
  | "sunrise"
  | "wind"
  | "ban";

export type ProgramId =
  | "classique"
  | "hard"
  | "monk"
  | "muscu"
  | "course"
  | "etudes"
  | "froid";

export type Program = {
  id: ProgramId;
  name: string;
  tagline: string;
  ruleIds: string[];
};

export type DayLog = {
  date: string;
  checks: Record<string, boolean>;
  gratitude?: string;
};

export type WeekMark = "complete" | "frozen" | "failed" | "current" | "upcoming";

export type PhotoVault = {
  day1?: string;
  day90?: string;
};

export type TrainingMode = "salle" | "maison" | "dehors";

export type Arc = {
  startDate: string;
  signedAt: string;
  signerName: string;
  signatureData?: string;
  programId: ProgramId;
  training?: TrainingMode;
  ruleIds: string[];
  days: Record<string, DayLog>;
  gelUsed: boolean;
  flameOut: boolean;
  iceBroken: boolean;
  photos: PhotoVault;
  demo?: boolean;
};

export type TabId = "jour" | "cases" | "flamme" | "toi";
