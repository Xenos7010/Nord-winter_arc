//#region node_modules/.nitro/vite/services/ssr/assets/_tanstack-start-manifest_v-BG_yc3Pt.js
var tsrStartManifest = () => ({ routes: {
	__root__: {
		filePath: "/workspace/src/routes/__root.tsx",
		children: ["/"],
		preloads: ["/assets/index-BW08UxwC.js"],
		scripts: [{ attrs: {
			type: "module",
			async: !0,
			src: "/assets/index-BW08UxwC.js"
		} }]
	},
	"/": {
		filePath: "/workspace/src/routes/index.tsx",
		children: void 0,
		preloads: ["/assets/routes-BbklMD2E.js"]
	}
} });
//#endregion
export { tsrStartManifest };
