import { i as __toESM } from "../_runtime.mjs";
import { q as require_react, x as require_jsx_runtime } from "../_libs/@tanstack/react-router+[...].mjs";
import { C as ArrowLeft, S as Ban, _ as Droplets, a as Trees, b as Brain, c as Smartphone, d as Lock, f as Heart, g as Dumbbell, h as Flame, l as PersonStanding, m as Footprints, n as UtensilsCrossed, o as Sun, p as Grid2x2, r as User, s as Snowflake, t as Wind, u as Moon, v as Check, x as BookOpen, y as Camera } from "../_libs/lucide-react.mjs";
import { n as toast } from "../_libs/sonner.mjs";
import { t as clsx } from "../_libs/clsx.mjs";
import { t as twMerge } from "../_libs/tailwind-merge.mjs";
import { n as create, t as persist } from "../_libs/zustand.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/routes-D3zSDh4Y.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
var RULE_MAP = Object.fromEntries([
	{
		id: "eau",
		title: "Que de l'eau",
		detail: "Ni soda, ni alcool, ni jus.",
		icon: "droplet",
		cadence: "daily"
	},
	{
		id: "fastfood",
		title: "Zéro fast-food",
		detail: "Ça attendra le jour 91.",
		icon: "utensils",
		cadence: "daily"
	},
	{
		id: "tel",
		title: "Pas de téléphone à table",
		detail: "Tu manges. C'est tout.",
		icon: "phone",
		cadence: "daily"
	},
	{
		id: "salle",
		title: "La salle, 4× par semaine",
		detail: "Pas trois. Quatre.",
		icon: "dumbbell",
		cadence: "weekly",
		weeklyTarget: 4
	},
	{
		id: "course",
		title: "Courir, 2× par semaine",
		detail: "Même lentement. Même sous la pluie.",
		icon: "run",
		cadence: "weekly",
		weeklyTarget: 2
	},
	{
		id: "dehors",
		title: "20 minutes dehors",
		detail: "Tous les jours. Surtout en hiver.",
		icon: "tree",
		cadence: "daily"
	},
	{
		id: "gratitude",
		title: "Gratitude",
		detail: "Une chose, chaque soir.",
		icon: "heart",
		cadence: "daily"
	},
	{
		id: "pas",
		title: "10 000 pas",
		detail: "Chaque jour. Tu valides quand c'est fait.",
		icon: "footprints",
		cadence: "daily"
	},
	{
		id: "sommeil",
		title: "7 à 8 h de sommeil",
		detail: "Le vrai secret. Couche-toi.",
		icon: "moon",
		cadence: "daily"
	},
	{
		id: "froid",
		title: "Douche froide",
		detail: "Chaque matin. Sans négocier.",
		icon: "shower",
		cadence: "daily"
	},
	{
		id: "reveil",
		title: "Réveil 5h30",
		detail: "Le jour commence avant le monde.",
		icon: "sunrise",
		cadence: "daily"
	},
	{
		id: "reseaux",
		title: "Zéro réseau social",
		detail: "90 jours hors du bruit.",
		icon: "ban",
		cadence: "daily"
	},
	{
		id: "meditation",
		title: "10 min de silence",
		detail: "Assis. Rien d'autre.",
		icon: "wind",
		cadence: "daily"
	},
	{
		id: "lecture",
		title: "20 pages",
		detail: "Un livre. Pas un écran.",
		icon: "book",
		cadence: "daily"
	},
	{
		id: "etude",
		title: "2 h de travail profond",
		detail: "Téléphone dans une autre pièce.",
		icon: "brain",
		cadence: "daily"
	},
	{
		id: "salle6",
		title: "La salle, 6× par semaine",
		detail: "Un repos. Six séances.",
		icon: "dumbbell",
		cadence: "weekly",
		weeklyTarget: 6
	},
	{
		id: "course5",
		title: "Courir, 5× par semaine",
		detail: "Endurance avant tout.",
		icon: "run",
		cadence: "weekly",
		weeklyTarget: 5
	}
].map((r) => [r.id, r]));
var PROGRAMS = [
	{
		id: "classique",
		name: "Classique",
		tagline: "Les 9 règles. Le vrai défi.",
		ruleIds: [
			"eau",
			"fastfood",
			"tel",
			"salle",
			"course",
			"dehors",
			"gratitude",
			"pas",
			"sommeil"
		]
	},
	{
		id: "hard",
		name: "Mode hard",
		tagline: "Froid, 5h30, zéro réseau.",
		ruleIds: [
			"eau",
			"fastfood",
			"froid",
			"reveil",
			"reseaux",
			"salle",
			"dehors",
			"pas",
			"sommeil"
		]
	},
	{
		id: "monk",
		name: "Monk mode",
		tagline: "Silence. Méditation. Rien d'autre.",
		ruleIds: [
			"eau",
			"reseaux",
			"meditation",
			"lecture",
			"dehors",
			"gratitude",
			"pas",
			"sommeil",
			"tel"
		]
	},
	{
		id: "muscu",
		name: "Muscu",
		tagline: "Salle 6×. Sommeil. Eau.",
		ruleIds: [
			"salle6",
			"eau",
			"fastfood",
			"pas",
			"sommeil",
			"dehors",
			"gratitude",
			"tel",
			"froid"
		]
	},
	{
		id: "course",
		name: "Course",
		tagline: "Cinq sorties. Outdoor. Endurance.",
		ruleIds: [
			"course5",
			"pas",
			"eau",
			"sommeil",
			"dehors",
			"fastfood",
			"gratitude",
			"tel",
			"lecture"
		]
	},
	{
		id: "etudes",
		name: "Études",
		tagline: "Deux heures profondes. Zéro bruit.",
		ruleIds: [
			"etude",
			"lecture",
			"reseaux",
			"eau",
			"sommeil",
			"dehors",
			"pas",
			"gratitude",
			"tel"
		]
	},
	{
		id: "froid",
		name: "Tête froide",
		tagline: "Douche froide. Souffle. Journal.",
		ruleIds: [
			"froid",
			"meditation",
			"gratitude",
			"eau",
			"dehors",
			"sommeil",
			"pas",
			"tel",
			"fastfood"
		]
	}
];
var PROGRAM_MAP = Object.fromEntries(PROGRAMS.map((p) => [p.id, p]));
var QUOTES = [
	"Pendant qu'ils attendent janvier, tu construis.",
	"Le froid ne négocie pas. Toi non plus.",
	"La discipline est le pont entre l'intention et le résultat.",
	"Personne ne vient te sauver. C'est ça, l'arc.",
	"Tu n'as pas besoin d'être motivé. Tu as besoin d'être présent.",
	"Le silence est une arme.",
	"Un jour tenu pèse plus que dix promis.",
	"La version de toi du printemps se décide maintenant.",
	"Ce n'est pas un tracker. C'est un contrat.",
	"Rate, gèle, continue. N'abandonne pas le compte.",
	"Les excuses aiment le confort. Toi, tu as choisi l'hiver.",
	"Neuf règles. Pas une de plus à inventer ce soir.",
	"Le jour 90 regarde le jour 1. Ne le déçois pas.",
	"Moins de bruit. Plus de preuves.",
	"Tu signes. Ensuite tu tiens.",
	"La flamme n'a pas d'opinion. Elle compte.",
	"Travaille en silence. Le résultat parlera.",
	"Un hiver bien tenu rattrape des années molles.",
	"Aujourd'hui compte. Demain n'existe pas encore.",
	"Ce n'est pas de la motivation. C'est de la répétition."
];
function quoteForDay(dayNumber) {
	if (dayNumber <= 0) return QUOTES[0];
	return QUOTES[(dayNumber - 1) % QUOTES.length];
}
function cn(...inputs) {
	return twMerge(clsx(inputs));
}
function todayISO(d = /* @__PURE__ */ new Date()) {
	return `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, "0")}-${String(d.getDate()).padStart(2, "0")}`;
}
function parseISODate(iso) {
	const [y, m, d] = iso.split("-").map(Number);
	return new Date(y, m - 1, d);
}
function addDaysISO(iso, days) {
	const d = parseISODate(iso);
	d.setDate(d.getDate() + days);
	return todayISO(d);
}
function diffDays(fromISO, toISO) {
	const a = parseISODate(fromISO);
	const b = parseISODate(toISO);
	return Math.round((b.getTime() - a.getTime()) / 864e5);
}
function formatFr(iso, opts) {
	return parseISODate(iso).toLocaleDateString("fr-FR", opts ?? {
		weekday: "long",
		day: "numeric",
		month: "long"
	});
}
function nextMondayISO(from = /* @__PURE__ */ new Date()) {
	const d = new Date(from.getFullYear(), from.getMonth(), from.getDate());
	const day = d.getDay();
	const add = day === 1 ? 7 : (8 - day) % 7 || 7;
	d.setDate(d.getDate() + add);
	return todayISO(d);
}
function officialStartISO() {
	const year = (/* @__PURE__ */ new Date()).getFullYear();
	const oct1 = `${year}-10-01`;
	if (diffDays(todayISO(), oct1) >= 0) return oct1;
	return `${year + 1}-10-01`;
}
async function compressImage(file, max = 720, quality = .7) {
	const bitmap = await createImageBitmap(file);
	const scale = Math.min(1, max / Math.max(bitmap.width, bitmap.height));
	const w = Math.round(bitmap.width * scale);
	const h = Math.round(bitmap.height * scale);
	const canvas = document.createElement("canvas");
	canvas.width = w;
	canvas.height = h;
	const ctx = canvas.getContext("2d");
	if (!ctx) throw new Error("canvas");
	ctx.drawImage(bitmap, 0, 0, w, h);
	bitmap.close();
	return canvas.toDataURL("image/jpeg", quality);
}
function rulesOf(arc) {
	return arc.ruleIds.map((id) => RULE_MAP[id]).filter(Boolean);
}
function dayNumber(arc, iso = todayISO()) {
	return diffDays(arc.startDate, iso) + 1;
}
function isoForDay(arc, n) {
	return addDaysISO(arc.startDate, n - 1);
}
function isBeforeStart(arc, iso = todayISO()) {
	return diffDays(arc.startDate, iso) < 0;
}
function isComplete(arc, iso = todayISO()) {
	return dayNumber(arc, iso) > 90;
}
function dailyRules(rules) {
	return rules.filter((r) => r.cadence === "daily");
}
function weeklyRules(rules) {
	return rules.filter((r) => r.cadence === "weekly");
}
function emptyLog(date) {
	return {
		date,
		checks: {}
	};
}
function logFor(arc, iso) {
	return arc.days[iso] ?? emptyLog(iso);
}
function isRuleChecked(arc, iso, ruleId) {
	return Boolean(arc.days[iso]?.checks[ruleId]);
}
function dayScore(arc, iso) {
	const rules = rulesOf(arc);
	const log = logFor(arc, iso);
	return {
		done: rules.filter((r) => log.checks[r.id]).length,
		total: rules.length
	};
}
function isDayFull(arc, iso) {
	const dailies = dailyRules(rulesOf(arc));
	if (dailies.length === 0) return false;
	const log = logFor(arc, iso);
	return dailies.every((r) => log.checks[r.id]);
}
function weekIndexForDay(dayN) {
	return Math.floor((dayN - 1) / 7);
}
function weekCount(arc) {
	return Math.ceil(90 / 7);
}
function daysInWeek(arc, weekIndex) {
	const start = weekIndex * 7 + 1;
	const end = Math.min(90, start + 6);
	const out = [];
	for (let n = start; n <= end; n++) out.push(isoForDay(arc, n));
	return out;
}
function weeklyProgress(arc, weekIndex, rule) {
	const target = rule.weeklyTarget ?? 1;
	return {
		done: daysInWeek(arc, weekIndex).filter((iso) => isRuleChecked(arc, iso, rule.id)).length,
		target
	};
}
function isWeekComplete(arc, weekIndex) {
	if (!daysInWeek(arc, weekIndex).every((iso) => isDayFull(arc, iso))) return false;
	return weeklyRules(rulesOf(arc)).every((r) => {
		const { done, target } = weeklyProgress(arc, weekIndex, r);
		return done >= target;
	});
}
function evaluateWeeks(arc, iso = todayISO()) {
	const todayN = dayNumber(arc, iso);
	const totalWeeks = weekCount(arc);
	const currentWeek = todayN <= 0 ? -1 : weekIndexForDay(Math.min(todayN, 90));
	const weeks = [];
	let gelUsed = false;
	let flameOut = false;
	let flame = 0;
	for (let i = 0; i < totalWeeks; i++) {
		const days = daysInWeek(arc, i).map((d) => {
			const n = dayNumber(arc, d);
			const future = todayN > 0 ? n > todayN : true;
			const full = !future && isDayFull(arc, d);
			return {
				iso: d,
				n,
				full,
				incomplete: !future && !full && Boolean(arc.days[d]) || !future && !full,
				future
			};
		});
		let mark;
		if (todayN <= 0 || i > currentWeek) mark = "upcoming";
		else if (i === currentWeek && todayN <= 90) mark = "current";
		else if (isWeekComplete(arc, i)) {
			mark = "complete";
			flame += 1;
		} else if (!gelUsed && !flameOut) {
			mark = "frozen";
			gelUsed = true;
		} else {
			mark = "failed";
			flameOut = true;
		}
		weeks.push({
			index: i,
			mark,
			days
		});
	}
	return {
		weeks,
		flame,
		gelUsed,
		flameOut
	};
}
function msUntil(iso) {
	return parseISODateMidnight(iso).getTime() - Date.now();
}
function parseISODateMidnight(iso) {
	const [y, m, d] = iso.split("-").map(Number);
	return new Date(y, m - 1, d, 0, 0, 0, 0);
}
function splitCountdown(ms) {
	const s = Math.floor(Math.max(0, ms) / 1e3);
	return {
		d: Math.floor(s / 86400),
		h: Math.floor(s % 86400 / 3600),
		m: Math.floor(s % 3600 / 60),
		s: s % 60
	};
}
var defaultDraft = () => ({
	programId: "classique",
	startDate: todayISO(),
	signerName: ""
});
function applyWeekFlags(arc) {
	const { gelUsed, flameOut } = evaluateWeeks(arc);
	if (arc.gelUsed === gelUsed && arc.flameOut === flameOut) return arc;
	return {
		...arc,
		gelUsed,
		flameOut
	};
}
function demoArc() {
	const start = addDaysISO(todayISO(), -46);
	const program = PROGRAM_MAP.classique;
	const days = {};
	for (let n = 1; n <= 46; n++) {
		const iso = addDaysISO(start, n - 1);
		const missDay = Math.floor((n - 1) / 7) === 2 && (n === 16 || n === 17);
		const checks = {};
		for (const id of program.ruleIds) {
			const ruleWeekly = id === "salle" || id === "course";
			if (missDay) {
				checks[id] = id === "eau" || id === "pas";
				continue;
			}
			if (ruleWeekly) {
				const dayInWeek = (n - 1) % 7;
				if (id === "salle") checks[id] = dayInWeek < 4;
				if (id === "course") checks[id] = dayInWeek === 1 || dayInWeek === 4;
			} else checks[id] = true;
		}
		days[iso] = {
			date: iso,
			checks,
			gratitude: missDay ? void 0 : "J'ai tenu. C'est déjà ça."
		};
	}
	return applyWeekFlags({
		startDate: start,
		signedAt: start,
		signerName: "Démo",
		programId: "classique",
		ruleIds: program.ruleIds,
		days,
		gelUsed: false,
		flameOut: false,
		iceBroken: true,
		photos: {},
		demo: true
	});
}
var useArcStore = create()(persist((set, get) => ({
	hydrated: false,
	arc: null,
	tab: "jour",
	draft: defaultDraft(),
	setHydrated: () => set({ hydrated: true }),
	setTab: (tab) => set({ tab }),
	setDraft: (partial) => set({ draft: {
		...get().draft,
		...partial
	} }),
	sign: () => {
		const { draft } = get();
		const program = PROGRAM_MAP[draft.programId] ?? PROGRAM_MAP.classique;
		const startDate = draft.startDate || todayISO();
		set({
			arc: {
				startDate,
				signedAt: todayISO(),
				signerName: draft.signerName.trim() || "Anonyme",
				signatureData: draft.signatureData,
				programId: program.id,
				ruleIds: program.ruleIds,
				days: {},
				gelUsed: false,
				flameOut: false,
				iceBroken: startDate < todayISO(),
				photos: {}
			},
			tab: "jour",
			draft: defaultDraft()
		});
	},
	loadDemo: () => set({
		arc: demoArc(),
		tab: "jour"
	}),
	toggleCheck: (iso, ruleId) => {
		const arc = get().arc;
		if (!arc) return;
		const prev = arc.days[iso] ?? {
			date: iso,
			checks: {}
		};
		const nextChecked = !prev.checks[ruleId];
		const checks = {
			...prev.checks,
			[ruleId]: nextChecked
		};
		const days = {
			...arc.days,
			[iso]: {
				...prev,
				checks
			}
		};
		set({ arc: applyWeekFlags({
			...arc,
			days
		}) });
	},
	setGratitude: (iso, text) => {
		const arc = get().arc;
		if (!arc) return;
		const prev = arc.days[iso] ?? {
			date: iso,
			checks: {}
		};
		const checks = {
			...prev.checks,
			gratitude: true
		};
		const days = {
			...arc.days,
			[iso]: {
				...prev,
				checks,
				gratitude: text.trim()
			}
		};
		set({ arc: applyWeekFlags({
			...arc,
			days
		}) });
	},
	setPhoto: (slot, dataUrl) => {
		const arc = get().arc;
		if (!arc) return;
		set({ arc: {
			...arc,
			photos: {
				...arc.photos,
				[slot]: dataUrl
			}
		} });
	},
	breakIce: () => {
		const arc = get().arc;
		if (!arc) return;
		set({ arc: {
			...arc,
			iceBroken: true
		} });
	},
	reset: () => set({
		arc: null,
		tab: "jour",
		draft: defaultDraft()
	})
}), {
	name: "nord-arc-v1",
	partialize: (s) => ({ arc: s.arc }),
	skipHydration: true
}));
function Frame({ children, className }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: "min-h-dvh bg-bg md:flex md:items-center md:justify-center md:bg-[#040506] md:p-6",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: cn("relative mx-auto flex min-h-dvh w-full max-w-[430px] flex-col overflow-hidden bg-bg grain", "md:min-h-[844px] md:max-h-[844px] md:rounded-[2.5rem] md:border md:border-line md:shadow-[0_40px_80px_-20px_rgba(0,0,0,0.7)]", className),
			children
		})
	});
}
function Complete({ arc }) {
	const reset = useArcStore((s) => s.reset);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Frame, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "relative z-[1] flex min-h-dvh flex-col px-6 pb-[max(1.5rem,env(safe-area-inset-bottom))] pt-[max(2rem,env(safe-area-inset-top))] md:min-h-[844px]",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-[11px] tracking-[0.24em] text-ice uppercase",
				children: "Jour 90"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
				className: "mt-3 font-serif text-[2.6rem] leading-tight tracking-tight",
				children: "Voilà ce que 90 jours ont changé."
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mt-8 grid flex-1 grid-cols-2 gap-3",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("figure", {
					className: "overflow-hidden rounded-lg bg-raised",
					children: [arc.photos.day1 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
						src: arc.photos.day1,
						alt: "Jour 1",
						className: "h-full min-h-48 w-full object-cover"
					}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "grid h-full min-h-48 place-items-center text-[12px] text-faint",
						children: "Pas de photo jour 1"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("figcaption", {
						className: "px-3 py-2 text-[12px] text-muted",
						children: "Jour 1"
					})]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("figure", {
					className: "overflow-hidden rounded-lg bg-raised",
					children: [arc.photos.day90 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
						src: arc.photos.day90,
						alt: "Jour 90",
						className: "h-full min-h-48 w-full object-cover"
					}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "grid h-full min-h-48 place-items-center text-[12px] text-faint",
						children: "Pas de photo jour 90"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("figcaption", {
						className: "px-3 py-2 text-[12px] text-muted",
						children: "Jour 90"
					})]
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
				className: "mt-6 text-[14px] text-muted",
				children: [arc.signerName, ". Un autre arc peut commencer quand tu veux."]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
				type: "button",
				onClick: reset,
				className: "mt-6 flex h-14 items-center justify-center rounded-[18px] bg-fg text-[15px] font-medium text-bg",
				children: "Nouvel arc"
			})
		]
	}) });
}
function Countdown({ arc, onReset }) {
	const [, setNow] = (0, import_react.useState)(() => Date.now());
	(0, import_react.useEffect)(() => {
		const id = window.setInterval(() => setNow(Date.now()), 1e3);
		return () => window.clearInterval(id);
	}, []);
	const live = splitCountdown(msUntil(arc.startDate));
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Frame, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "relative z-[1] flex min-h-dvh flex-col px-6 pb-[max(1.5rem,env(safe-area-inset-bottom))] pt-[max(2rem,env(safe-area-inset-top))] md:min-h-[844px]",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-center text-[11px] tracking-[0.24em] text-ice uppercase",
				children: "Avant le départ"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("h1", {
				className: "mt-4 text-center font-serif text-[2.4rem] leading-tight tracking-tight",
				children: [
					"Ton arc commence",
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("br", {}),
					formatFr(arc.startDate, {
						weekday: "long",
						day: "numeric",
						month: "long"
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "my-auto grid grid-cols-4 gap-2",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Unit, {
						value: live.d,
						label: "jours"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Unit, {
						value: live.h,
						label: "heures"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Unit, {
						value: live.m,
						label: "min"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Unit, {
						value: live.s,
						label: "sec"
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mb-8 text-center text-[14px] leading-relaxed text-muted",
				children: "Un rappel chaque soir jusqu'au jour 1. Arrive prêt. Le jour J, tu brises la glace."
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
				className: "mb-4 text-center text-[12px] text-faint",
				children: ["Signé par ", arc.signerName]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
				type: "button",
				onClick: onReset,
				className: "h-11 text-[13px] text-muted",
				children: "Annuler le contrat"
			})
		]
	}) });
}
function Unit({ value, label }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "rounded-lg bg-surface px-1 py-4 text-center",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "font-serif text-[2rem] tabular-nums leading-none text-fg",
			children: String(value).padStart(2, "0")
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "mt-2 text-[10px] tracking-[0.16em] text-muted uppercase",
			children: label
		})]
	});
}
function FlameView({ arc }) {
	const { weeks, flame, gelUsed, flameOut } = evaluateWeeks(arc);
	const total = weekCount(arc);
	const frozen = weeks.some((w) => w.mark === "frozen");
	let status = "La flamme grandit avec chaque semaine complète.";
	if (flameOut) status = "La flamme s'est éteinte. L'arc, lui, continue jusqu'au jour 90.";
	else if (frozen) status = "Le gel la couvre. Une seule fois. La prochaine, elle s'éteint.";
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "flex flex-1 flex-col overflow-y-auto px-5 pb-28 pt-[max(1.25rem,env(safe-area-inset-top))]",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-[11px] tracking-[0.22em] text-muted uppercase",
				children: "La flamme"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
				className: "mt-2 font-serif text-[2.4rem] leading-tight tracking-tight",
				children: flameOut ? "Éteinte." : frozen ? "Gelée." : "Elle ne pardonne qu'une fois."
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-3 max-w-[22rem] text-[14px] leading-relaxed text-muted",
				children: status
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "relative mx-auto my-10 grid place-items-center",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
					className: cn("absolute size-40 rounded-full blur-3xl", flameOut ? "bg-faint/20" : frozen ? "bg-ice/25" : "bg-ember/25"),
					style: flameOut ? void 0 : { animation: "flame-pulse 2.6s ease-in-out infinite" }
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(FlameMark, {
					level: flame,
					out: flameOut,
					frozen
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "text-center",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "font-serif text-[3rem] leading-none tabular-nums",
					children: flame
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "mt-1 text-[12px] tracking-[0.16em] text-muted uppercase",
					children: [
						"semaines allumées · ",
						total,
						" au total"
					]
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("ul", {
				className: "mt-10 space-y-3 text-[13px] text-muted",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
						className: "flex justify-between border-b border-line pb-3",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "Gel utilisé" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "text-fg",
							children: gelUsed ? "Oui" : "Pas encore"
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
						className: "flex justify-between border-b border-line pb-3",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "Semaines validées" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "text-fg tabular-nums",
							children: flame
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
						className: "flex justify-between",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "État" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "text-fg",
							children: flameOut ? "Éteinte" : frozen ? "Couverte par le gel" : "Vivante"
						})]
					})
				]
			})
		]
	});
}
function FlameMark({ level, out, frozen }) {
	const fill = out ? "#5c5852" : frozen ? "#9bb4c0" : "#d4894a";
	const h = 28 + Math.min(13, level) * 6;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("svg", {
		width: "120",
		height: "150",
		viewBox: "0 0 120 150",
		className: "relative",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("path", {
			d: `M60 ${150 - h} C78 ${150 - h + 18} 96 ${150 - h / 2} 88 128 C110 118 108 92 84 78 C90 52 74 ${150 - h + 8} 60 ${150 - h} C46 ${150 - h + 8} 30 52 36 78 C12 92 10 118 32 128 C24 ${150 - h / 2} 42 ${150 - h + 18} 60 ${150 - h} Z`,
			fill,
			fillOpacity: out ? .35 : .92
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("path", {
			d: `M60 ${150 - h + 22} C70 ${150 - h + 36} 78 118 70 128 C76 124 74 110 60 ${150 - h + 22} C46 110 44 124 50 128 C42 118 50 ${150 - h + 36} 60 ${150 - h + 22} Z`,
			fill: out ? "#3a3836" : frozen ? "#d7e6ee" : "#f2efe8",
			fillOpacity: .85
		})]
	});
}
function Grid90({ arc }) {
	const iso = todayISO();
	const n = dayNumber(arc, iso);
	const evalw = evaluateWeeks(arc, iso);
	const [picked, setPicked] = (0, import_react.useState)(null);
	const pickedIso = picked ? isoForDay(arc, picked) : null;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "flex flex-1 flex-col overflow-y-auto px-5 pb-28 pt-[max(1.25rem,env(safe-area-inset-top))]",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-[11px] tracking-[0.22em] text-muted uppercase",
				children: "90 cases"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("h1", {
				className: "mt-2 font-serif text-[2.4rem] leading-tight tracking-tight",
				children: [
					"Plus tu tiens,",
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("br", {}),
					"plus elles s'allument."
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "mt-6 grid grid-cols-10 gap-1.5",
				children: Array.from({ length: 90 }, (_, i) => {
					const day = i + 1;
					const dIso = isoForDay(arc, day);
					const future = n > 0 ? day > n : true;
					const full = !future && isDayFull(arc, dIso);
					const started = !future && Boolean(arc.days[dIso]);
					return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						type: "button",
						onClick: () => setPicked(day),
						"aria-label": `Jour ${day}`,
						className: cn("aspect-square rounded-[5px] transition-transform duration-150 active:scale-[0.96]", full && "bg-ok", !full && started && "bg-ember/80", future && "bg-raised", !future && !full && !started && "bg-line", picked === day && "ring-1 ring-fg")
					}, day);
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mt-6 flex flex-wrap gap-x-4 gap-y-2 text-[11px] text-muted",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Legend, {
						swatch: "bg-ok",
						label: "Journée pleine"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Legend, {
						swatch: "bg-ember/80",
						label: "Incomplète"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Legend, {
						swatch: "bg-raised",
						label: "À venir"
					})
				]
			}),
			picked && pickedIso && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mt-6 rounded-lg border border-line bg-surface px-4 py-4",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "text-[12px] text-muted",
					children: [
						"Jour ",
						picked,
						" · ",
						formatFr(pickedIso)
					]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "mt-1 text-[15px]",
					children: n > 0 && picked > n ? "Pas encore." : isDayFull(arc, pickedIso) ? "Journée pleine." : arc.days[pickedIso] ? "Journée incomplète." : "Rien de validé."
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mt-8",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mb-3 text-[11px] tracking-[0.2em] text-muted uppercase",
					children: "Semaines"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
					className: "space-y-2",
					children: evalw.weeks.map((w) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
						className: "flex items-center justify-between text-[13px]",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", { children: ["Semaine ", w.index + 1] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: cn("text-[12px]", w.mark === "complete" && "text-ok", w.mark === "frozen" && "text-ice", w.mark === "failed" && "text-danger", w.mark === "current" && "text-fg", w.mark === "upcoming" && "text-faint"),
							children: weekLabel(w.mark)
						})]
					}, w.index))
				})]
			})
		]
	});
}
function Legend({ swatch, label }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
		className: "inline-flex items-center gap-2",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { className: cn("size-2.5 rounded-[3px]", swatch) }), label]
	});
}
function weekLabel(mark) {
	if (mark === "complete") return "Validée";
	if (mark === "frozen") return "Gelée";
	if (mark === "failed") return "Ratée";
	if (mark === "current") return "En cours";
	return "—";
}
function IceBreak({ onBroken }) {
	const [taps, setTaps] = (0, import_react.useState)(0);
	const [leaving, setLeaving] = (0, import_react.useState)(false);
	function tap() {
		if (leaving) return;
		const next = taps + 1;
		setTaps(next);
		if (next >= 3) {
			setLeaving(true);
			window.setTimeout(onBroken, 700);
		}
	}
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Frame, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
		type: "button",
		onClick: tap,
		className: "relative z-[1] flex min-h-dvh w-full flex-col items-center justify-center px-6 text-center md:min-h-[844px]",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "pointer-events-none absolute inset-0",
				style: {
					background: "radial-gradient(120% 80% at 50% 20%, rgba(155,180,192,0.18), transparent 55%), linear-gradient(180deg, #0c1216, #08090c 70%)",
					opacity: leaving ? 0 : 1,
					transition: "opacity 600ms cubic-bezier(0.22, 1, 0.36, 1)"
				}
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Cracks, {
				taps,
				leaving
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "relative text-[11px] tracking-[0.28em] text-ice uppercase",
				children: "Jour 1"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("h1", {
				className: "relative mt-4 font-serif text-[2.6rem] leading-[1.05] tracking-tight",
				children: [
					"Ton arc est pris",
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("br", {}),
					"dans la glace."
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "relative mt-5 max-w-[16rem] text-[14px] text-muted",
				children: taps >= 3 ? "C'est ouvert." : `Trois taps pour la briser. ${3 - taps} restant${3 - taps > 1 ? "s" : ""}.`
			})
		]
	}) });
}
function Cracks({ taps, leaving }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("svg", {
		className: "pointer-events-none absolute inset-0 h-full w-full",
		viewBox: "0 0 390 844",
		preserveAspectRatio: "xMidYMid slice",
		style: {
			opacity: leaving ? 0 : taps === 0 ? .15 : 1,
			transition: "opacity 600ms ease"
		},
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("path", {
				d: "M200 0 L210 180 L140 310 L250 430 L190 844",
				fill: "none",
				stroke: "#d7e6ee",
				strokeWidth: taps >= 1 ? 1.4 : .4,
				opacity: taps >= 1 ? .7 : .15
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("path", {
				d: "M210 180 L320 220 L390 260",
				fill: "none",
				stroke: "#d7e6ee",
				strokeWidth: taps >= 2 ? 1.2 : 0,
				opacity: taps >= 2 ? .65 : 0
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("path", {
				d: "M140 310 L40 360 L0 400",
				fill: "none",
				stroke: "#d7e6ee",
				strokeWidth: taps >= 2 ? 1.1 : 0,
				opacity: taps >= 2 ? .55 : 0
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("path", {
				d: "M250 430 L340 520 L360 700",
				fill: "none",
				stroke: "#d7e6ee",
				strokeWidth: taps >= 3 ? 1.4 : 0,
				opacity: taps >= 3 ? .75 : 0
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("path", {
				d: "M250 430 L160 560 L80 720",
				fill: "none",
				stroke: "#d7e6ee",
				strokeWidth: taps >= 3 ? 1.3 : 0,
				opacity: taps >= 3 ? .7 : 0
			})
		]
	});
}
var MAP = {
	droplet: Droplets,
	utensils: UtensilsCrossed,
	phone: Smartphone,
	dumbbell: Dumbbell,
	run: PersonStanding,
	tree: Trees,
	heart: Heart,
	footprints: Footprints,
	moon: Moon,
	shower: Snowflake,
	book: BookOpen,
	brain: Brain,
	sunrise: Sun,
	wind: Wind,
	ban: Ban
};
function RuleGlyph({ name, className }) {
	const Icon = MAP[name] ?? Heart;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Icon, {
		className,
		strokeWidth: 1.6
	});
}
function Profile({ arc }) {
	const setPhoto = useArcStore((s) => s.setPhoto);
	const reset = useArcStore((s) => s.reset);
	const n = dayNumber(arc);
	const unlocked = n >= 90;
	const program = PROGRAM_MAP[arc.programId];
	const rules = rulesOf(arc);
	const day1Ref = (0, import_react.useRef)(null);
	const day90Ref = (0, import_react.useRef)(null);
	async function onFile(slot, file) {
		if (!file) return;
		try {
			const data = await compressImage(file);
			setPhoto(slot, data);
			toast(slot === "day1" ? "Photo du jour 1 verrouillée." : "Photo du jour 90 enregistrée.");
		} catch {
			toast("Impossible de lire cette image.");
		}
	}
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "flex flex-1 flex-col overflow-y-auto px-5 pb-28 pt-[max(1.25rem,env(safe-area-inset-top))]",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-[11px] tracking-[0.22em] text-muted uppercase",
				children: "Toi"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
				className: "mt-2 font-serif text-[2.4rem] leading-tight tracking-tight",
				children: arc.signerName
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
				className: "mt-1 text-[13px] text-muted",
				children: [
					program?.name,
					" · départ ",
					formatFr(arc.startDate, {
						day: "numeric",
						month: "long"
					})
				]
			}),
			arc.signatureData && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
				src: arc.signatureData,
				alt: "Signature",
				className: "mt-4 h-14 w-auto max-w-[200px] object-contain opacity-80"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
				className: "mt-8 text-[11px] tracking-[0.2em] text-muted uppercase",
				children: "Jour 1 vs jour 90"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-2 text-[13px] leading-relaxed text-muted",
				children: "La photo du premier jour reste verrouillée jusqu'au jour 90 — même pour toi. Rien ne quitte cet appareil."
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mt-4 grid grid-cols-2 gap-3",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PhotoSlot, {
					label: "Jour 1",
					src: arc.photos.day1,
					locked: Boolean(arc.photos.day1) && !unlocked,
					onPick: () => day1Ref.current?.click()
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(PhotoSlot, {
					label: "Jour 90",
					src: arc.photos.day90,
					locked: false,
					disabled: n < 90 && !arc.photos.day90,
					onPick: () => day90Ref.current?.click()
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
				ref: day1Ref,
				type: "file",
				accept: "image/*",
				capture: "user",
				className: "hidden",
				onChange: (e) => onFile("day1", e.target.files?.[0])
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
				ref: day90Ref,
				type: "file",
				accept: "image/*",
				capture: "user",
				className: "hidden",
				onChange: (e) => onFile("day90", e.target.files?.[0])
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
				className: "mt-10 text-[11px] tracking-[0.2em] text-muted uppercase",
				children: "Le contrat"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
				className: "mt-3 space-y-3",
				children: rules.map((r) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
					className: "flex gap-3",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "mt-0.5 text-ice",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(RuleGlyph, {
							name: r.icon,
							className: "size-4"
						})
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "block text-[14px]",
						children: r.title
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "block text-[12px] text-muted",
						children: r.detail
					})] })]
				}, r.id))
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
				type: "button",
				onClick: () => {
					if (window.confirm("Effacer cet arc et revenir au départ ?")) reset();
				},
				className: "mt-10 h-12 rounded-md border border-line text-[13px] text-muted",
				children: "Terminer / recommencer"
			}),
			arc.demo && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
				className: "mt-3 text-center text-[12px] text-faint",
				children: [
					"Arc de démonstration · jour ",
					Math.min(90, Math.max(1, n)),
					" · ",
					todayISO()
				]
			})
		]
	});
}
function PhotoSlot({ label, src, locked, disabled, onPick }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
		type: "button",
		onClick: onPick,
		disabled,
		className: "relative aspect-[3/4] overflow-hidden rounded-lg bg-raised text-left",
		children: [
			src && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
				src,
				alt: "",
				className: locked ? "h-full w-full object-cover blur-xl scale-110" : "h-full w-full object-cover"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
				className: "absolute inset-x-0 bottom-0 bg-gradient-to-t from-bg/80 to-transparent px-3 py-2 text-[12px]",
				children: label
			}),
			!src && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
				className: "absolute inset-0 grid place-items-center text-faint",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Camera, { className: "size-6" })
			}),
			locked && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
				className: "absolute inset-0 grid place-items-center bg-bg/30",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Lock, { className: "size-6 text-fg" })
			})
		]
	});
}
var TABS = [
	{
		id: "jour",
		label: "Jour",
		icon: Sun
	},
	{
		id: "cases",
		label: "90",
		icon: Grid2x2
	},
	{
		id: "flamme",
		label: "Flamme",
		icon: Flame
	},
	{
		id: "toi",
		label: "Toi",
		icon: User
	}
];
function TabBar({ tab, onChange }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("nav", {
		className: "absolute inset-x-0 bottom-0 z-10 border-t border-line bg-bg/95 pb-[max(0.5rem,env(safe-area-inset-bottom))] pt-1",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
			className: "grid grid-cols-4",
			children: TABS.map((t) => {
				const Icon = t.icon;
				const active = tab === t.id;
				return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
					type: "button",
					onClick: () => onChange(t.id),
					className: cn("flex h-14 w-full flex-col items-center justify-center gap-0.5 text-[10px] tracking-wide", active ? "text-fg" : "text-faint"),
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Icon, {
						className: "size-[18px]",
						strokeWidth: active ? 2 : 1.6
					}), t.label]
				}) }, t.id);
			})
		})
	});
}
var HOLD_MS = 680;
var SIZE = 44;
var R = 16;
var C = 2 * Math.PI * R;
function HoldConfirm({ confirmed, disabled, onConfirm, label }) {
	const [progress, setProgress] = (0, import_react.useState)(0);
	const raf = (0, import_react.useRef)(null);
	const start = (0, import_react.useRef)(0);
	function stop() {
		if (raf.current) cancelAnimationFrame(raf.current);
		raf.current = null;
		setProgress(0);
	}
	function tick(now) {
		const p = Math.min(1, (now - start.current) / HOLD_MS);
		setProgress(p);
		if (p >= 1) {
			stop();
			onConfirm();
			return;
		}
		raf.current = requestAnimationFrame(tick);
	}
	function down(e) {
		if (disabled) return;
		e.preventDefault();
		e.currentTarget.setPointerCapture(e.pointerId);
		start.current = performance.now();
		raf.current = requestAnimationFrame(tick);
	}
	function up() {
		stop();
	}
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
		type: "button",
		"aria-label": label ?? (confirmed ? "Retirer" : "Maintenir pour valider"),
		disabled,
		onPointerDown: down,
		onPointerUp: up,
		onPointerCancel: up,
		onLostPointerCapture: up,
		onContextMenu: (e) => e.preventDefault(),
		className: cn("relative grid size-11 place-items-center rounded-full select-none", "transition-transform duration-150 ease-out active:scale-[0.96]", disabled && "opacity-40"),
		style: { touchAction: "none" },
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("svg", {
			width: SIZE,
			height: SIZE,
			viewBox: "0 0 44 44",
			className: "absolute inset-0",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("circle", {
				cx: "22",
				cy: "22",
				r: R,
				fill: "none",
				className: "stroke-line",
				strokeWidth: "1.5"
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("circle", {
				cx: "22",
				cy: "22",
				r: R,
				fill: "none",
				className: confirmed ? "stroke-ok" : "stroke-ice",
				strokeWidth: "2",
				strokeLinecap: "round",
				strokeDasharray: C,
				strokeDashoffset: confirmed ? 0 : C * (1 - progress),
				transform: "rotate(-90 22 22)"
			})]
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
			className: cn("grid size-7 place-items-center rounded-full transition-[background,color,transform] duration-200", confirmed ? "bg-ok/15 text-ok" : "text-faint"),
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Check, {
				className: "size-3.5",
				strokeWidth: 2.4
			})
		})]
	});
}
function Today({ arc }) {
	const toggleCheck = useArcStore((s) => s.toggleCheck);
	const setGratitude = useArcStore((s) => s.setGratitude);
	const iso = todayISO();
	const n = dayNumber(arc, iso);
	const clamped = Math.min(90, Math.max(1, n));
	const activeIso = n < 1 ? isoForDay(arc, 1) : n > 90 ? isoForDay(arc, 90) : iso;
	const score = dayScore(arc, activeIso);
	const full = isDayFull(arc, activeIso);
	const evalw = evaluateWeeks(arc, iso);
	const weekI = weekIndexForDay(clamped);
	const week = evalw.weeks[weekI];
	const log = arc.days[activeIso];
	const rules = rulesOf(arc);
	const [gratitudeOpen, setGratitudeOpen] = (0, import_react.useState)(false);
	const [gratitudeText, setGratitudeText] = (0, import_react.useState)(log?.gratitude ?? "");
	function handleToggle(rule) {
		if (rule.id === "gratitude" && !log?.checks.gratitude) {
			setGratitudeOpen(true);
			return;
		}
		const wasFull = isDayFull(arc, activeIso);
		toggleCheck(activeIso, rule.id);
		window.setTimeout(() => {
			const snap = useArcStore.getState().arc;
			if (snap && !wasFull && isDayFull(snap, activeIso)) toast("Journée pleine.");
		}, 30);
	}
	function saveGratitude() {
		if (!gratitudeText.trim()) return;
		setGratitude(activeIso, gratitudeText);
		setGratitudeOpen(false);
		toast("Gratitude notée.");
	}
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "flex flex-1 flex-col overflow-hidden",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("header", {
				className: "px-5 pb-4 pt-[max(1.25rem,env(safe-area-inset-top))]",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-[11px] tracking-[0.22em] text-muted uppercase",
						children: formatFr(activeIso)
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "mt-2 flex items-end justify-between gap-4",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("h1", {
							className: "font-serif text-[3.4rem] leading-none tracking-tight",
							children: [clamped, /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "ml-1 text-[1.1rem] text-muted",
								children: "/ 90"
							})]
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "mb-1 text-right",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "text-[13px] tabular-nums text-fg",
								children: [
									score.done,
									" sur ",
									score.total
								]
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "text-[11px] text-muted",
								children: full ? "Journée pleine" : "En cours"
							})]
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-4 max-w-[22rem] text-[13px] leading-relaxed text-muted",
						children: quoteForDay(clamped)
					}),
					week && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "mt-5 flex gap-1.5",
						children: week.days.map((d) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { className: cn("h-1.5 flex-1 rounded-full", d.full ? "bg-ok" : d.future ? "bg-line" : "bg-ember/70") }, d.iso))
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
				className: "flex-1 overflow-y-auto px-4 pb-28",
				children: rules.map((rule) => {
					const checked = Boolean(arc.days[activeIso]?.checks[rule.id]);
					const weekly = rule.cadence === "weekly" ? weeklyProgress(arc, weekI, rule) : null;
					return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
						className: "flex items-center gap-3 border-b border-line py-3 last:border-0",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "grid size-10 shrink-0 place-items-center rounded-md bg-surface text-ice",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(RuleGlyph, {
									name: rule.icon,
									className: "size-[18px]"
								})
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "min-w-0 flex-1",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
									className: "truncate text-[14px] font-medium",
									children: rule.title
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
									className: "truncate text-[12px] text-muted",
									children: weekly ? `${weekly.done} / ${weekly.target} cette semaine` : rule.detail
								})]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(HoldConfirm, {
								confirmed: checked,
								onConfirm: () => handleToggle(rule),
								label: rule.title
							})
						]
					}, rule.id);
				})
			}),
			gratitudeOpen && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "absolute inset-0 z-20 flex items-end bg-bg/70",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "w-full rounded-t-xl border-t border-line bg-surface px-5 pb-[max(1.25rem,env(safe-area-inset-bottom))] pt-5",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
							className: "font-serif text-[1.6rem]",
							children: "Une chose, ce soir."
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("textarea", {
							autoFocus: true,
							value: gratitudeText,
							onChange: (e) => setGratitudeText(e.target.value),
							rows: 3,
							placeholder: "Aujourd'hui je suis reconnaissant pour…",
							className: "mt-3 w-full resize-none rounded-md border border-line bg-raised px-3 py-2.5 text-[14px] text-fg outline-none placeholder:text-faint"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "mt-3 flex gap-2",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
								type: "button",
								onClick: () => setGratitudeOpen(false),
								className: "h-12 flex-1 rounded-md text-[14px] text-muted",
								children: "Plus tard"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
								type: "button",
								onClick: saveGratitude,
								className: "h-12 flex-1 rounded-md bg-fg text-[14px] font-medium text-bg",
								children: "Valider"
							})]
						})
					]
				})
			})
		]
	});
}
function AppShell({ arc }) {
	const tab = useArcStore((s) => s.tab);
	const setTab = useArcStore((s) => s.setTab);
	const breakIce = useArcStore((s) => s.breakIce);
	const reset = useArcStore((s) => s.reset);
	const [, setTick] = (0, import_react.useState)(0);
	(0, import_react.useEffect)(() => {
		const id = window.setInterval(() => setTick((n) => n + 1), 1e3);
		return () => window.clearInterval(id);
	}, []);
	if (isBeforeStart(arc)) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Countdown, {
		arc,
		onReset: reset
	});
	const n = dayNumber(arc);
	if (n >= 1 && n <= 90 && !arc.iceBroken) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(IceBreak, { onBroken: breakIce });
	if (isComplete(arc)) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Complete, { arc });
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Frame, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "relative z-[1] flex min-h-dvh flex-1 flex-col md:min-h-[844px]",
		children: [
			tab === "jour" && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Today, { arc }),
			tab === "cases" && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Grid90, { arc }),
			tab === "flamme" && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(FlameView, { arc }),
			tab === "toi" && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Profile, { arc }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TabBar, {
				tab,
				onChange: setTab
			})
		]
	}) });
}
function Landing({ onStart, onDemo }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Frame, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "relative z-[1] flex min-h-dvh flex-col px-6 pb-[max(1.5rem,env(safe-area-inset-bottom))] pt-[max(2.5rem,env(safe-area-inset-top))] md:min-h-[844px]",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("header", {
				className: "flex items-center justify-between text-[11px] tracking-[0.22em] text-muted uppercase",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "NORD" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "Défi 90 jours" })]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "stagger-in flex flex-1 flex-col justify-center",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "mb-8 flex justify-center",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
							className: "relative grid size-16 place-items-center",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "absolute inset-0 rounded-full bg-ember/20 blur-xl",
								style: { animation: "flame-pulse 2.8s ease-in-out infinite" }
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Flame, {
								className: "relative size-9 text-ember",
								strokeWidth: 1.4,
								fill: "currentColor",
								fillOpacity: .25
							})]
						})
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mb-3 text-center text-[11px] tracking-[0.28em] text-ice uppercase",
						children: "L'hiver ne t'attendra pas"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("h1", {
						className: "font-serif text-[3.15rem] leading-[0.95] tracking-tight text-fg text-center",
						children: [
							"90 jours.",
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("br", {}),
							"9 règles.",
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("br", {}),
							"Zéro excuse."
						]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mx-auto mt-6 max-w-[18rem] text-center text-[15px] leading-relaxed text-muted",
						children: "Tu signes un contrat. Tu valides chaque soir. Ta discipline se construit case après case."
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "space-y-3",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						type: "button",
						onClick: onStart,
						className: "flex h-14 w-full items-center justify-center rounded-[18px] bg-fg text-[15px] font-medium text-bg transition-transform duration-150 ease-out active:scale-[0.96]",
						children: "Signer mon contrat"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						type: "button",
						onClick: onDemo,
						className: "flex h-12 w-full items-center justify-center rounded-[18px] border border-line text-[14px] text-muted transition-transform duration-150 ease-out active:scale-[0.96]",
						children: "Voir un arc au jour 47"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "pt-1 text-center text-[11px] text-faint",
						children: "Gratuit. Sans compte. Tes photos restent ici."
					})
				]
			})
		]
	}) });
}
function SignaturePad({ value, onChange, className }) {
	const canvasRef = (0, import_react.useRef)(null);
	const drawing = (0, import_react.useRef)(false);
	const last = (0, import_react.useRef)(null);
	(0, import_react.useEffect)(() => {
		const canvas = canvasRef.current;
		if (!canvas) return;
		const dpr = Math.min(2, window.devicePixelRatio || 1);
		const rect = canvas.getBoundingClientRect();
		canvas.width = Math.floor(rect.width * dpr);
		canvas.height = Math.floor(rect.height * dpr);
		const ctx = canvas.getContext("2d");
		if (!ctx) return;
		ctx.scale(dpr, dpr);
		ctx.lineWidth = 1.8;
		ctx.lineCap = "round";
		ctx.lineJoin = "round";
		ctx.strokeStyle = "#f2efe8";
		if (value) {
			const img = new Image();
			img.onload = () => ctx.drawImage(img, 0, 0, rect.width, rect.height);
			img.src = value;
		}
	}, []);
	function pos(e) {
		const r = canvasRef.current.getBoundingClientRect();
		return {
			x: e.clientX - r.left,
			y: e.clientY - r.top
		};
	}
	function down(e) {
		drawing.current = true;
		last.current = pos(e);
		e.currentTarget.setPointerCapture(e.pointerId);
	}
	function move(e) {
		if (!drawing.current || !last.current) return;
		const ctx = canvasRef.current?.getContext("2d");
		if (!ctx) return;
		const p = pos(e);
		ctx.beginPath();
		ctx.moveTo(last.current.x, last.current.y);
		ctx.lineTo(p.x, p.y);
		ctx.stroke();
		last.current = p;
	}
	function up() {
		drawing.current = false;
		last.current = null;
		const canvas = canvasRef.current;
		if (canvas) onChange(canvas.toDataURL("image/png"));
	}
	function clear() {
		const canvas = canvasRef.current;
		const ctx = canvas?.getContext("2d");
		if (!canvas || !ctx) return;
		ctx.save();
		ctx.setTransform(1, 0, 0, 1, 0, 0);
		ctx.clearRect(0, 0, canvas.width, canvas.height);
		ctx.restore();
		onChange("");
	}
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: cn("space-y-2", className),
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("canvas", {
			ref: canvasRef,
			onPointerDown: down,
			onPointerMove: move,
			onPointerUp: up,
			onPointerCancel: up,
			className: "h-28 w-full rounded-md bg-raised touch-none"
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
			type: "button",
			onClick: clear,
			className: "text-[12px] text-muted underline-offset-2 hover:text-fg",
			children: "Effacer la signature"
		})]
	});
}
function Onboarding({ onCancel }) {
	const [step, setStep] = (0, import_react.useState)(0);
	const draft = useArcStore((s) => s.draft);
	const setDraft = useArcStore((s) => s.setDraft);
	const sign = useArcStore((s) => s.sign);
	const program = PROGRAM_MAP[draft.programId];
	const rules = program.ruleIds.map((id) => RULE_MAP[id]);
	const oct1 = officialStartISO();
	const today = todayISO();
	const monday = nextMondayISO();
	function next() {
		if (step < 4) setStep(step + 1);
		else sign();
	}
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Frame, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "relative z-[1] flex min-h-dvh flex-col px-6 pb-[max(1.25rem,env(safe-area-inset-bottom))] pt-[max(1.25rem,env(safe-area-inset-top))] md:min-h-[844px]",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("header", {
				className: "mb-6 flex items-center justify-between",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						type: "button",
						onClick: () => step === 0 ? onCancel() : setStep(step - 1),
						className: "grid size-11 place-items-center rounded-full text-muted transition-transform duration-150 active:scale-[0.96]",
						"aria-label": "Retour",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ArrowLeft, { className: "size-5" })
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "text-[11px] tracking-[0.2em] text-muted uppercase",
						children: [
							"Le contrat",
							"Le programme",
							"Les règles",
							"Le jour 1",
							"La signature"
						][step]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
						className: "w-11 text-right text-[11px] tabular-nums text-faint",
						children: [step + 1, "/5"]
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "mb-6 flex gap-1",
				children: [
					0,
					1,
					2,
					3,
					4
				].map((i) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { className: cn("h-0.5 flex-1 rounded-full", i <= step ? "bg-fg" : "bg-line") }, i))
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex-1 overflow-y-auto",
				children: [
					step === 0 && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "stagger-in space-y-5",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
								className: "font-serif text-[2.35rem] leading-[1.05] tracking-tight",
								children: "Une période de lock-in."
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "text-[15px] leading-relaxed text-muted",
								children: "90 jours. Sport, sommeil, discipline. Tu signes, tu valides chaque soir, tu regardes ta flamme grandir."
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("ul", {
								className: "space-y-3 pt-2 text-[14px] text-fg",
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
										className: "flex gap-3 border-b border-line pb-3",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
											className: "text-ice",
											children: "01"
										}), "Neuf règles. Pas une de plus à inventer ce soir."]
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
										className: "flex gap-3 border-b border-line pb-3",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
											className: "text-ice",
											children: "02"
										}), "Appui long pour valider. Pas de case cochée par réflexe."]
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
										className: "flex gap-3",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
											className: "text-ice",
											children: "03"
										}), "Une semaine ratée : le gel sauve ta flamme. Une seule fois."]
									})
								]
							})
						]
					}),
					step === 1 && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "space-y-3",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
								className: "font-serif text-[2.1rem] leading-tight tracking-tight",
								children: "Choisis ton arc."
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "mb-4 text-[14px] text-muted",
								children: "Classique, ou un programme plus serré."
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "grid gap-2",
								children: PROGRAMS.map((p) => {
									const active = draft.programId === p.id;
									return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
										type: "button",
										onClick: () => setDraft({ programId: p.id }),
										className: cn("flex items-center justify-between rounded-lg border px-4 py-3.5 text-left transition-colors duration-150", active ? "border-fg/35 bg-raised" : "border-line bg-transparent"),
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
											className: "block text-[15px] font-medium",
											children: p.name
										}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
											className: "block text-[12px] text-muted",
											children: p.tagline
										})] }), active && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Check, { className: "size-4 text-ok" })]
									}, p.id);
								})
							})
						]
					}),
					step === 2 && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "space-y-4",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("h2", {
								className: "font-serif text-[2.1rem] leading-tight tracking-tight",
								children: [rules.length, " règles. Chaque jour."]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
								className: "text-[14px] text-muted",
								children: [
									"Voici le contrat ",
									program.name.toLowerCase(),
									"."
								]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
								className: "space-y-1",
								children: rules.map((r) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
									className: "flex items-start gap-3 rounded-md px-1 py-2.5",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: "mt-0.5 grid size-9 shrink-0 place-items-center rounded-sm bg-raised text-ice",
										children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(RuleGlyph, {
											name: r.icon,
											className: "size-4"
										})
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: "block text-[14px] font-medium",
										children: r.title
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: "block text-[12px] text-muted",
										children: r.detail
									})] })]
								}, r.id))
							})
						]
					}),
					step === 3 && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "space-y-4",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
								className: "font-serif text-[2.1rem] leading-tight tracking-tight",
								children: "Ton jour 1."
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "text-[14px] text-muted",
								children: "Le 1er octobre, tu pars avec tout le monde. Ou tu choisis ta date : tes 90 jours commencent quand tu signes."
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(DateChoice, {
								label: "1er octobre",
								hint: `${formatFr(oct1, {
									day: "numeric",
									month: "long",
									year: "numeric"
								})} · avec tout le monde`,
								selected: draft.startDate === oct1,
								onSelect: () => setDraft({ startDate: oct1 })
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(DateChoice, {
								label: "Aujourd'hui",
								hint: "Tes 90 jours démarrent ce soir.",
								selected: draft.startDate === today,
								onSelect: () => setDraft({ startDate: today })
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(DateChoice, {
								label: "Lundi prochain",
								hint: formatFr(monday, {
									weekday: "long",
									day: "numeric",
									month: "long"
								}),
								selected: draft.startDate === monday,
								onSelect: () => setDraft({ startDate: monday })
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
								className: "block",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "mb-2 block text-[12px] tracking-wide text-muted uppercase",
									children: "Autre date"
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
									type: "date",
									value: draft.startDate,
									onChange: (e) => e.target.value && setDraft({ startDate: e.target.value }),
									className: "h-12 w-full rounded-md border border-line bg-raised px-3 text-[14px] text-fg outline-none"
								})]
							})
						]
					}),
					step === 4 && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "space-y-5",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
								className: "font-serif text-[2.1rem] leading-tight tracking-tight",
								children: "Tu signes."
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
								className: "text-[14px] text-muted",
								children: [
									"Pré-engagement. Tu n'essaies pas — tu es engagé. Départ le",
									" ",
									formatFr(draft.startDate, {
										weekday: "long",
										day: "numeric",
										month: "long"
									}),
									"."
								]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
								className: "block",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "mb-2 block text-[12px] tracking-wide text-muted uppercase",
									children: "Ton nom"
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
									type: "text",
									value: draft.signerName,
									onChange: (e) => setDraft({ signerName: e.target.value }),
									placeholder: "Prénom",
									className: "h-12 w-full rounded-md border border-line bg-raised px-3 text-[15px] text-fg outline-none placeholder:text-faint"
								})]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "mb-2 block text-[12px] tracking-wide text-muted uppercase",
								children: "Signature"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SignaturePad, {
								value: draft.signatureData,
								onChange: (signatureData) => setDraft({ signatureData })
							})] })
						]
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
				type: "button",
				onClick: next,
				className: "mt-4 flex h-14 w-full items-center justify-center rounded-[18px] bg-fg text-[15px] font-medium text-bg transition-transform duration-150 ease-out active:scale-[0.96]",
				children: step === 4 ? "Je m'engage" : "Continuer"
			})
		]
	}) });
}
function DateChoice({ label, hint, selected, onSelect }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
		type: "button",
		onClick: onSelect,
		className: cn("flex w-full items-center justify-between rounded-lg border px-4 py-3.5 text-left", selected ? "border-fg/35 bg-raised" : "border-line"),
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
			className: "block text-[15px] font-medium",
			children: label
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
			className: "block text-[12px] text-muted",
			children: hint
		})] }), selected && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Check, { className: "size-4 text-ok" })]
	});
}
function Home() {
	const hydrated = useArcStore((s) => s.hydrated);
	const arc = useArcStore((s) => s.arc);
	const loadDemo = useArcStore((s) => s.loadDemo);
	const [onboarding, setOnboarding] = (0, import_react.useState)(false);
	(0, import_react.useEffect)(() => {
		const result = useArcStore.persist.rehydrate();
		Promise.resolve(result).finally(() => {
			useArcStore.getState().setHydrated();
		});
	}, []);
	if (!hydrated) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Frame, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: "relative z-[1] flex min-h-dvh items-center justify-center md:min-h-[844px]",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "font-serif text-2xl tracking-tight",
			children: "NORD"
		})
	}) });
	if (onboarding && !arc) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Onboarding, { onCancel: () => setOnboarding(false) });
	if (!arc) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Landing, {
		onStart: () => setOnboarding(true),
		onDemo: loadDemo
	});
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(AppShell, { arc });
}
//#endregion
export { Home as component };
