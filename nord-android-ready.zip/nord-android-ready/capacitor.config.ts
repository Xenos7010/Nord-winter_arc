import type { CapacitorConfig } from "@capacitor/cli";

/**
 * Android packaging for NORD.
 *
 * The web app remains the source of truth. By default Capacitor uses the
 * generated web assets; set CAPACITOR_SERVER_URL only when you intentionally
 * want the Android app to load a deployed web instance instead.
 */
const config: CapacitorConfig = {
  appId: "com.nord.arc90",
  appName: "NORD",
  webDir: ".output/public",
  android: {
    allowMixedContent: false,
  },
  server: process.env.CAPACITOR_SERVER_URL
    ? {
        url: process.env.CAPACITOR_SERVER_URL,
        cleartext: process.env.CAPACITOR_SERVER_URL.startsWith("http://"),
      }
    : undefined,
};

export default config;
