import { Flame, Grid2x2, Sun, User } from "lucide-react";
import type { TabId } from "@/lib/types";
import { cn } from "@/lib/utils";

const TABS: { id: TabId; label: string; icon: typeof Sun }[] = [
  { id: "jour", label: "Jour", icon: Sun },
  { id: "cases", label: "90", icon: Grid2x2 },
  { id: "flamme", label: "Flamme", icon: Flame },
  { id: "toi", label: "Toi", icon: User },
];

export function TabBar({ tab, onChange }: { tab: TabId; onChange: (t: TabId) => void }) {
  return (
    <nav className="absolute inset-x-0 bottom-0 z-10 border-t border-line bg-bg/95 pb-[max(0.5rem,env(safe-area-inset-bottom))] pt-1">
      <ul className="grid grid-cols-4">
        {TABS.map((t) => {
          const Icon = t.icon;
          const active = tab === t.id;
          return (
            <li key={t.id}>
              <button
                type="button"
                onClick={() => onChange(t.id)}
                className={cn(
                  "flex h-14 w-full flex-col items-center justify-center gap-0.5 text-[10px] tracking-wide",
                  active ? "text-fg" : "text-faint",
                )}
              >
                <Icon className="size-[18px]" strokeWidth={active ? 2 : 1.6} />
                {t.label}
              </button>
            </li>
          );
        })}
      </ul>
    </nav>
  );
}
