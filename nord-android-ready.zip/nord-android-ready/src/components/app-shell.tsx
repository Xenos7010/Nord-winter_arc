import { useEffect, useState } from "react";
import {
  dayNumber,
  isBeforeStart,
  isComplete,
} from "@/lib/arc";
import { useArcStore } from "@/lib/store";
import type { Arc } from "@/lib/types";
import { Complete } from "./complete";
import { Countdown } from "./countdown";
import { FlameView } from "./flame-view";
import { Frame } from "./frame";
import { Grid90 } from "./grid-90";
import { IceBreak } from "./ice-break";
import { Profile } from "./profile";
import { TabBar } from "./tab-bar";
import { Today } from "./today";

export function AppShell({ arc }: { arc: Arc }) {
  const tab = useArcStore((s) => s.tab);
  const setTab = useArcStore((s) => s.setTab);
  const breakIce = useArcStore((s) => s.breakIce);
  const reset = useArcStore((s) => s.reset);
  const [, setTick] = useState(0);

  useEffect(() => {
    const id = window.setInterval(() => setTick((n) => n + 1), 1000);
    return () => window.clearInterval(id);
  }, []);

  if (isBeforeStart(arc)) {
    return <Countdown arc={arc} onReset={reset} />;
  }

  const n = dayNumber(arc);
  if (n >= 1 && n <= 90 && !arc.iceBroken) {
    return <IceBreak onBroken={breakIce} />;
  }

  if (isComplete(arc)) {
    return <Complete arc={arc} />;
  }

  return (
    <Frame>
      <div className="relative z-[1] flex min-h-dvh flex-1 flex-col md:min-h-[844px]">
        {tab === "jour" && <Today arc={arc} />}
        {tab === "cases" && <Grid90 arc={arc} />}
        {tab === "flamme" && <FlameView arc={arc} />}
        {tab === "toi" && <Profile arc={arc} />}
        <TabBar tab={tab} onChange={setTab} />
      </div>
    </Frame>
  );
}
