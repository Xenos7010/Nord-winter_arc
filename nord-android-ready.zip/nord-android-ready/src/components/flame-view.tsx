import { evaluateWeeks, weekCount } from "@/lib/arc";
import type { Arc } from "@/lib/types";
import { cn } from "@/lib/utils";

export function FlameView({ arc }: { arc: Arc }) {
  const { weeks, flame, gelUsed, flameOut } = evaluateWeeks(arc);
  const total = weekCount(arc);
  const frozen = weeks.some((w) => w.mark === "frozen");

  let status = "La flamme grandit avec chaque semaine complète.";
  if (flameOut) status = "La flamme s'est éteinte. L'arc, lui, continue jusqu'au jour 90.";
  else if (frozen) status = "Le gel la couvre. Une seule fois. La prochaine, elle s'éteint.";

  return (
    <div className="flex flex-1 flex-col overflow-y-auto px-5 pb-28 pt-[max(1.25rem,env(safe-area-inset-top))]">
      <p className="text-[11px] tracking-[0.22em] text-muted uppercase">La flamme</p>
      <h1 className="mt-2 font-serif text-[2.4rem] leading-tight tracking-tight">
        {flameOut ? "Éteinte." : frozen ? "Gelée." : "Elle ne pardonne qu'une fois."}
      </h1>
      <p className="mt-3 max-w-[22rem] text-[14px] leading-relaxed text-muted">{status}</p>

      <div className="relative mx-auto my-10 grid place-items-center">
        <span
          className={cn(
            "absolute size-40 rounded-full blur-3xl",
            flameOut ? "bg-faint/20" : frozen ? "bg-ice/25" : "bg-ember/25",
          )}
          style={flameOut ? undefined : { animation: "flame-pulse 2.6s ease-in-out infinite" }}
        />
        <FlameMark level={flame} out={flameOut} frozen={frozen} />
      </div>

      <div className="text-center">
        <div className="font-serif text-[3rem] leading-none tabular-nums">{flame}</div>
        <div className="mt-1 text-[12px] tracking-[0.16em] text-muted uppercase">
          semaines allumées · {total} au total
        </div>
      </div>

      <ul className="mt-10 space-y-3 text-[13px] text-muted">
        <li className="flex justify-between border-b border-line pb-3">
          <span>Gel utilisé</span>
          <span className="text-fg">{gelUsed ? "Oui" : "Pas encore"}</span>
        </li>
        <li className="flex justify-between border-b border-line pb-3">
          <span>Semaines validées</span>
          <span className="text-fg tabular-nums">{flame}</span>
        </li>
        <li className="flex justify-between">
          <span>État</span>
          <span className="text-fg">
            {flameOut ? "Éteinte" : frozen ? "Couverte par le gel" : "Vivante"}
          </span>
        </li>
      </ul>
    </div>
  );
}

function FlameMark({ level, out, frozen }: { level: number; out: boolean; frozen: boolean }) {
  const fill = out ? "#5c5852" : frozen ? "#9bb4c0" : "#d4894a";
  const h = 28 + Math.min(13, level) * 6;
  return (
    <svg width="120" height="150" viewBox="0 0 120 150" className="relative">
      <path
        d={`M60 ${150 - h} C78 ${150 - h + 18} 96 ${150 - h / 2} 88 128 C110 118 108 92 84 78 C90 52 74 ${150 - h + 8} 60 ${150 - h} C46 ${150 - h + 8} 30 52 36 78 C12 92 10 118 32 128 C24 ${150 - h / 2} 42 ${150 - h + 18} 60 ${150 - h} Z`}
        fill={fill}
        fillOpacity={out ? 0.35 : 0.92}
      />
      <path
        d={`M60 ${150 - h + 22} C70 ${150 - h + 36} 78 118 70 128 C76 124 74 110 60 ${150 - h + 22} C46 110 44 124 50 128 C42 118 50 ${150 - h + 36} 60 ${150 - h + 22} Z`}
        fill={out ? "#3a3836" : frozen ? "#d7e6ee" : "#f2efe8"}
        fillOpacity={0.85}
      />
    </svg>
  );
}
