import { useState } from "react";
import { Frame } from "./frame";

export function IceBreak({ onBroken }: { onBroken: () => void }) {
  const [taps, setTaps] = useState(0);
  const [leaving, setLeaving] = useState(false);

  function tap() {
    if (leaving) return;
    const next = taps + 1;
    setTaps(next);
    if (next >= 3) {
      setLeaving(true);
      window.setTimeout(onBroken, 700);
    }
  }

  return (
    <Frame>
      <button
        type="button"
        onClick={tap}
        className="relative z-[1] flex min-h-dvh w-full flex-col items-center justify-center px-6 text-center md:min-h-[844px]"
      >
        <div
          className="pointer-events-none absolute inset-0"
          style={{
            background:
              "radial-gradient(120% 80% at 50% 20%, rgba(155,180,192,0.18), transparent 55%), linear-gradient(180deg, #0c1216, #08090c 70%)",
            opacity: leaving ? 0 : 1,
            transition: "opacity 600ms cubic-bezier(0.22, 1, 0.36, 1)",
          }}
        />
        <Cracks taps={taps} leaving={leaving} />
        <p className="relative text-[11px] tracking-[0.28em] text-ice uppercase">Jour 1</p>
        <h1 className="relative mt-4 font-serif text-[2.6rem] leading-[1.05] tracking-tight">
          Ton arc est pris
          <br />
          dans la glace.
        </h1>
        <p className="relative mt-5 max-w-[16rem] text-[14px] text-muted">
          {taps >= 3 ? "C'est ouvert." : `Trois taps pour la briser. ${3 - taps} restant${3 - taps > 1 ? "s" : ""}.`}
        </p>
      </button>
    </Frame>
  );
}

function Cracks({ taps, leaving }: { taps: number; leaving: boolean }) {
  return (
    <svg
      className="pointer-events-none absolute inset-0 h-full w-full"
      viewBox="0 0 390 844"
      preserveAspectRatio="xMidYMid slice"
      style={{
        opacity: leaving ? 0 : taps === 0 ? 0.15 : 1,
        transition: "opacity 600ms ease",
      }}
    >
      <path
        d="M200 0 L210 180 L140 310 L250 430 L190 844"
        fill="none"
        stroke="#d7e6ee"
        strokeWidth={taps >= 1 ? 1.4 : 0.4}
        opacity={taps >= 1 ? 0.7 : 0.15}
      />
      <path
        d="M210 180 L320 220 L390 260"
        fill="none"
        stroke="#d7e6ee"
        strokeWidth={taps >= 2 ? 1.2 : 0}
        opacity={taps >= 2 ? 0.65 : 0}
      />
      <path
        d="M140 310 L40 360 L0 400"
        fill="none"
        stroke="#d7e6ee"
        strokeWidth={taps >= 2 ? 1.1 : 0}
        opacity={taps >= 2 ? 0.55 : 0}
      />
      <path
        d="M250 430 L340 520 L360 700"
        fill="none"
        stroke="#d7e6ee"
        strokeWidth={taps >= 3 ? 1.4 : 0}
        opacity={taps >= 3 ? 0.75 : 0}
      />
      <path
        d="M250 430 L160 560 L80 720"
        fill="none"
        stroke="#d7e6ee"
        strokeWidth={taps >= 3 ? 1.3 : 0}
        opacity={taps >= 3 ? 0.7 : 0}
      />
    </svg>
  );
}
