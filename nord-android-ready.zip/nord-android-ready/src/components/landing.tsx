import { Flame } from "lucide-react";
import { Frame } from "./frame";

type Props = {
  onStart: () => void;
  onDemo: () => void;
};

export function Landing({ onStart, onDemo }: Props) {
  return (
    <Frame>
      <div className="relative z-[1] flex min-h-dvh flex-col px-6 pb-[max(1.5rem,env(safe-area-inset-bottom))] pt-[max(2.5rem,env(safe-area-inset-top))] md:min-h-[844px]">
        <header className="flex items-center justify-between text-[11px] tracking-[0.22em] text-muted uppercase">
          <span>NORD</span>
          <span>Défi 90 jours</span>
        </header>

        <div className="stagger-in flex flex-1 flex-col justify-center">
          <div className="mb-8 flex justify-center">
            <span className="relative grid size-16 place-items-center">
              <span
                className="absolute inset-0 rounded-full bg-ember/20 blur-xl"
                style={{ animation: "flame-pulse 2.8s ease-in-out infinite" }}
              />
              <Flame className="relative size-9 text-ember" strokeWidth={1.4} fill="currentColor" fillOpacity={0.25} />
            </span>
          </div>
          <p className="mb-3 text-center text-[11px] tracking-[0.28em] text-ice uppercase">
            L'hiver ne t'attendra pas
          </p>
          <h1 className="font-serif text-[3.15rem] leading-[0.95] tracking-tight text-fg text-center">
            90 jours.
            <br />
            9 règles.
            <br />
            Zéro excuse.
          </h1>
          <p className="mx-auto mt-6 max-w-[18rem] text-center text-[15px] leading-relaxed text-muted">
            Tu signes un contrat. Tu valides chaque soir. Ta discipline se construit case après case.
          </p>
        </div>

        <div className="space-y-3">
          <button
            type="button"
            onClick={onStart}
            className="flex h-14 w-full items-center justify-center rounded-[18px] bg-fg text-[15px] font-medium text-bg transition-transform duration-150 ease-out active:scale-[0.96]"
          >
            Signer mon contrat
          </button>
          <button
            type="button"
            onClick={onDemo}
            className="flex h-12 w-full items-center justify-center rounded-[18px] border border-line text-[14px] text-muted transition-transform duration-150 ease-out active:scale-[0.96]"
          >
            Voir un arc au jour 47
          </button>
          <p className="pt-1 text-center text-[11px] text-faint">
            Gratuit. Sans compte. Tes photos restent ici.
          </p>
        </div>
      </div>
    </Frame>
  );
}
