import { useState } from "react";
import { ArrowLeft, Check } from "lucide-react";
import { PROGRAMS, PROGRAM_MAP, RULE_MAP } from "@/lib/catalog";
import { useArcStore } from "@/lib/store";
import type { ProgramId } from "@/lib/types";
import { cn, formatFr, nextMondayISO, officialStartISO, todayISO } from "@/lib/utils";
import { Frame } from "./frame";
import { RuleGlyph } from "./rule-icon";
import { SignaturePad } from "./signature-pad";

type Props = {
  onCancel: () => void;
};

export function Onboarding({ onCancel }: Props) {
  const [step, setStep] = useState(0);
  const draft = useArcStore((s) => s.draft);
  const setDraft = useArcStore((s) => s.setDraft);
  const sign = useArcStore((s) => s.sign);
  const program = PROGRAM_MAP[draft.programId];
  const rules = program.ruleIds.map((id) => RULE_MAP[id]);

  const oct1 = officialStartISO();
  const today = todayISO();
  const monday = nextMondayISO();

  function next() {
    if (step < 4) setStep(step + 1);
    else sign();
  }

  const titles = ["Le contrat", "Le programme", "Les règles", "Le jour 1", "La signature"];

  return (
    <Frame>
      <div className="relative z-[1] flex min-h-dvh flex-col px-6 pb-[max(1.25rem,env(safe-area-inset-bottom))] pt-[max(1.25rem,env(safe-area-inset-top))] md:min-h-[844px]">
        <header className="mb-6 flex items-center justify-between">
          <button
            type="button"
            onClick={() => (step === 0 ? onCancel() : setStep(step - 1))}
            className="grid size-11 place-items-center rounded-full text-muted transition-transform duration-150 active:scale-[0.96]"
            aria-label="Retour"
          >
            <ArrowLeft className="size-5" />
          </button>
          <span className="text-[11px] tracking-[0.2em] text-muted uppercase">{titles[step]}</span>
          <span className="w-11 text-right text-[11px] tabular-nums text-faint">{step + 1}/5</span>
        </header>

        <div className="mb-6 flex gap-1">
          {[0, 1, 2, 3, 4].map((i) => (
            <span
              key={i}
              className={cn("h-0.5 flex-1 rounded-full", i <= step ? "bg-fg" : "bg-line")}
            />
          ))}
        </div>

        <div className="flex-1 overflow-y-auto">
          {step === 0 && (
            <div className="stagger-in space-y-5">
              <h2 className="font-serif text-[2.35rem] leading-[1.05] tracking-tight">
                Une période de lock-in.
              </h2>
              <p className="text-[15px] leading-relaxed text-muted">
                90 jours. Sport, sommeil, discipline. Tu signes, tu valides chaque soir, tu regardes ta flamme grandir.
              </p>
              <ul className="space-y-3 pt-2 text-[14px] text-fg">
                <li className="flex gap-3 border-b border-line pb-3">
                  <span className="text-ice">01</span>
                  Neuf règles. Pas une de plus à inventer ce soir.
                </li>
                <li className="flex gap-3 border-b border-line pb-3">
                  <span className="text-ice">02</span>
                  Appui long pour valider. Pas de case cochée par réflexe.
                </li>
                <li className="flex gap-3">
                  <span className="text-ice">03</span>
                  Une semaine ratée : le gel sauve ta flamme. Une seule fois.
                </li>
              </ul>
            </div>
          )}

          {step === 1 && (
            <div className="space-y-3">
              <h2 className="font-serif text-[2.1rem] leading-tight tracking-tight">Choisis ton arc.</h2>
              <p className="mb-4 text-[14px] text-muted">Classique, ou un programme plus serré.</p>
              <div className="grid gap-2">
                {PROGRAMS.map((p) => {
                  const active = draft.programId === p.id;
                  return (
                    <button
                      key={p.id}
                      type="button"
                      onClick={() => setDraft({ programId: p.id as ProgramId })}
                      className={cn(
                        "flex items-center justify-between rounded-lg border px-4 py-3.5 text-left transition-colors duration-150",
                        active ? "border-fg/35 bg-raised" : "border-line bg-transparent",
                      )}
                    >
                      <span>
                        <span className="block text-[15px] font-medium">{p.name}</span>
                        <span className="block text-[12px] text-muted">{p.tagline}</span>
                      </span>
                      {active && <Check className="size-4 text-ok" />}
                    </button>
                  );
                })}
              </div>
            </div>
          )}

          {step === 2 && (
            <div className="space-y-4">
              <h2 className="font-serif text-[2.1rem] leading-tight tracking-tight">
                {rules.length} règles. Chaque jour.
              </h2>
              <p className="text-[14px] text-muted">Voici le contrat {program.name.toLowerCase()}.</p>
              <ul className="space-y-1">
                {rules.map((r) => (
                  <li key={r.id} className="flex items-start gap-3 rounded-md px-1 py-2.5">
                    <span className="mt-0.5 grid size-9 shrink-0 place-items-center rounded-sm bg-raised text-ice">
                      <RuleGlyph name={r.icon} className="size-4" />
                    </span>
                    <span>
                      <span className="block text-[14px] font-medium">{r.title}</span>
                      <span className="block text-[12px] text-muted">{r.detail}</span>
                    </span>
                  </li>
                ))}
              </ul>
            </div>
          )}

          {step === 3 && (
            <div className="space-y-4">
              <h2 className="font-serif text-[2.1rem] leading-tight tracking-tight">Ton jour 1.</h2>
              <p className="text-[14px] text-muted">
                Le 1er octobre, tu pars avec tout le monde. Ou tu choisis ta date : tes 90 jours commencent quand tu signes.
              </p>
              <DateChoice
                label="1er octobre"
                hint={`${formatFr(oct1, { day: "numeric", month: "long", year: "numeric" })} · avec tout le monde`}
                selected={draft.startDate === oct1}
                onSelect={() => setDraft({ startDate: oct1 })}
              />
              <DateChoice
                label="Aujourd'hui"
                hint="Tes 90 jours démarrent ce soir."
                selected={draft.startDate === today}
                onSelect={() => setDraft({ startDate: today })}
              />
              <DateChoice
                label="Lundi prochain"
                hint={formatFr(monday, { weekday: "long", day: "numeric", month: "long" })}
                selected={draft.startDate === monday}
                onSelect={() => setDraft({ startDate: monday })}
              />
              <label className="block">
                <span className="mb-2 block text-[12px] tracking-wide text-muted uppercase">Autre date</span>
                <input
                  type="date"
                  value={draft.startDate}
                  onChange={(e) => e.target.value && setDraft({ startDate: e.target.value })}
                  className="h-12 w-full rounded-md border border-line bg-raised px-3 text-[14px] text-fg outline-none"
                />
              </label>
            </div>
          )}

          {step === 4 && (
            <div className="space-y-5">
              <h2 className="font-serif text-[2.1rem] leading-tight tracking-tight">Tu signes.</h2>
              <p className="text-[14px] text-muted">
                Pré-engagement. Tu n'essaies pas — tu es engagé. Départ le{" "}
                {formatFr(draft.startDate, { weekday: "long", day: "numeric", month: "long" })}.
              </p>
              <label className="block">
                <span className="mb-2 block text-[12px] tracking-wide text-muted uppercase">Ton nom</span>
                <input
                  type="text"
                  value={draft.signerName}
                  onChange={(e) => setDraft({ signerName: e.target.value })}
                  placeholder="Prénom"
                  className="h-12 w-full rounded-md border border-line bg-raised px-3 text-[15px] text-fg outline-none placeholder:text-faint"
                />
              </label>
              <div>
                <span className="mb-2 block text-[12px] tracking-wide text-muted uppercase">Signature</span>
                <SignaturePad
                  value={draft.signatureData}
                  onChange={(signatureData) => setDraft({ signatureData })}
                />
              </div>
            </div>
          )}
        </div>

        <button
          type="button"
          onClick={next}
          className="mt-4 flex h-14 w-full items-center justify-center rounded-[18px] bg-fg text-[15px] font-medium text-bg transition-transform duration-150 ease-out active:scale-[0.96]"
        >
          {step === 4 ? "Je m'engage" : "Continuer"}
        </button>
      </div>
    </Frame>
  );
}

function DateChoice({
  label,
  hint,
  selected,
  onSelect,
}: {
  label: string;
  hint: string;
  selected: boolean;
  onSelect: () => void;
}) {
  return (
    <button
      type="button"
      onClick={onSelect}
      className={cn(
        "flex w-full items-center justify-between rounded-lg border px-4 py-3.5 text-left",
        selected ? "border-fg/35 bg-raised" : "border-line",
      )}
    >
      <span>
        <span className="block text-[15px] font-medium">{label}</span>
        <span className="block text-[12px] text-muted">{hint}</span>
      </span>
      {selected && <Check className="size-4 text-ok" />}
    </button>
  );
}
