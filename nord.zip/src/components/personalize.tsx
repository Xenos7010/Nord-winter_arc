import { Check, Plus, X } from "lucide-react";
import { useState } from "react";
import { BONUS_CATALOG } from "@/lib/premium/bonus";
import { MAX_BONUS, MAX_CUSTOM_BONUS } from "@/lib/premium/constants";
import { FLAME_THEMES, FLAME_THEME_IDS } from "@/lib/premium/themes";
import { useArcStore } from "@/lib/store";
import type { Arc } from "@/lib/types";
import { cn } from "@/lib/utils";
import { RuleGlyph } from "./rule-icon";

/** Personnalisation NORD Premium : couleur de la flamme, exercices bonus, exercices personnels. */
export function Personalize({ arc }: { arc: Arc }) {
  const theme = useArcStore((s) => s.flameTheme);
  const setFlameTheme = useArcStore((s) => s.setFlameTheme);
  const toggleBonus = useArcStore((s) => s.toggleBonus);
  const addCustomBonus = useArcStore((s) => s.addCustomBonus);
  const removeCustomBonus = useArcStore((s) => s.removeCustomBonus);
  const [draft, setDraft] = useState("");

  const ids = arc.bonusIds ?? [];
  const custom = arc.customBonus ?? [];
  const count = ids.length + custom.length;
  const full = count >= MAX_BONUS;

  function submit() {
    if (!draft.trim()) return;
    addCustomBonus(draft);
    setDraft("");
  }

  return (
    <section className="mt-10">
      <h2 className="text-[11px] tracking-[0.2em] text-muted uppercase">Personnaliser</h2>
      <div className="mt-3 rounded-lg border border-line bg-surface px-4 py-4">
        <p className="text-[12px] text-muted">Flamme</p>
        <div className="mt-3 flex gap-4">
          {FLAME_THEME_IDS.map((id) => {
            const t = FLAME_THEMES[id];
            return (
              <button key={id} type="button" onClick={() => setFlameTheme(id)} className="flex flex-col items-center gap-1.5">
                <span
                  className={cn("grid size-11 place-items-center rounded-full border", theme === id ? "border-fg" : "border-line")}
                >
                  <span className="size-6 rounded-full" style={{ background: `rgb(${t.rgb})` }} />
                </span>
                <span className={cn("text-[11px]", theme === id ? "text-fg" : "text-muted")}>{t.label}</span>
              </button>
            );
          })}
        </div>

        <div className="mt-7 flex items-baseline justify-between">
          <p className="text-[12px] text-muted">Exercices bonus</p>
          <p className="text-[11px] tabular-nums text-faint">
            {count} / {MAX_BONUS}
          </p>
        </div>
        <p className="mt-1 text-[12px] text-faint">Ils s'ajoutent à ta journée, sans jamais compter dans « Journée pleine ».</p>
        <ul className="mt-2">
          {BONUS_CATALOG.map((b) => {
            const on = ids.includes(b.id);
            return (
              <li key={b.id} className="border-b border-line last:border-0">
                <button
                  type="button"
                  disabled={!on && full}
                  onClick={() => toggleBonus(b.id)}
                  className="flex w-full items-center gap-3 py-2.5 text-left disabled:opacity-40"
                >
                  <span className="text-ice">
                    <RuleGlyph name={b.icon} className="size-4" />
                  </span>
                  <span className="min-w-0 flex-1">
                    <span className="block truncate text-[13px]">{b.title}</span>
                  </span>
                  {on && <Check className="size-4 text-ok" />}
                </button>
              </li>
            );
          })}
        </ul>

        <p className="mt-6 text-[12px] text-muted">Tes propres exercices</p>
        <ul className="mt-1">
          {custom.map((c) => (
            <li key={c.id} className="flex items-center justify-between border-b border-line py-2.5 text-[13px] last:border-0">
              <span className="truncate">{c.title}</span>
              <button type="button" aria-label="Retirer" onClick={() => removeCustomBonus(c.id)} className="p-1 text-muted">
                <X className="size-4" />
              </button>
            </li>
          ))}
        </ul>
        {custom.length < MAX_CUSTOM_BONUS && !full && (
          <div className="mt-3 flex gap-2">
            <input
              value={draft}
              maxLength={40}
              onChange={(e) => setDraft(e.target.value)}
              onKeyDown={(e) => e.key === "Enter" && submit()}
              placeholder="Ex. Corde à sauter, 5 minutes"
              className="h-10 min-w-0 flex-1 rounded-md border border-line bg-raised px-3 text-[13px] text-fg outline-none placeholder:text-faint"
            />
            <button
              type="button"
              onClick={submit}
              aria-label="Ajouter"
              className="grid h-10 w-10 place-items-center rounded-md border border-line text-fg"
            >
              <Plus className="size-4" />
            </button>
          </div>
        )}
      </div>
    </section>
  );
}
