import { useEffect } from "react";
import { LivingFlame } from "./living-flame";

export type Moment = {
  kicker: string;
  title: string;
  day: number;
  lines: string[];
};

export function DayMoment({ moment, onClose }: { moment: Moment; onClose: () => void }) {
  useEffect(() => {
    const id = window.setTimeout(onClose, 5200);
    return () => window.clearTimeout(id);
  }, [onClose]);

  return (
    <button
      type="button"
      onClick={onClose}
      aria-label="Continuer"
      className="fixed inset-0 z-50 grid place-items-center bg-bg/90 px-8 text-center md:absolute"
    >
      <span className="stagger-in flex flex-col items-center">
        <span className="text-[11px] tracking-[0.24em] text-ice uppercase">{moment.kicker}</span>
        <span className="mt-6">
          <LivingFlame size={120} day={moment.day} flare />
        </span>
        <span className="mt-8 font-serif text-[2.1rem] leading-tight tracking-tight">{moment.title}</span>
        {moment.lines.map((l, i) => (
          <span key={i} className={i === 0 ? "mt-5 text-[14px] text-fg" : "mt-1.5 max-w-[19rem] text-[13px] text-muted"}>
            {l}
          </span>
        ))}
      </span>
    </button>
  );
}
