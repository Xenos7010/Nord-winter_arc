import { useEffect, useState } from "react";
import { toast } from "sonner";
import {
  dayNumber,
  dayScore,
  evaluateWeeks,
  isDayFull,
  isoForDay,
  rulesOf,
  weekIndexForDay,
  weeklyProgress,
} from "@/lib/arc";
import { quoteForDay } from "@/lib/catalog";
import { bonusRulesOf } from "@/lib/premium/bonus";
import { MILESTONES, nextMilestone, progressStats, reachedMilestones, tomorrowLine } from "@/lib/progress";
import { useArcStore } from "@/lib/store";
import type { Arc, RuleDef } from "@/lib/types";
import { cn, formatFr, todayISO } from "@/lib/utils";
import { DayMoment, type Moment } from "./day-moment";
import { HoldConfirm } from "./hold-confirm";
import { LivingFlame } from "./living-flame";
import { useIsPremium } from "@/lib/premium/store";
import { RuleGlyph } from "./rule-icon";

export function Today({ arc }: { arc: Arc }) {
  const toggleCheck = useArcStore((s) => s.toggleCheck);
  const setGratitude = useArcStore((s) => s.setGratitude);
  const markMilestoneSeen = useArcStore((s) => s.markMilestoneSeen);
  const iso = todayISO();
  const n = dayNumber(arc, iso);
  const clamped = Math.min(90, Math.max(1, n));
  const activeIso = n < 1 ? isoForDay(arc, 1) : n > 90 ? isoForDay(arc, 90) : iso;
  const score = dayScore(arc, activeIso);
  const evalw = evaluateWeeks(arc, iso);
  const weekI = weekIndexForDay(clamped);
  const week = evalw.weeks[weekI];
  const log = arc.days[activeIso];
  const rules = rulesOf(arc);
  const premium = useIsPremium();
  const bonus = premium ? bonusRulesOf(arc) : [];
  const stats = progressStats(arc, iso);
  const [moment, setMoment] = useState<Moment | null>(null);
  const [gratitudeOpen, setGratitudeOpen] = useState(false);
  const [gratitudeText, setGratitudeText] = useState(log?.gratitude ?? "");

  // Palier atteint mais pas encore montré (ex. jour passé sans ouvrir l'app) : un seul moment, une seule fois.
  useEffect(() => {
    const seen = arc.seenMilestones ?? [];
    const unseen = reachedMilestones(arc).filter((d) => !seen.includes(d));
    if (unseen.length === 0) return;
    const d = Math.max(...unseen);
    const m = MILESTONES.find((x) => x.day === d);
    markMilestoneSeen(d);
    if (m) setMoment({ kicker: `Jour ${d}`, title: m.title, day: d, lines: [m.note] });
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  function celebrate(day: number) {
    const m = MILESTONES.find((x) => x.day === day);
    if (m) markMilestoneSeen(day);
    const next = nextMilestone(day);
    const lines =
      day >= 90
        ? ["Demain : ta synthèse.", "Les 90 jours sont à toi."]
        : [
            `Demain : JOUR ${day + 1}`,
            m ? m.note : next ? `Prochain palier : jour ${next.day}, dans ${next.day - day} jours.` : tomorrowLine(day),
          ];
    setMoment({
      kicker: m ? `Jour ${day}` : "Journée pleine",
      title: m ? m.title : `Jour ${day} terminé.`,
      day,
      lines,
    });
  }

  function handleToggle(rule: RuleDef) {
    if (rule.id === "gratitude" && !log?.checks.gratitude) {
      setGratitudeOpen(true);
      return;
    }
    const wasFull = isDayFull(arc, activeIso);
    toggleCheck(activeIso, rule.id);
    window.setTimeout(() => {
      const snap = useArcStore.getState().arc;
      if (snap && !wasFull && isDayFull(snap, activeIso) && activeIso === iso) celebrate(clamped);
    }, 30);
  }

  function saveGratitude() {
    if (!gratitudeText.trim()) return;
    setGratitude(activeIso, gratitudeText);
    setGratitudeOpen(false);
    toast("Gratitude notée.");
  }

  return (
    <div className="flex flex-1 flex-col overflow-hidden">
      <header className="px-5 pb-4 pt-[max(1.25rem,env(safe-area-inset-top))]">
        <p className="text-[11px] tracking-[0.22em] text-muted uppercase">
          {formatFr(activeIso)}
        </p>
        <div className="mt-2 flex items-end justify-between gap-4">
          <div>
            <p className="text-[11px] tracking-[0.22em] text-ice uppercase">Jour</p>
            <h1 className="font-serif text-[3.4rem] leading-none tracking-tight">
              {clamped}
              <span className="ml-2 font-sans text-[1.05rem] font-normal text-muted">/ 90</span>
            </h1>
            <p className="mt-2 text-[12px] tabular-nums text-muted">
              {stats.percent} % terminé · {stats.remaining} jours restants
            </p>
            <p className="mt-0.5 text-[12px] tabular-nums text-muted">
              {stats.streak} {stats.streak > 1 ? "jours consécutifs" : "jour consécutif"} · {score.done} sur {score.total}
            </p>
          </div>
          <LivingFlame size={84} day={clamped} />
        </div>
        <p className="mt-4 max-w-[22rem] text-[13px] leading-relaxed text-muted">
          {quoteForDay(clamped)}
        </p>
        {week && (
          <div className="mt-5 flex gap-1.5">
            {week.days.map((d) => (
              <span
                key={d.iso}
                className={cn(
                  "h-1.5 flex-1 rounded-full",
                  d.full ? "bg-ok" : d.future ? "bg-line" : "bg-ember/70",
                )}
              />
            ))}
          </div>
        )}
      </header>

      <ul className="flex-1 overflow-y-auto px-4 pb-36">
        {rules.map((rule) => {
          const checked = Boolean(arc.days[activeIso]?.checks[rule.id]);
          const weekly =
            rule.cadence === "weekly" ? weeklyProgress(arc, weekI, rule) : null;
          return (
            <li
              key={rule.id}
              className="flex items-center gap-3 border-b border-line py-3 last:border-0"
            >
              <span className="grid size-10 shrink-0 place-items-center rounded-md bg-surface text-ice">
                <RuleGlyph name={rule.icon} className="size-[18px]" />
              </span>
              <div className="min-w-0 flex-1">
                <div className="truncate text-[14px] font-medium">{rule.title}</div>
                <div className="truncate text-[12px] text-muted">
                  {weekly
                    ? `${weekly.done} / ${weekly.target} cette semaine`
                    : rule.detail}
                </div>
              </div>
              <HoldConfirm
                confirmed={checked}
                onConfirm={() => handleToggle(rule)}
                label={rule.title}
              />
            </li>
          );
        })}
        {bonus.length > 0 && (
          <li className="pb-1 pt-6 text-[11px] tracking-[0.22em] text-muted uppercase">Bonus</li>
        )}
        {bonus.map((rule) => {
          const checked = Boolean(arc.days[activeIso]?.checks[rule.id]);
          return (
            <li key={rule.id} className="flex items-center gap-3 border-b border-line py-3 last:border-0">
              <span className="grid size-10 shrink-0 place-items-center rounded-md bg-surface text-ember">
                <RuleGlyph name={rule.icon} className="size-[18px]" />
              </span>
              <div className="min-w-0 flex-1">
                <div className="truncate text-[14px] font-medium">{rule.title}</div>
                <div className="truncate text-[12px] text-muted">{rule.detail}</div>
              </div>
              <HoldConfirm confirmed={checked} onConfirm={() => handleToggle(rule)} label={rule.title} />
            </li>
          );
        })}
      </ul>

      {moment && <DayMoment moment={moment} onClose={() => setMoment(null)} />}

      {gratitudeOpen && (
        <div className="fixed inset-0 z-40 flex items-end md:absolute bg-bg/70">
          <div className="w-full rounded-t-xl border-t border-line bg-surface px-5 pb-[max(1.25rem,env(safe-area-inset-bottom))] pt-5">
            <h3 className="font-serif text-[1.6rem]">Une chose, ce soir.</h3>
            <textarea
              autoFocus
              value={gratitudeText}
              onChange={(e) => setGratitudeText(e.target.value)}
              rows={3}
              placeholder="Aujourd'hui je suis reconnaissant pour…"
              className="mt-3 w-full resize-none rounded-md border border-line bg-raised px-3 py-2.5 text-[14px] text-fg outline-none placeholder:text-faint"
            />
            <div className="mt-3 flex gap-2">
              <button
                type="button"
                onClick={() => setGratitudeOpen(false)}
                className="h-12 flex-1 rounded-md text-[14px] text-muted"
              >
                Plus tard
              </button>
              <button
                type="button"
                onClick={saveGratitude}
                className="h-12 flex-1 rounded-md bg-fg text-[14px] font-medium text-bg"
              >
                Valider
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
