import { useState } from "react";
import { toast } from "sonner";
import {
  dayNumber,
  dayScore,
  evaluateWeeks,
  isDayFull,
  isoForDay,
  rulesOf,
  weekIndexForDay,
  weeklyProgress,
} from "@/lib/arc";
import { quoteForDay } from "@/lib/catalog";
import { useArcStore } from "@/lib/store";
import type { Arc, RuleDef } from "@/lib/types";
import { cn, formatFr, todayISO } from "@/lib/utils";
import { HoldConfirm } from "./hold-confirm";
import { RuleGlyph } from "./rule-icon";

export function Today({ arc }: { arc: Arc }) {
  const toggleCheck = useArcStore((s) => s.toggleCheck);
  const setGratitude = useArcStore((s) => s.setGratitude);
  const iso = todayISO();
  const n = dayNumber(arc, iso);
  const clamped = Math.min(90, Math.max(1, n));
  const activeIso = n < 1 ? isoForDay(arc, 1) : n > 90 ? isoForDay(arc, 90) : iso;
  const score = dayScore(arc, activeIso);
  const full = isDayFull(arc, activeIso);
  const evalw = evaluateWeeks(arc, iso);
  const weekI = weekIndexForDay(clamped);
  const week = evalw.weeks[weekI];
  const log = arc.days[activeIso];
  const rules = rulesOf(arc);
  const [gratitudeOpen, setGratitudeOpen] = useState(false);
  const [gratitudeText, setGratitudeText] = useState(log?.gratitude ?? "");

  function handleToggle(rule: RuleDef) {
    if (rule.id === "gratitude" && !log?.checks.gratitude) {
      setGratitudeOpen(true);
      return;
    }
    const wasFull = isDayFull(arc, activeIso);
    toggleCheck(activeIso, rule.id);
    window.setTimeout(() => {
      const snap = useArcStore.getState().arc;
      if (snap && !wasFull && isDayFull(snap, activeIso)) toast("Journée pleine.");
    }, 30);
  }

  function saveGratitude() {
    if (!gratitudeText.trim()) return;
    setGratitude(activeIso, gratitudeText);
    setGratitudeOpen(false);
    toast("Gratitude notée.");
  }

  return (
    <div className="flex flex-1 flex-col overflow-hidden">
      <header className="px-5 pb-4 pt-[max(1.25rem,env(safe-area-inset-top))]">
        <p className="text-[11px] tracking-[0.22em] text-muted uppercase">
          {formatFr(activeIso)}
        </p>
        <div className="mt-2 flex items-end justify-between gap-4">
          <h1 className="font-serif text-[3.4rem] leading-none tracking-tight">
            {clamped}
            <span className="ml-2 font-sans text-[1.05rem] font-normal text-muted">/ 90</span>
          </h1>
          <div className="mb-1 text-right">
            <div className="text-[13px] tabular-nums text-fg">
              {score.done} sur {score.total}
            </div>
            <div className="text-[11px] text-muted">{full ? "Journée pleine" : "En cours"}</div>
          </div>
        </div>
        <p className="mt-4 max-w-[22rem] text-[13px] leading-relaxed text-muted">
          {quoteForDay(clamped)}
        </p>
        {week && (
          <div className="mt-5 flex gap-1.5">
            {week.days.map((d) => (
              <span
                key={d.iso}
                className={cn(
                  "h-1.5 flex-1 rounded-full",
                  d.full ? "bg-ok" : d.future ? "bg-line" : "bg-ember/70",
                )}
              />
            ))}
          </div>
        )}
      </header>

      <ul className="flex-1 overflow-y-auto px-4 pb-36">
        {rules.map((rule) => {
          const checked = Boolean(arc.days[activeIso]?.checks[rule.id]);
          const weekly =
            rule.cadence === "weekly" ? weeklyProgress(arc, weekI, rule) : null;
          return (
            <li
              key={rule.id}
              className="flex items-center gap-3 border-b border-line py-3 last:border-0"
            >
              <span className="grid size-10 shrink-0 place-items-center rounded-md bg-surface text-ice">
                <RuleGlyph name={rule.icon} className="size-[18px]" />
              </span>
              <div className="min-w-0 flex-1">
                <div className="truncate text-[14px] font-medium">{rule.title}</div>
                <div className="truncate text-[12px] text-muted">
                  {weekly
                    ? `${weekly.done} / ${weekly.target} cette semaine`
                    : rule.detail}
                </div>
              </div>
              <HoldConfirm
                confirmed={checked}
                onConfirm={() => handleToggle(rule)}
                label={rule.title}
              />
            </li>
          );
        })}
      </ul>

      {gratitudeOpen && (
        <div className="absolute inset-0 z-20 flex items-end bg-bg/70">
          <div className="w-full rounded-t-xl border-t border-line bg-surface px-5 pb-[max(1.25rem,env(safe-area-inset-bottom))] pt-5">
            <h3 className="font-serif text-[1.6rem]">Une chose, ce soir.</h3>
            <textarea
              autoFocus
              value={gratitudeText}
              onChange={(e) => setGratitudeText(e.target.value)}
              rows={3}
              placeholder="Aujourd'hui je suis reconnaissant pour…"
              className="mt-3 w-full resize-none rounded-md border border-line bg-raised px-3 py-2.5 text-[14px] text-fg outline-none placeholder:text-faint"
            />
            <div className="mt-3 flex gap-2">
              <button
                type="button"
                onClick={() => setGratitudeOpen(false)}
                className="h-12 flex-1 rounded-md text-[14px] text-muted"
              >
                Plus tard
              </button>
              <button
                type="button"
                onClick={saveGratitude}
                className="h-12 flex-1 rounded-md bg-fg text-[14px] font-medium text-bg"
              >
                Valider
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
