import { useState } from "react";
import { Frame } from "./frame";

const SHARDS = [
  { clip: "polygon(-0.5% -0.7%, 89.9% -0.7%, 100.0% 73.0%, 12.5% 99.4%, -0.5% 100.0%)", l: "0.00%", t: "0.00%", w: "30.27%", h: "23.08%", fw: "330.3%", fh: "433.3%", fl: "-0.0%", ft: "-0.0%", x: -91, y: -104, r: -18, d: 32 },
  { clip: "polygon(0.0% -0.5%, 100.0% -0.5%, 68.6% 100.0%, 9.3% 80.8%)", l: "26.85%", t: "0.00%", w: "32.91%", h: "20.89%", fw: "303.9%", fh: "478.8%", fl: "-81.6%", ft: "-0.0%", x: -40, y: -86, r: -5, d: 31 },
  { clip: "polygon(41.3% -0.7%, 79.2% -0.7%, 100.0% 80.6%, 63.9% 100.0%, 14.9% 95.9%, 0.0% 88.8%)", l: "49.17%", t: "0.00%", w: "25.05%", h: "23.47%", fw: "399.2%", fh: "426.2%", fl: "-196.3%", ft: "-0.0%", x: 45, y: -97, r: 15, d: 27 },
  { clip: "polygon(0.0% -0.5%, 100.5% -0.5%, 100.5% 76.9%, 16.7% 100.0%)", l: "68.72%", t: "0.00%", w: "31.28%", h: "18.99%", fw: "319.6%", fh: "526.6%", fl: "-219.6%", ft: "-0.0%", x: 92, y: -135, r: 5, d: 35 },
  { clip: "polygon(-0.6% 100.0%, -0.6% 0.5%, 10.7% 0.0%, 100.0% 55.3%, 99.7% 69.6%, 93.4% 78.4%, 58.4% 94.2%)", l: "0.00%", t: "22.66%", w: "34.78%", h: "24.14%", fw: "287.5%", fh: "414.2%", fl: "-0.0%", ft: "-93.9%", x: -85, y: 27, r: 1, d: 15 },
  { clip: "polygon(62.5% 100.0%, 0.0% 31.4%, 53.3% 0.0%, 92.5% 20.6%, 100.0% 29.2%)", l: "3.51%", t: "16.71%", w: "49.72%", h: "19.46%", fw: "201.1%", fh: "513.8%", fl: "-7.1%", ft: "-85.8%", x: -51, y: -86, r: -2, d: 19 },
  { clip: "polygon(0.0% 100.0%, 0.2% 80.0%, 42.0% 0.0%, 69.4% 5.6%, 100.0% 63.5%, 85.6% 92.5%)", l: "34.22%", t: "22.28%", w: "44.67%", h: "17.24%", fw: "223.9%", fh: "580.0%", fl: "-76.6%", ft: "-129.2%", x: 42, y: -49, r: -8, d: 10 },
  { clip: "polygon(100.6% 0.0%, 100.6% 100.0%, 38.9% 96.1%, 0.0% 45.4%, 25.8% 22.3%)", l: "64.92%", t: "14.40%", w: "35.08%", h: "19.68%", fw: "285.0%", fh: "508.0%", fl: "-185.0%", ft: "-73.2%", x: 80, y: -5, r: 18, d: 22 },
  { clip: "polygon(-0.5% 60.9%, -0.5% 7.6%, 49.1% 0.0%, 100.0% 89.5%, 48.5% 100.0%)", l: "0.00%", t: "45.17%", w: "41.34%", h: "18.45%", fw: "241.9%", fh: "542.1%", fl: "-0.0%", ft: "-244.9%", x: -115, y: 147, r: -21, d: 19 },
  { clip: "polygon(39.9% 92.7%, 0.0% 17.3%, 23.1% 0.0%, 96.8% 65.6%, 100.0% 75.3%, 91.4% 85.6%, 59.7% 100.0%)", l: "19.90%", t: "41.37%", w: "52.65%", h: "21.91%", fw: "189.9%", fh: "456.5%", fl: "-37.8%", ft: "-188.9%", x: -19, y: 217, r: -7, d: 12 },
  { clip: "polygon(96.0% 100.0%, 0.0% 19.2%, 5.5% 7.2%, 100.0% 0.0%)", l: "32.07%", t: "38.10%", w: "40.43%", h: "17.79%", fw: "247.4%", fh: "562.1%", fl: "-79.3%", ft: "-214.2%", x: 43, y: 142, r: -7, d: 2 },
  { clip: "polygon(100.7% 3.1%, 100.7% 100.0%, 5.6% 99.8%, 0.0% 91.3%, 5.5% 20.1%, 27.4% 0.0%)", l: "70.52%", t: "33.06%", w: "29.48%", h: "24.97%", fw: "339.2%", fh: "400.6%", fl: "-239.2%", ft: "-132.4%", x: 119, y: 84, r: 14, d: 15 },
  { clip: "polygon(-0.4% 100.0%, -0.4% 0.0%, 100.0% 30.5%, 45.9% 97.9%)", l: "0.00%", t: "56.22%", w: "20.15%", h: "23.71%", fw: "496.3%", fh: "421.8%", fl: "-0.0%", ft: "-237.1%", x: -112, y: 220, r: -21, d: 32 },
  { clip: "polygon(0.0% 95.9%, 25.6% 10.3%, 75.5% 0.0%, 100.0% 8.5%, 74.8% 84.7%, 12.5% 100.0%)", l: "8.99%", t: "61.49%", w: "42.63%", h: "18.70%", fw: "234.6%", fh: "534.8%", fl: "-21.1%", ft: "-328.9%", x: -59, y: 273, r: 0, d: 29 },
  { clip: "polygon(0.0% 65.0%, 27.3% 11.8%, 69.8% 0.0%, 100.0% 87.6%, 87.9% 94.6%, 54.4% 100.0%)", l: "40.48%", t: "59.87%", w: "39.27%", h: "26.78%", fw: "254.6%", fh: "373.4%", fl: "-103.1%", ft: "-223.5%", x: 18, y: 285, r: -3, d: 32 },
  { clip: "polygon(100.6% 0.2%, 100.6% 94.6%, 36.7% 100.0%, 0.0% 8.7%, 14.0% 0.0%)", l: "67.63%", t: "57.72%", w: "32.37%", h: "25.72%", fw: "308.9%", fh: "388.9%", fl: "-208.9%", ft: "-224.4%", x: 72, y: 249, r: 15, d: 29 },
  { clip: "polygon(100.0% 100.7%, -0.4% 100.7%, -0.4% 2.3%, 25.6% 0.0%, 40.4% 3.7%)", l: "0.00%", t: "79.22%", w: "35.90%", h: "20.78%", fw: "278.6%", fh: "481.3%", fl: "-0.0%", ft: "-381.3%", x: -92, y: 324, r: -20, d: 46 },
  { clip: "polygon(62.3% 100.6%, 44.6% 100.6%, 0.0% 12.5%, 55.4% 0.0%, 100.0% 41.0%)", l: "14.19%", t: "77.11%", w: "47.93%", h: "22.89%", fw: "208.7%", fh: "436.9%", fl: "-29.6%", ft: "-336.9%", x: -32, y: 317, r: -8, d: 44 },
  { clip: "polygon(100.0% 100.6%, 0.0% 100.6%, 40.6% 9.7%, 70.2% 0.0%)", l: "43.73%", t: "85.00%", w: "44.52%", h: "15.00%", fw: "224.6%", fh: "666.6%", fl: "-98.2%", ft: "-566.6%", x: 22, y: 280, r: -4, d: 48 },
  { clip: "polygon(100.5% 0.0%, 100.5% 100.7%, 52.5% 100.7%, 0.0% 17.8%, 18.7% 7.6%)", l: "74.70%", t: "81.79%", w: "25.30%", h: "18.21%", fw: "395.3%", fh: "549.0%", fl: "-295.3%", ft: "-449.0%", x: 75, y: 279, r: 16, d: 48 },
];

export function IceBreak({ onBroken }: { onBroken: () => void }) {
  const [taps, setTaps] = useState(0);
  const [leaving, setLeaving] = useState(false);
  const [impacts, setImpacts] = useState<{ id: number; x: number; y: number }[]>([]);
  const [flash, setFlash] = useState(0);

  function tap(e: React.PointerEvent<HTMLButtonElement>) {
    if (leaving) return;
    const rect = e.currentTarget.getBoundingClientRect();
    const x = ((e.clientX - rect.left) / rect.width) * 100;
    const y = ((e.clientY - rect.top) / rect.height) * 100;
    setImpacts((prev) => [...prev.slice(-4), { id: Date.now() + Math.random(), x, y }]);
    setFlash((n) => n + 1);
    const next = taps + 1;
    setTaps(next);
    if (next >= 3) {
      setLeaving(true);
      window.setTimeout(onBroken, 1150);
    }
  }

  return (
    <Frame>
      <button
        type="button"
        onPointerDown={tap}
        className="relative z-[1] flex min-h-dvh w-full flex-col items-center justify-center overflow-hidden px-6 text-center md:min-h-[844px]"
      >
        {!leaving && <IcePane taps={taps} />}
        {leaving &&
          SHARDS.map((s, i) => (
            <span
              key={i}
              className="ice-shard pointer-events-none absolute"
              style={{
                left: s.l,
                top: s.t,
                width: s.w,
                height: s.h,
                clipPath: s.clip,
                ["--dx" as string]: `${s.x}px`,
                ["--dy" as string]: `${s.y}px`,
                ["--rot" as string]: `${s.r}deg`,
                animation: `ice-shatter 1000ms cubic-bezier(0.22, 1, 0.36, 1) ${s.d}ms both`,
              }}
            >
              <span className="ice-fill-lite" style={{ width: s.fw, height: s.fh, left: s.fl, top: s.ft }} />
            </span>
          ))}

        <Cracks taps={taps} leaving={leaving} />

        {impacts.map((p) => (
          <span
            key={p.id}
            className="ice-ripple pointer-events-none absolute size-4 rounded-full"
            style={{ left: `${p.x}%`, top: `${p.y}%` }}
          />
        ))}

        <span
          key={flash}
          className="pointer-events-none absolute inset-0 bg-ice/30"
          style={{ animation: flash ? "ice-flash 420ms ease-out both" : undefined }}
        />

        <div
          className="relative z-[2]"
          style={{
            opacity: leaving ? 0 : 1,
            transform: leaving ? "scale(0.98)" : "scale(1)",
            transition: "opacity 400ms ease, transform 400ms ease",
          }}
        >
          <p className="text-[11px] tracking-[0.28em] text-ice uppercase">Jour 1</p>
          <h1 className="mt-4 font-serif text-[2.6rem] leading-[1.05] tracking-tight text-fg">
            Ton arc est pris
            <br />
            dans la glace.
          </h1>
          <p className="mx-auto mt-5 max-w-[16rem] text-[14px] text-muted">
            {taps >= 3
              ? "Ça se brise."
              : `Trois taps pour la briser. ${3 - taps} restant${3 - taps > 1 ? "s" : ""}.`}
          </p>
        </div>
      </button>
    </Frame>
  );
}

function IcePane({ taps: _taps }: { taps: number }) {
  return (
    <span
      className="ice-fill pointer-events-none absolute inset-0"
      style={{ boxShadow: "inset 0 0 80px rgba(190, 230, 245, 0.12)" }}
    />
  );
}

function Cracks({ taps, leaving }: { taps: number; leaving: boolean }) {
  return (
    <svg
      className="pointer-events-none absolute inset-0 h-full w-full"
      viewBox="0 0 390 844"
      preserveAspectRatio="xMidYMid slice"
      style={{ opacity: leaving ? 0 : 1, transition: "opacity 280ms ease" }}
    >
      <defs>
        <filter id="crack-glow" x="-20%" y="-20%" width="140%" height="140%">
          <feGaussianBlur stdDeviation="1.2" result="b" />
          <feMerge>
            <feMergeNode in="b" />
            <feMergeNode in="SourceGraphic" />
          </feMerge>
        </filter>
      </defs>
      <g
        fill="none"
        stroke="#e8f4fa"
        strokeLinecap="round"
        strokeLinejoin="round"
        filter="url(#crack-glow)"
      >
        <CrackPath
          d="M196 0 L204 150 L168 250 L248 360 L190 520 L220 844"
          show={taps >= 1}
          w={2.2}
        />
        <CrackPath d="M204 150 L310 120 L390 168" show={taps >= 1} w={1.4} />
        <CrackPath d="M168 250 L70 210 L0 248" show={taps >= 1} w={1.3} />
        <CrackPath d="M168 250 L120 340 L40 420" show={taps >= 2} w={1.5} />
        <CrackPath d="M248 360 L340 320 L390 360" show={taps >= 2} w={1.4} />
        <CrackPath d="M248 360 L300 470 L360 560 L390 620" show={taps >= 2} w={1.6} />
        <CrackPath d="M190 520 L90 500 L0 560" show={taps >= 2} w={1.3} />
        <CrackPath d="M190 520 L140 640 L80 760" show={taps >= 3} w={1.8} />
        <CrackPath d="M220 620 L300 700 L340 820" show={taps >= 3} w={1.6} />
        <CrackPath d="M310 120 L280 60 L300 0" show={taps >= 3} w={1.1} />
        <CrackPath d="M70 210 L90 80 L40 0" show={taps >= 3} w={1.1} />
        <CrackPath d="M300 470 L250 430 L210 470" show={taps >= 3} w={1} />
      </g>
    </svg>
  );
}

function CrackPath({ d, show, w }: { d: string; show: boolean; w: number }) {
  return (
    <path
      d={d}
      pathLength={1}
      strokeWidth={show ? w : 0}
      className={show ? "ice-crack" : undefined}
      opacity={show ? 0.9 : 0}
    />
  );
}
