import { useEffect, useState } from "react";
import {
  dayNumber,
  isBeforeStart,
  isComplete,
} from "@/lib/arc";
import { useArcStore } from "@/lib/store";
import type { Arc } from "@/lib/types";
import { usePremiumStore } from "@/lib/premium/store";
import { Complete } from "./complete";
import { ConfirmSheet } from "./confirm-sheet";
import { Countdown } from "./countdown";
import { FlameView } from "./flame-view";
import { Frame } from "./frame";
import { Grid90 } from "./grid-90";
import { IceBreak } from "./ice-break";
import { Profile } from "./profile";
import { TabBar } from "./tab-bar";
import { Today } from "./today";

export function AppShell({ arc }: { arc: Arc }) {
  const tab = useArcStore((s) => s.tab);
  const setTab = useArcStore((s) => s.setTab);
  const breakIce = useArcStore((s) => s.breakIce);
  const reset = useArcStore((s) => s.reset);
  const [, setTick] = useState(0);
  const [resetOpen, setResetOpen] = useState(false);

  useEffect(() => {
    const bump = () => setTick((n) => n + 1);
    const recheck = () => {
      if (document.visibilityState === "visible") void usePremiumStore.getState().refresh();
    };
    recheck();
    document.addEventListener("visibilitychange", recheck);
    const id = window.setInterval(bump, 60_000);
    document.addEventListener("visibilitychange", bump);
    return () => {
      window.clearInterval(id);
      document.removeEventListener("visibilitychange", bump);
      document.removeEventListener("visibilitychange", recheck);
    };
  }, []);

  if (isBeforeStart(arc)) {
    return <Countdown arc={arc} onReset={reset} />;
  }

  const n = dayNumber(arc);
  if (n >= 1 && n <= 90 && !arc.iceBroken) {
    return <IceBreak onBroken={breakIce} />;
  }

  if (isComplete(arc)) {
    return <Complete arc={arc} />;
  }

  return (
    <Frame>
      <div className="relative z-[1] flex h-dvh flex-1 flex-col overflow-hidden md:h-[844px]">
        {tab === "jour" && <Today arc={arc} />}
        {tab === "cases" && <Grid90 arc={arc} />}
        {tab === "flamme" && <FlameView arc={arc} />}
        {tab === "toi" && <Profile arc={arc} onAskReset={() => setResetOpen(true)} />}
        <TabBar tab={tab} onChange={setTab} />
        <ConfirmSheet
          open={resetOpen}
          title="Recommencer un arc ?"
          body="Ça efface cet arc et tes validations. Les 90 jours repartent de zéro."
          confirmLabel="Effacer l'arc"
          onCancel={() => setResetOpen(false)}
          onConfirm={() => {
            setResetOpen(false);
            reset();
          }}
        />
      </div>
    </Frame>
  );
}
