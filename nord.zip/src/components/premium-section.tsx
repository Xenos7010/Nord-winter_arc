import { Check } from "lucide-react";
import { usePremiumStore } from "@/lib/premium/store";

/** Section "NORD Premium" des paramètres (onglet Toi) : compte Google Play, achat et restauration. */
export function PremiumSection() {
  const { status, reason, pending, price, busy, event, buy, restore } = usePremiumStore();

  const account =
    status === "premium"
      ? "NORD Premium"
      : status === "free"
        ? "Connecté à Google Play · Gratuit"
        : status === "checking"
          ? "Vérification…"
          : "Non connecté à Google Play";

  const detail =
    status === "premium"
      ? event === "purchased"
        ? "Achat effectué."
        : event === "restored"
          ? "Achat restauré."
          : "Achat validé par Google Play."
      : status === "unavailable"
        ? reason === "web"
          ? "Disponible dans l'application Android."
          : "Connexion à Google Play impossible pour l'instant."
        : null;

  return (
    <section className="mt-10">
      <h2 className="text-[11px] tracking-[0.2em] text-muted uppercase">NORD Premium</h2>
      <div className="mt-3 rounded-lg border border-line bg-surface px-4 py-4">
        <div className="flex items-start justify-between gap-3">
          <div>
            <p className="font-serif text-[1.35rem] leading-tight">{account}</p>
            {detail && <p className="mt-1 text-[12px] text-muted">{detail}</p>}
          </div>
          {status === "premium" && <Check className="mt-1 size-4 shrink-0 text-ok" />}
        </div>

        {status !== "premium" && (
          <>
            <ul className="mt-3 space-y-1.5 text-[12px] leading-relaxed text-muted">
              <li>· Couleur de ta flamme : Braise, Or, Rouge, Glace</li>
              <li>· Exercices bonus et tes propres exercices</li>
              <li>· Paliers, défis et synthèse détaillée</li>
            </ul>
            <p className="mt-3 text-[12px] leading-relaxed text-faint">
              Les 90 jours sont à toi, avec ou sans Premium. Achat unique, sans abonnement, conservé par ton compte Google Play.
            </p>
          </>
        )}
        {status === "free" && pending && (
          <p className="mt-3 text-[12px] text-ice">Paiement en attente chez Google Play.</p>
        )}

        {status === "free" && (
          <button
            type="button"
            disabled={busy || pending}
            onClick={() => void buy()}
            className="mt-4 h-11 w-full rounded-md bg-fg text-[14px] font-medium text-bg transition-opacity disabled:opacity-50"
          >
            Débloquer NORD Premium · {price}
          </button>
        )}

        <button
          type="button"
          disabled={busy}
          onClick={() => void restore()}
          className="mt-3 h-10 w-full rounded-md border border-line text-[13px] text-fg disabled:opacity-50"
        >
          Restaurer mes achats
        </button>
      </div>
    </section>
  );
}
