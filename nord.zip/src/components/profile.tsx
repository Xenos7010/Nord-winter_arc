import { Camera, Lock } from "lucide-react";
import { useRef } from "react";
import { toast } from "sonner";
import { dayNumber, rulesOf } from "@/lib/arc";
import { PROGRAM_MAP } from "@/lib/catalog";
import { useArcStore } from "@/lib/store";
import type { Arc } from "@/lib/types";
import { compressImage, formatFr, todayISO } from "@/lib/utils";
import { Personalize } from "./personalize";
import { PremiumSection } from "./premium-section";
import { useIsPremium } from "@/lib/premium/store";
import { RuleGlyph } from "./rule-icon";

export function Profile({ arc, onAskReset }: { arc: Arc; onAskReset: () => void }) {
  const premium = useIsPremium();
  const setPhoto = useArcStore((s) => s.setPhoto);
  const n = dayNumber(arc);
  const unlocked = n >= 90;
  const program = PROGRAM_MAP[arc.programId];
  const rules = rulesOf(arc);
  const day1Ref = useRef<HTMLInputElement>(null);
  const day90Ref = useRef<HTMLInputElement>(null);

  async function onFile(slot: "day1" | "day90", file?: File) {
    if (!file) return;
    try {
      const data = await compressImage(file);
      setPhoto(slot, data);
      toast(slot === "day1" ? "Photo du jour 1 verrouillée." : "Photo du jour 90 enregistrée.");
    } catch {
      toast("Impossible de lire cette image.");
    }
  }

  return (
    <div className="flex flex-1 flex-col overflow-y-auto px-5 pb-36 pt-[max(1.25rem,env(safe-area-inset-top))]">
      <p className="text-[11px] tracking-[0.22em] text-muted uppercase">Toi</p>
      <h1 className="mt-2 font-serif text-[2.4rem] leading-tight tracking-tight">{arc.signerName}</h1>
      <p className="mt-1 text-[13px] text-muted">
        {program?.name} · départ {formatFr(arc.startDate, { day: "numeric", month: "long" })}
      </p>

      {arc.signatureData && (
        <img
          src={arc.signatureData}
          alt="Signature"
          className="mt-4 h-14 w-auto max-w-[200px] object-contain opacity-80"
        />
      )}

      <h2 className="mt-8 text-[11px] tracking-[0.2em] text-muted uppercase">Jour 1 vs jour 90</h2>
      <p className="mt-2 text-[13px] leading-relaxed text-muted">
        La photo du premier jour reste verrouillée jusqu'au jour 90 — même pour toi. Rien ne quitte cet appareil.
      </p>
      <div className="mt-4 grid grid-cols-2 gap-3">
        <PhotoSlot
          label="Jour 1"
          src={arc.photos.day1}
          locked={Boolean(arc.photos.day1) && !unlocked}
          onPick={() => day1Ref.current?.click()}
        />
        <PhotoSlot
          label="Jour 90"
          src={arc.photos.day90}
          locked={false}
          disabled={n < 90 && !arc.photos.day90}
          onPick={() => day90Ref.current?.click()}
        />
      </div>
      <input
        ref={day1Ref}
        type="file"
        accept="image/*"
        capture="user"
        className="hidden"
        onChange={(e) => onFile("day1", e.target.files?.[0])}
      />
      <input
        ref={day90Ref}
        type="file"
        accept="image/*"
        capture="user"
        className="hidden"
        onChange={(e) => onFile("day90", e.target.files?.[0])}
      />

      <h2 className="mt-10 text-[11px] tracking-[0.2em] text-muted uppercase">Le contrat</h2>
      <ul className="mt-3 space-y-3">
        {rules.map((r) => (
          <li key={r.id} className="flex gap-3">
            <span className="mt-0.5 text-ice">
              <RuleGlyph name={r.icon} className="size-4" />
            </span>
            <span>
              <span className="block text-[14px]">{r.title}</span>
              <span className="block text-[12px] text-muted">{r.detail}</span>
            </span>
          </li>
        ))}
      </ul>

      <PremiumSection />
      {premium && <Personalize arc={arc} />}

      <button
        type="button"
        onClick={onAskReset}
        className="mt-10 h-12 rounded-md border border-line text-[13px] text-muted"
      >
        Terminer / recommencer
      </button>
      {arc.demo && (
        <p className="mt-3 text-center text-[12px] text-faint">
          Arc de démonstration · jour {Math.min(90, Math.max(1, n))} · {todayISO()}
        </p>
      )}
    </div>
  );
}

function PhotoSlot({
  label,
  src,
  locked,
  disabled,
  onPick,
}: {
  label: string;
  src?: string;
  locked: boolean;
  disabled?: boolean;
  onPick: () => void;
}) {
  return (
    <button
      type="button"
      onClick={onPick}
      disabled={disabled}
      className="relative aspect-[3/4] overflow-hidden rounded-lg bg-raised text-left"
    >
      {src && (
        <img
          src={src}
          alt=""
          className={locked ? "h-full w-full object-cover blur-xl scale-110" : "h-full w-full object-cover"}
        />
      )}
      <span className="absolute inset-x-0 bottom-0 bg-gradient-to-t from-bg/80 to-transparent px-3 py-2 text-[12px]">
        {label}
      </span>
      {!src && (
        <span className="absolute inset-0 grid place-items-center text-faint">
          <Camera className="size-6" />
        </span>
      )}
      {locked && (
        <span className="absolute inset-0 grid place-items-center bg-bg/30">
          <Lock className="size-6 text-fg" />
        </span>
      )}
    </button>
  );
}
