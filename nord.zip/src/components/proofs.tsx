import { Check } from "lucide-react";
import { MILESTONES, challenges, progressStats, reachedMilestones } from "@/lib/progress";
import type { Arc } from "@/lib/types";
import { cn } from "@/lib/utils";

export function Proofs({ arc }: { arc: Arc }) {
  const st = progressStats(arc);
  const list = challenges(arc, st);
  const reached = reachedMilestones(arc);

  const figures: [string, string | number][] = [
    ["Jours terminés", st.doneDays],
    ["Série en cours", st.streak],
    ["Meilleure série", st.bestStreak],
    ["Journées parfaites", st.perfectDays],
    ["Progression", `${st.percent} %`],
    ["Gel", arc.gelUsed ? "Utilisé" : "Intact"],
  ];

  return (
    <section className="mt-12">
      <p className="text-[11px] tracking-[0.22em] text-muted uppercase">Preuves</p>
      <dl className="mt-5 grid grid-cols-2 gap-x-6 gap-y-6">
        {figures.map(([label, value]) => (
          <div key={label}>
            <dd className="font-serif text-[1.9rem] leading-none tabular-nums">{value}</dd>
            <dt className="mt-1.5 text-[11px] tracking-wide text-muted">{label}</dt>
          </div>
        ))}
      </dl>

      <p className="mt-10 text-[11px] tracking-[0.22em] text-muted uppercase">Paliers</p>
      <ol className="mt-4 flex items-start justify-between">
        {MILESTONES.map((m) => {
          const ok = reached.includes(m.day);
          return (
            <li key={m.day} className="flex w-9 flex-col items-center gap-2">
              <span className={cn("size-2.5 rounded-full", ok ? "bg-ember" : "border border-line")} />
              <span className={cn("text-[11px] tabular-nums", ok ? "text-fg" : "text-faint")}>{m.day}</span>
            </li>
          );
        })}
      </ol>

      <p className="mt-10 text-[11px] tracking-[0.22em] text-muted uppercase">Défis</p>
      <ul className="mt-3">
        {list.map((c) => (
          <li key={c.id} className="border-b border-line py-3 last:border-0">
            <div className="flex items-center justify-between text-[13px]">
              <span className={c.done ? "text-fg" : "text-muted"}>{c.label}</span>
              {c.done ? (
                <Check className="size-4 text-ok" />
              ) : c.failed ? (
                <span className="text-[12px] text-faint">Gel utilisé</span>
              ) : (
                <span className="text-[12px] tabular-nums text-muted">
                  {c.value} / {c.target}
                </span>
              )}
            </div>
            {!c.done && !c.failed && (
              <div className="mt-2 h-[3px] overflow-hidden rounded-full bg-line">
                <div className="h-full rounded-full bg-ember/70" style={{ width: `${(c.value / c.target) * 100}%` }} />
              </div>
            )}
          </li>
        ))}
      </ul>
    </section>
  );
}
