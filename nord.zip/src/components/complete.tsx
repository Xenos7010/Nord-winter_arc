import { summary } from "@/lib/progress";
import { useArcStore } from "@/lib/store";
import type { Arc } from "@/lib/types";
import { Frame } from "./frame";
import { useIsPremium } from "@/lib/premium/store";
import { LivingFlame } from "./living-flame";

export function Complete({ arc }: { arc: Arc }) {
  const reset = useArcStore((s) => s.reset);
  const sm = summary(arc);
  const premium = useIsPremium();

  return (
    <Frame>
      <div className="relative z-[1] flex min-h-dvh flex-col px-6 pb-[max(1.5rem,env(safe-area-inset-bottom))] pt-[max(2rem,env(safe-area-inset-top))] md:min-h-[844px]">
        <div className="flex items-center justify-between">
          <p className="text-[11px] tracking-[0.24em] text-ice uppercase">90 jours terminés</p>
          <LivingFlame size={64} day={90} />
        </div>
        <h1 className="mt-3 font-serif text-[2.6rem] leading-tight tracking-tight">
          Voilà ce que 90 jours ont changé.
        </h1>
        <div className="mt-8 grid flex-1 grid-cols-2 gap-3">
          <figure className="overflow-hidden rounded-lg bg-raised">
            {arc.photos.day1 ? (
              <img src={arc.photos.day1} alt="Jour 1" className="h-full min-h-48 w-full object-cover" />
            ) : (
              <div className="grid h-full min-h-48 place-items-center text-[12px] text-faint">Pas de photo jour 1</div>
            )}
            <figcaption className="px-3 py-2 text-[12px] text-muted">Jour 1</figcaption>
          </figure>
          <figure className="overflow-hidden rounded-lg bg-raised">
            {arc.photos.day90 ? (
              <img src={arc.photos.day90} alt="Jour 90" className="h-full min-h-48 w-full object-cover" />
            ) : (
              <div className="grid h-full min-h-48 place-items-center text-[12px] text-faint">Pas de photo jour 90</div>
            )}
            <figcaption className="px-3 py-2 text-[12px] text-muted">Jour 90</figcaption>
          </figure>
        </div>
        <section className="mt-8">
          <dl className="grid grid-cols-2 gap-x-6 gap-y-6">
            {(
              [
                ["Progression totale", `${sm.overall} %`],
                ["Journées parfaites", sm.st.perfectDays],
                ["Série maximale", sm.st.bestStreak],
                ["Défis terminés", `${sm.challengesDone} / ${sm.challengesTotal}`],
                ["Gel", arc.gelUsed ? "Utilisé" : "Intact"],
                ["Jours terminés", sm.st.doneDays],
              ] as [string, string | number][]
            ).map(([label, value]) => (
              <div key={label}>
                <dd className="font-serif text-[1.9rem] leading-none tabular-nums">{value}</dd>
                <dt className="mt-1.5 text-[11px] tracking-wide text-muted">{label}</dt>
              </div>
            ))}
          </dl>

          {!premium && (
            <p className="mt-10 text-[12px] leading-relaxed text-muted">
              Règles les plus tenues et comparaison début / fin : NORD Premium.
            </p>
          )}
          {premium && (
            <>
          <p className="mt-10 text-[11px] tracking-[0.22em] text-muted uppercase">Règles les plus tenues</p>
          <ul className="mt-3">
            {sm.ruleRates.map((r) => (
              <li key={r.title} className="flex justify-between border-b border-line py-3 text-[13px] last:border-0">
                <span className="mr-4 truncate text-muted">{r.title}</span>
                <span className="tabular-nums">{r.pct} %</span>
              </li>
            ))}
          </ul>

          <p className="mt-10 text-[11px] tracking-[0.22em] text-muted uppercase">Début et fin</p>
          <div className="mt-3 flex justify-between text-[13px]">
            <span className="text-muted">Jours 1 à 30</span>
            <span className="tabular-nums">{sm.firstRate} % de jours pleins</span>
          </div>
          <div className="mt-2 flex justify-between text-[13px]">
            <span className="text-muted">Jours 61 à 90</span>
            <span className="tabular-nums">{sm.lastRate} % de jours pleins</span>
          </div>
            </>
          )}
        </section>
        <p className="mt-8 text-[14px] text-muted">
          {arc.signerName}. Un autre arc peut commencer quand tu veux.
        </p>
        <button
          type="button"
          onClick={reset}
          className="mt-6 flex h-14 items-center justify-center rounded-[18px] bg-fg text-[15px] font-medium text-bg"
        >
          Nouvel arc
        </button>
      </div>
    </Frame>
  );
}
