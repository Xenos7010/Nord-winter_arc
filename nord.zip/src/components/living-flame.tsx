import { flameStage } from "@/lib/progress";
import { cn } from "@/lib/utils";

type Props = {
  size?: number;
  out?: boolean;
  frozen?: boolean;
  /** Numéro du jour (1-90) : fait évoluer la taille et l'éclat de la flamme. */
  day?: number;
  /** Petit éclat bref (validation d'une journée). */
  flare?: boolean;
  className?: string;
};

export function LivingFlame({ size = 180, out = false, frozen = false, day, flare = false, className }: Props) {
  const stage = day ? flameStage(day) : null;
  const scale = stage?.scale ?? 1;
  const glow = stage?.glow ?? 1;
  return (
    <div
      className={cn("relative isolate grid place-items-center", className)}
      style={{ width: size, height: size }}
      aria-hidden
    >
      <div
        className={cn("flame-stage absolute inset-0 grid place-items-center", flare && "flame-flare")}
        style={{ ["--s" as string]: scale }}
      >
        <span
          className={cn("flame-halo pointer-events-none absolute inset-[-34%]", !out && "flame-glow")}
          style={{ ["--g" as string]: out ? 0.3 : glow }}
        />
        <img
          src="/flame.png"
          alt=""
          className={cn(
            "relative h-[112%] w-[112%] max-w-none object-contain",
            "select-none",
            !out && !frozen && "flame-shimmer",
            frozen && !out && "flame-frozen",
            out && "flame-out",
          )}
          draggable={false}
        />
      </div>
    </div>
  );
}
