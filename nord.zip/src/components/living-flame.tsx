import { cn } from "@/lib/utils";

type Props = {
  size?: number;
  out?: boolean;
  frozen?: boolean;
  className?: string;
};

export function LivingFlame({ size = 180, out = false, frozen = false, className }: Props) {
  return (
    <div
      className={cn("relative isolate grid place-items-center", className)}
      style={{ width: size, height: size }}
      aria-hidden
    >
      <span
        className={cn(
          "pointer-events-none absolute inset-[-18%] rounded-full blur-3xl",
          out ? "bg-faint/20" : frozen ? "bg-ice/35" : "bg-ember/40",
          !out && "flame-glow",
        )}
      />
      <img
        src="/flame.png"
        alt=""
        className={cn(
          "relative h-[112%] w-[112%] max-w-none object-contain",
          "select-none",
          !out && !frozen && "flame-shimmer",
          frozen && !out && "flame-frozen",
          out && "flame-out",
        )}
        draggable={false}
      />
      {frozen && !out && (
        <span className="pointer-events-none absolute inset-[18%] rounded-full bg-ice/15 mix-blend-screen" />
      )}
    </div>
  );
}
