import { ARC_LENGTH, dayNumber, isDayFull, isoForDay, rulesOf } from "./arc";
import type { Arc } from "./types";
import { todayISO } from "./utils";

export type Milestone = { day: number; title: string; note: string };

export const MILESTONES: Milestone[] = [
  { day: 7, title: "Première semaine terminée.", note: "Ta flamme a grandi." },
  { day: 14, title: "Deux semaines tenues.", note: "L'habitude s'installe." },
  { day: 30, title: "Premier mois terminé.", note: "Ta flamme a grandi." },
  { day: 45, title: "La moitié du chemin.", note: "Ta flamme est devenue intense." },
  { day: 60, title: "Deux mois tenus.", note: "Il n'en reste que trente." },
  { day: 75, title: "Les quinze derniers jours.", note: "Ta flamme est un brasier." },
  { day: 90, title: "Quatre-vingt-dix jours.", note: "Le feu final." },
];

const STAGES = [
  { from: 1, label: "Étincelle", scale: 0.58, glow: 0.45 },
  { from: 7, label: "Petite flamme", scale: 0.74, glow: 0.6 },
  { from: 30, label: "Flamme", scale: 0.88, glow: 0.75 },
  { from: 45, label: "Flamme intense", scale: 1, glow: 0.9 },
  { from: 75, label: "Brasier", scale: 1.08, glow: 1.1 },
  { from: 90, label: "Feu final", scale: 1.16, glow: 1.3 },
];

export function flameStage(day: number) {
  let stage = STAGES[0];
  for (const s of STAGES) if (day >= s.from) stage = s;
  return stage;
}

export type ProgressStats = {
  day: number;
  percent: number;
  remaining: number;
  doneDays: number;
  perfectDays: number;
  streak: number;
  bestStreak: number;
};

export function progressStats(arc: Arc, iso = todayISO()): ProgressStats {
  const n = dayNumber(arc, iso);
  const day = Math.min(ARC_LENGTH, Math.max(0, n));
  const rules = rulesOf(arc);
  let doneDays = 0;
  let perfectDays = 0;
  let run = 0;
  let best = 0;
  for (let d = 1; d <= day; d++) {
    const dIso = isoForDay(arc, d);
    const full = isDayFull(arc, dIso);
    if (full) {
      doneDays++;
      run++;
      if (run > best) best = run;
      const log = arc.days[dIso];
      if (rules.every((r) => log?.checks[r.id])) perfectDays++;
    } else if (d < n) {
      run = 0;
    }
  }
  return {
    day,
    percent: Math.round((day / ARC_LENGTH) * 100),
    remaining: ARC_LENGTH - day,
    doneDays,
    perfectDays,
    streak: run,
    bestStreak: best,
  };
}

export function reachedMilestones(arc: Arc, iso = todayISO()): number[] {
  const n = dayNumber(arc, iso);
  return MILESTONES.filter(
    (m) => n > m.day || (n === m.day && isDayFull(arc, isoForDay(arc, m.day))),
  ).map((m) => m.day);
}

export function nextMilestone(day: number): Milestone | undefined {
  return MILESTONES.find((m) => m.day > day);
}

const TOMORROW_LINES = [
  "Même geste. Même heure.",
  "Un jour de plus. Pas davantage.",
  "Tu n'as qu'à poursuivre.",
  "Demain ressemble à aujourd'hui. C'est le but.",
  "La série tient parce que tu reviens.",
];

export function tomorrowLine(day: number): string {
  return TOMORROW_LINES[day % TOMORROW_LINES.length];
}

export type Challenge = {
  id: string;
  label: string;
  value: number;
  target: number;
  done: boolean;
  failed?: boolean;
};

export function challenges(arc: Arc, st: ProgressStats): Challenge[] {
  const mk = (id: string, label: string, raw: number, target: number): Challenge => ({
    id,
    label,
    value: Math.min(raw, target),
    target,
    done: raw >= target,
  });
  const noGel: Challenge = {
    id: "nogel",
    label: "30 jours sans le gel",
    value: arc.gelUsed ? 0 : Math.min(st.day, 30),
    target: 30,
    done: !arc.gelUsed && st.day >= 30,
    failed: arc.gelUsed,
  };
  const finished = st.day >= ARC_LENGTH && isDayFull(arc, isoForDay(arc, ARC_LENGTH));
  return [
    mk("s7", "7 jours consécutifs", st.bestStreak, 7),
    mk("s14", "14 jours consécutifs", st.bestStreak, 14),
    mk("s30", "30 jours consécutifs", st.bestStreak, 30),
    mk("p10", "10 journées parfaites", st.perfectDays, 10),
    noGel,
    { id: "end", label: "Terminer les 90 jours", value: st.day, target: ARC_LENGTH, done: finished },
  ];
}

export function summary(arc: Arc) {
  const st = progressStats(arc);
  const rules = rulesOf(arc);
  const rate = (from: number, to: number) => {
    let full = 0;
    for (let d = from; d <= to; d++) if (isDayFull(arc, isoForDay(arc, d))) full++;
    return Math.round((full / (to - from + 1)) * 100);
  };
  const ruleRates = rules
    .map((r) => {
      let count = 0;
      for (let d = 1; d <= ARC_LENGTH; d++) if (arc.days[isoForDay(arc, d)]?.checks[r.id]) count++;
      const denom = r.cadence === "weekly" ? (r.weeklyTarget ?? 1) * Math.ceil(ARC_LENGTH / 7) : ARC_LENGTH;
      return { title: r.title, pct: Math.min(100, Math.round((count / denom) * 100)) };
    })
    .sort((a, b) => b.pct - a.pct)
    .slice(0, 3);
  const ch = challenges(arc, st);
  return {
    st,
    ruleRates,
    challengesDone: ch.filter((c) => c.done).length,
    challengesTotal: ch.length,
    firstRate: rate(1, 30),
    lastRate: rate(61, 90),
    overall: Math.round((st.doneDays / ARC_LENGTH) * 100),
  };
}
