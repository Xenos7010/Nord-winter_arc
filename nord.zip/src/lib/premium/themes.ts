import type { FlameTheme } from "../types";

/** Thèmes de flamme (NORD Premium). La couleur est choisie une fois : la flamme ne change plus ensuite. */
export const FLAME_THEMES: Record<FlameTheme, { label: string; hue: number; rgb: string }> = {
  braise: { label: "Braise", hue: 0, rgb: "212 137 74" },
  or: { label: "Or", hue: 14, rgb: "222 176 72" },
  rouge: { label: "Rouge", hue: -26, rgb: "214 86 70" },
  glace: { label: "Glace", hue: 175, rgb: "110 170 210" },
};
export const FLAME_THEME_IDS = Object.keys(FLAME_THEMES) as FlameTheme[];
