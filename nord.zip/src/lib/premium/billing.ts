import { Capacitor, registerPlugin } from "@capacitor/core";

export type Entitlement = {
  premium: boolean;
  pending: boolean;
  /** "ok" : Google Play joignable. "unavailable" : Play Store absent, hors ligne ou service indisponible. */
  billing: "ok" | "unavailable" | "error";
  purchaseToken?: string;
  orderId?: string;
  message?: string;
};

export type PurchaseResult = {
  status: "purchased" | "pending" | "cancelled" | "already_owned" | "unavailable" | "error";
  message?: string;
};

export type ProductInfo = { available: boolean; price?: string; message?: string };

interface NordBillingPlugin {
  getEntitlement(): Promise<Entitlement>;
  getProduct(): Promise<ProductInfo>;
  purchase(): Promise<PurchaseResult>;
}

const Native = registerPlugin<NordBillingPlugin>("NordBilling");

export const isAndroidNative = () => Capacitor.getPlatform() === "android";

export const billing = {
  getEntitlement: () => Native.getEntitlement(),
  getProduct: () => Native.getProduct(),
  purchase: () => Native.purchase(),
};

/**
 * Vérification serveur facultative (VITE_VERIFY_URL → /api/verify-purchase).
 * Réponse valide → Premium confirmé par l'API Google Play Developer.
 * Réponse invalide → Premium refusé. Serveur injoignable → on garde le résultat de Google Play.
 */
export async function verifyOnServer(token: string, productId: string): Promise<boolean | null> {
  const url = import.meta.env.VITE_VERIFY_URL as string | undefined;
  if (!url) return null;
  try {
    const res = await fetch(url, {
      method: "POST",
      headers: { "content-type": "application/json" },
      body: JSON.stringify({ purchaseToken: token, productId }),
    });
    if (!res.ok) return null;
    const data = (await res.json()) as { valid?: boolean };
    return data.valid === true;
  } catch {
    return null;
  }
}
