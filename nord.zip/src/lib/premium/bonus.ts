import type { Arc, RuleDef } from "../types";

/** Exercices et habitudes bonus de NORD Premium. Ils ne comptent pas dans « Journée pleine » : aucune pression en plus. */
export const BONUS_CATALOG: RuleDef[] = [
  { id: "b-etirements", title: "Étirements, 10 minutes", detail: "Après l'effort, ou le soir.", icon: "wind", cadence: "daily" },
  { id: "b-gainage", title: "Gainage, 3 minutes", detail: "Planche. Tiens. Respire.", icon: "dumbbell", cadence: "daily" },
  { id: "b-mobilite", title: "Mobilité du matin", detail: "Cinq minutes avant de commencer.", icon: "sunrise", cadence: "daily" },
  { id: "b-pompes", title: "100 pompes dans la journée", detail: "Par séries. Comme tu veux.", icon: "dumbbell", cadence: "daily" },
  { id: "b-meditation", title: "Méditer, 10 minutes", detail: "Assis. Sans écran.", icon: "brain", cadence: "daily" },
  { id: "b-respiration", title: "Respiration, 5 minutes", detail: "Lente. Par le nez.", icon: "wind", cadence: "daily" },
  { id: "b-lecture", title: "Lire 20 pages", detail: "Un vrai livre.", icon: "book", cadence: "daily" },
  { id: "b-sucre", title: "Zéro sucre ajouté", detail: "Aujourd'hui, c'est non.", icon: "ban", cadence: "daily" },
  { id: "b-marche", title: "Marche du soir, 20 minutes", detail: "Sans téléphone.", icon: "footprints", cadence: "daily" },
  { id: "b-journal", title: "Écrire dix lignes", detail: "Ce qui s'est passé. Ce que tu retiens.", icon: "heart", cadence: "daily" },
];

const BONUS_MAP = Object.fromEntries(BONUS_CATALOG.map((r) => [r.id, r]));

export function bonusRulesOf(arc: Arc): RuleDef[] {
  const fromCatalog = (arc.bonusIds ?? []).map((id) => BONUS_MAP[id]).filter(Boolean);
  const custom: RuleDef[] = (arc.customBonus ?? []).map((c) => ({
    id: c.id,
    title: c.title,
    detail: "Ton exercice.",
    icon: "heart",
    cadence: "daily",
  }));
  return [...fromCatalog, ...custom];
}

/** Nombre total de bonus validés sur toute la durée de l'arc. */
export function bonusDone(arc: Arc): number {
  let n = 0;
  for (const day of Object.values(arc.days)) {
    for (const [id, ok] of Object.entries(day.checks)) {
      if (ok && (id.startsWith("b-") || id.startsWith("x-"))) n++;
    }
  }
  return n;
}
