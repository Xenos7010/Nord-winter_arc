/** Identifiant du produit "achat unique" créé dans la Google Play Console. */
export const PRODUCT_ID = "nord_premium";
export const PRICE_FALLBACK = "1,99 €";
/** Nombre maximum d'exercices bonus actifs (catalogue + personnels). */
export const MAX_BONUS = 5;
export const MAX_CUSTOM_BONUS = 2;
