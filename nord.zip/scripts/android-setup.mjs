#!/usr/bin/env node
import { existsSync } from "node:fs";
import { spawnSync } from "node:child_process";

function run(command, args) {
  console.log(`\n$ ${command} ${args.join(" ")}`);
  const result = spawnSync(command, args, { stdio: "inherit", shell: false });
  if (result.status !== 0) process.exit(result.status ?? 1);
}

if (!existsSync("node_modules")) {
  console.error("node_modules est absent. Lance d'abord: npm install");
  process.exit(1);
}

if (!existsSync("android")) {
  run(process.platform === "win32" ? "npx.cmd" : "npx", ["cap", "add", "android"]);
}
if (process.platform !== "win32" && existsSync("android-overlay/apply.sh")) run("bash", ["android-overlay/apply.sh"]);
run(process.platform === "win32" ? "npx.cmd" : "npx", ["cap", "sync", "android"]);
console.log("\nProjet Android prêt. Ouvre Android Studio avec: npm run android:open");
