/**
 * Vérification serveur facultative d'un achat Google Play (API Google Play Developer).
 * Variables d'environnement (déploiement Vercel) :
 *   GOOGLE_PLAY_SERVICE_ACCOUNT_JSON  JSON du compte de service (accès API Play Console)
 *   GOOGLE_PLAY_PACKAGE_NAME          par défaut com.nord.arc90
 * Côté app : VITE_VERIFY_URL=https://ton-domaine/api/verify-purchase
 */
import { createSign } from "node:crypto";

const json = (body: unknown, status = 200) =>
  new Response(JSON.stringify(body), { status, headers: { "content-type": "application/json" } });

const b64u = (s: string) => Buffer.from(s).toString("base64url");

async function accessToken(sa: { client_email: string; private_key: string }): Promise<string> {
  const now = Math.floor(Date.now() / 1000);
  const head = b64u(JSON.stringify({ alg: "RS256", typ: "JWT" }));
  const claim = b64u(
    JSON.stringify({
      iss: sa.client_email,
      scope: "https://www.googleapis.com/auth/androidpublisher",
      aud: "https://oauth2.googleapis.com/token",
      iat: now,
      exp: now + 3600,
    }),
  );
  const sig = createSign("RSA-SHA256").update(`${head}.${claim}`).sign(sa.private_key, "base64url");
  const res = await fetch("https://oauth2.googleapis.com/token", {
    method: "POST",
    headers: { "content-type": "application/x-www-form-urlencoded" },
    body: new URLSearchParams({
      grant_type: "urn:ietf:params:oauth:grant-type:jwt-bearer",
      assertion: `${head}.${claim}.${sig}`,
    }),
  });
  if (!res.ok) throw new Error("token");
  return ((await res.json()) as { access_token: string }).access_token;
}

export default async function verifyPurchase(event: { req: Request }): Promise<Response> {
  try {
    const { purchaseToken, productId } = (await event.req.json()) as { purchaseToken?: string; productId?: string };
    const raw = process.env.GOOGLE_PLAY_SERVICE_ACCOUNT_JSON;
    if (!purchaseToken || productId !== "nord_premium" || !raw) return json({ valid: false }, 400);
    const pkg = process.env.GOOGLE_PLAY_PACKAGE_NAME ?? "com.nord.arc90";
    const token = await accessToken(JSON.parse(raw));
    const res = await fetch(
      `https://androidpublisher.googleapis.com/androidpublisher/v3/applications/${pkg}/purchases/products/${productId}/tokens/${encodeURIComponent(purchaseToken)}`,
      { headers: { authorization: `Bearer ${token}` } },
    );
    if (!res.ok) return json({ valid: false });
    const p = (await res.json()) as { purchaseState?: number };
    return json({ valid: p.purchaseState === 0 });
  } catch {
    return json({ valid: false }, 500);
  }
}
