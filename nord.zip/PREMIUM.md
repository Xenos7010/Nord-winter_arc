# NORD Premium — mise en place (Google Play Billing)

Achat unique de 1,99 €, produit `nord_premium`, sans abonnement.

## Ce que fait l'app
- Les 90 jours sont gratuits : aucun jour n'est verrouillé.
- NORD Premium débloque la personnalisation : couleur de la flamme (Braise, Or, Rouge, Glace), 10 exercices bonus au choix (5 actifs maximum), 2 exercices personnels, ainsi que les paliers, défis et la synthèse détaillée. Les bonus ne comptent jamais dans « Journée pleine ».
- Si Premium n'est plus validé (remboursement), les réglages sont conservés mais cessent de s'appliquer.
- Le statut Premium n'est jamais enregistré sur l'appareil : il est relu auprès de Google Play à chaque lancement et à chaque retour dans l'app (un remboursement retire donc Premium).
- Le compte Google Play fait office de compte : « Restaurer mes achats » (onglet Toi) retrouve l'achat sur tout appareil connecté au même compte.
- Vérification serveur facultative : `VITE_VERIFY_URL` + route `server/routes/api/verify-purchase.post.ts` (variables `GOOGLE_PLAY_SERVICE_ACCOUNT_JSON`, `GOOGLE_PLAY_PACKAGE_NAME`).

## Ce qu'il faut côté Google (impossible à faire depuis le code)
1. Compte développeur Google Play (25 $, paiement unique).
2. Créer l'application avec le nom de paquet `com.nord.arc90`.
3. Monétisation → Produits → Produits uniques : ID `nord_premium`, prix 1,99 €, statut actif.
4. Générer la clé de signature : GitHub → Actions → « Créer la clé de signature » → Run. Télécharger l'artefact `secrets.txt`, puis créer trois secrets (Settings → Secrets and variables → Actions) : `KEYSTORE_BASE64`, `KEYSTORE_PASSWORD`, `KEY_ALIAS`. Garder ce fichier : sans cette clé, impossible de mettre à jour l'app.
5. Relancer « Build APK » : il produit en plus `NORD-aab` (bundle signé). L'envoyer dans une piste de test interne (Testing → Internal testing).
6. Settings → License testing : ajouter les adresses Gmail de test (achats sans débit).
7. Installer l'app depuis le lien de test interne (pas l'APK de GitHub : l'achat ne marche qu'avec une app installée depuis Google Play).
