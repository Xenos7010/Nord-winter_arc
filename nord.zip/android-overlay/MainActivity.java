package com.nord.arc90;

import android.os.Bundle;
import com.getcapacitor.BridgeActivity;

public class MainActivity extends BridgeActivity {
    @Override
    public void onCreate(Bundle savedInstanceState) {
        registerPlugin(NordBillingPlugin.class);
        super.onCreate(savedInstanceState);
    }
}
