#!/usr/bin/env bash
# Ajoute le pont Google Play Billing au projet Android généré par Capacitor.
# À lancer depuis la racine du projet, après `npx cap add android`.
set -euo pipefail
DIR="android/app/src/main/java/com/nord/arc90"
mkdir -p "$DIR"
cp android-overlay/NordBillingPlugin.java "$DIR/"
cp android-overlay/MainActivity.java "$DIR/"
GRADLE="android/app/build.gradle"
if ! grep -q "com.android.billingclient" "$GRADLE"; then
  sed -i '/^dependencies {/a\    implementation "com.android.billingclient:billing:8.3.0"' "$GRADLE"
fi
echo "Billing overlay appliqué."
