package com.nord.arc90;

import android.app.Activity;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import com.android.billingclient.api.AcknowledgePurchaseParams;
import com.android.billingclient.api.BillingClient;
import com.android.billingclient.api.BillingClientStateListener;
import com.android.billingclient.api.BillingFlowParams;
import com.android.billingclient.api.BillingResult;
import com.android.billingclient.api.PendingPurchasesParams;
import com.android.billingclient.api.ProductDetails;
import com.android.billingclient.api.Purchase;
import com.android.billingclient.api.PurchasesUpdatedListener;
import com.android.billingclient.api.QueryProductDetailsParams;
import com.android.billingclient.api.QueryPurchasesParams;
import com.getcapacitor.JSObject;
import com.getcapacitor.Plugin;
import com.getcapacitor.PluginCall;
import com.getcapacitor.PluginMethod;
import com.getcapacitor.annotation.CapacitorPlugin;
import java.util.Collections;
import java.util.List;

/**
 * Pont Google Play Billing (achat unique "nord_premium").
 * Aucun état n'est conservé : chaque appel interroge Google Play.
 */
@CapacitorPlugin(name = "NordBilling")
public class NordBillingPlugin extends Plugin implements PurchasesUpdatedListener {
    private static final String PRODUCT_ID = "nord_premium";

    private BillingClient client;
    private PluginCall pendingPurchase;

    @Override
    public void load() {
        client = BillingClient.newBuilder(getContext())
            .setListener(this)
            .enablePendingPurchases(PendingPurchasesParams.newBuilder().enableOneTimeProducts().build())
            .enableAutoServiceReconnection()
            .build();
    }

    private interface Ready {
        void run(@Nullable String error);
    }

    private void withConnection(final Ready ready) {
        if (client.isReady()) {
            ready.run(null);
            return;
        }
        client.startConnection(new BillingClientStateListener() {
            @Override
            public void onBillingSetupFinished(@NonNull BillingResult result) {
                if (result.getResponseCode() == BillingClient.BillingResponseCode.OK) {
                    ready.run(null);
                } else {
                    String msg = result.getDebugMessage();
                    ready.run(msg == null || msg.isEmpty() ? "Google Play indisponible." : msg);
                }
            }

            @Override
            public void onBillingServiceDisconnected() {}
        });
    }

    private boolean isNord(Purchase p) {
        return p.getProducts().contains(PRODUCT_ID);
    }

    private void acknowledgeIfNeeded(Purchase p) {
        if (p.getPurchaseState() == Purchase.PurchaseState.PURCHASED && !p.isAcknowledged()) {
            client.acknowledgePurchase(
                AcknowledgePurchaseParams.newBuilder().setPurchaseToken(p.getPurchaseToken()).build(),
                result -> {}
            );
        }
    }

    @PluginMethod
    public void getEntitlement(final PluginCall call) {
        withConnection(error -> {
            JSObject out = new JSObject();
            out.put("premium", false);
            out.put("pending", false);
            if (error != null) {
                out.put("billing", "unavailable");
                out.put("message", error);
                call.resolve(out);
                return;
            }
            client.queryPurchasesAsync(
                QueryPurchasesParams.newBuilder().setProductType(BillingClient.ProductType.INAPP).build(),
                (result, purchases) -> {
                    if (result.getResponseCode() != BillingClient.BillingResponseCode.OK) {
                        out.put("billing", "error");
                        out.put("message", result.getDebugMessage());
                        call.resolve(out);
                        return;
                    }
                    out.put("billing", "ok");
                    for (Purchase p : purchases) {
                        if (!isNord(p)) continue;
                        if (p.getPurchaseState() == Purchase.PurchaseState.PURCHASED) {
                            acknowledgeIfNeeded(p);
                            out.put("premium", true);
                            out.put("purchaseToken", p.getPurchaseToken());
                            out.put("orderId", p.getOrderId());
                        } else if (p.getPurchaseState() == Purchase.PurchaseState.PENDING) {
                            out.put("pending", true);
                        }
                    }
                    call.resolve(out);
                }
            );
        });
    }

    private QueryProductDetailsParams productParams() {
        return QueryProductDetailsParams.newBuilder()
            .setProductList(
                Collections.singletonList(
                    QueryProductDetailsParams.Product.newBuilder()
                        .setProductId(PRODUCT_ID)
                        .setProductType(BillingClient.ProductType.INAPP)
                        .build()
                )
            )
            .build();
    }

    @PluginMethod
    public void getProduct(final PluginCall call) {
        withConnection(error -> {
            JSObject out = new JSObject();
            out.put("available", false);
            if (error != null) {
                out.put("message", error);
                call.resolve(out);
                return;
            }
            client.queryProductDetailsAsync(productParams(), (result, details) -> {
                List<ProductDetails> list = details.getProductDetailsList();
                if (result.getResponseCode() == BillingClient.BillingResponseCode.OK && !list.isEmpty()) {
                    ProductDetails.OneTimePurchaseOfferDetails offer = list.get(0).getOneTimePurchaseOfferDetails();
                    if (offer != null) {
                        out.put("available", true);
                        out.put("price", offer.getFormattedPrice());
                    }
                }
                call.resolve(out);
            });
        });
    }

    @PluginMethod
    public void purchase(final PluginCall call) {
        final Activity activity = getActivity();
        if (activity == null) {
            call.reject("Activité indisponible.");
            return;
        }
        withConnection(error -> {
            if (error != null) {
                resolveStatus(call, "unavailable", "Impossible de joindre Google Play.");
                return;
            }
            client.queryProductDetailsAsync(productParams(), (result, details) -> {
                List<ProductDetails> list = details.getProductDetailsList();
                if (result.getResponseCode() != BillingClient.BillingResponseCode.OK || list.isEmpty()) {
                    resolveStatus(call, "unavailable", "NORD Premium n'est pas disponible sur ce compte Google Play.");
                    return;
                }
                BillingFlowParams flow = BillingFlowParams.newBuilder()
                    .setProductDetailsParamsList(
                        Collections.singletonList(
                            BillingFlowParams.ProductDetailsParams.newBuilder().setProductDetails(list.get(0)).build()
                        )
                    )
                    .build();
                getBridge().saveCall(call);
                pendingPurchase = call;
                BillingResult launched = client.launchBillingFlow(activity, flow);
                if (launched.getResponseCode() != BillingClient.BillingResponseCode.OK) {
                    pendingPurchase = null;
                    getBridge().releaseCall(call);
                    if (launched.getResponseCode() == BillingClient.BillingResponseCode.ITEM_ALREADY_OWNED) {
                        resolveStatus(call, "already_owned", null);
                    } else {
                        resolveStatus(call, "error", "Le paiement n'a pas pu démarrer.");
                    }
                }
            });
        });
    }

    @Override
    public void onPurchasesUpdated(@NonNull BillingResult result, @Nullable List<Purchase> purchases) {
        final PluginCall call = pendingPurchase;
        pendingPurchase = null;
        int code = result.getResponseCode();
        String status = "error";
        String message = null;

        if (code == BillingClient.BillingResponseCode.OK && purchases != null) {
            for (Purchase p : purchases) {
                if (!isNord(p)) continue;
                if (p.getPurchaseState() == Purchase.PurchaseState.PURCHASED) {
                    acknowledgeIfNeeded(p);
                    status = "purchased";
                } else if (p.getPurchaseState() == Purchase.PurchaseState.PENDING && !"purchased".equals(status)) {
                    status = "pending";
                }
            }
        } else if (code == BillingClient.BillingResponseCode.USER_CANCELED) {
            status = "cancelled";
        } else if (code == BillingClient.BillingResponseCode.ITEM_ALREADY_OWNED) {
            status = "already_owned";
        } else if (
            code == BillingClient.BillingResponseCode.SERVICE_UNAVAILABLE ||
            code == BillingClient.BillingResponseCode.BILLING_UNAVAILABLE ||
            code == BillingClient.BillingResponseCode.NETWORK_ERROR
        ) {
            status = "unavailable";
            message = "Impossible de joindre Google Play. Vérifie ta connexion.";
        } else {
            message = "Le paiement n'a pas abouti. Aucun montant n'a été débité.";
        }

        if (call != null) {
            getBridge().releaseCall(call);
            resolveStatus(call, status, message);
        }
    }

    private void resolveStatus(PluginCall call, String status, @Nullable String message) {
        JSObject out = new JSObject();
        out.put("status", status);
        if (message != null) out.put("message", message);
        call.resolve(out);
    }
}
